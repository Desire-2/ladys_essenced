# app/routes/ussd.py
from flask import Blueprint, request
from app.models import User, CycleLog, MealLog, Appointment, Notification, ContentCategory, ContentItem, Parent, Adolescent, ParentChild, Feedback
from app import db, bcrypt
from datetime import datetime, timedelta
from flask_jwt_extended import create_access_token
import re
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

ussd_bp = Blueprint('ussd', __name__)

def format_content(content, max_length=160):
    """Format content for USSD display with pagination"""
    pages = []
    current_page = []
    current_length = 0
    
    for word in content.split():
        if current_length + len(word) + 1 <= max_length:
            current_page.append(word)
            current_length += len(word) + 1
        else:
            pages.append(' '.join(current_page))
            current_page = [word]
            current_length = len(word)
    
    if current_page:
        pages.append(' '.join(current_page))
    
    return pages

def check_backflow_navigation(user, input_list, current_step, service_name):
    """Check for backflow navigation commands ('0' for back, '00' for main menu)"""
    if not input_list:
        return None
    
    current_input = input_list[-1]
    
    # Check for main menu return
    if current_input == '00':
        logger.info(f"Backflow: User requested main menu from {service_name}")
        return main_menu(user)
    
    # Check for back navigation
    if current_input == '0':
        logger.info(f"Backflow: User requested back from {service_name}, step {current_step}")
        
        if current_step <= 1:
            # If at first step of service, go back to main menu
            return main_menu(user)
        else:
            # Go back to previous step by removing last input and calling handler again
            previous_input_list = input_list[:-1]
            logger.info(f"Backflow: Going back with input_list: {previous_input_list}")
            
            # Route back to appropriate handler based on service
            if service_name == 'cycle_tracking':
                return handle_cycle_tracking(user, previous_input_list)
            elif service_name == 'meal_logging':
                return handle_meal_logging(user, previous_input_list)
            elif service_name == 'appointments':
                return handle_appointments(user, previous_input_list)
            elif service_name == 'notifications':
                return handle_notifications(user, previous_input_list)
            elif service_name == 'education':
                return handle_education(user, previous_input_list)
            elif service_name == 'parent_dashboard':
                return handle_parent_dashboard(user, previous_input_list)
            elif service_name == 'settings':
                return handle_settings(user, previous_input_list)
            elif service_name == 'feedback':
                return handle_feedback_submission(user, previous_input_list)
            elif service_name == 'help':
                return handle_help_menu(user, previous_input_list)
            else:
                return main_menu(user)
    
    return None

@ussd_bp.route('', methods=['POST'])
def handle_ussd():
    """Main USSD handler with improved error handling and state management"""
    try:
        session_id = request.form.get('sessionId')
        phone_number = request.form.get('phoneNumber', '').strip()
        text = request.form.get('text', '').strip()
        
        # Validate input
        if not phone_number:
            return "END Invalid phone number"
        
        input_list = text.split('*') if text else []
        current_step = len(input_list)
        user_input = input_list[-1] if input_list else ''
        user = User.query.filter_by(phone_number=phone_number).first()

        logger.info(f"USSD Request: Phone={phone_number}, Step={current_step}, Input={input_list}, User={'Found' if user else 'Not Found'}")

        # Route to appropriate handler based on authentication state and step
        if current_step == 0:
            return handle_initial_menu(user)
        
        elif current_step == 1:
            return handle_first_step(user, user_input, phone_number)
        
        elif current_step >= 2:
            return handle_authenticated_flow(user, input_list, phone_number)
        
        else:
            return "END Invalid session state"

    except Exception as e:
        logger.error(f"USSD Error: {str(e)}")
        return "END Service temporarily unavailable. Please try again."

def handle_initial_menu(user):
    """Handle the initial USSD menu"""
    if user:
        return "CON Welcome back!\nEnter your 4-digit PIN:"
    else:
        return "CON Welcome to The Lady's Essence 🌸\n1. Register New Account\n2. Login to Existing Account"

def handle_first_step(user, user_input, phone_number):
    """Handle first step after initial menu"""
    if not user:  # New user flow
        if user_input == '1':
            return "CON Registration\nEnter your full name:"
        elif user_input == '2':
            return "CON Login\nEnter your 4-digit PIN:"
        else:
            return "END Invalid option. Please try again."
    
    else:  # Existing user PIN verification
        if len(user_input) == 4 and user_input.isdigit():
            if bcrypt.check_password_hash(user.password_hash, user_input):
                return main_menu(user)
            else:
                return "END Invalid PIN. Please try again."
        else:
            return "END PIN must be exactly 4 digits."

def handle_authenticated_flow(user, input_list, phone_number):
    """Handle authenticated user flows"""
    steps = len(input_list)
    
    if not user and input_list[0] == '1':  # Registration flow
        return handle_registration_flow(input_list, phone_number)
    
    elif not user and input_list[0] == '2':  # Login flow
        return handle_login_flow(input_list, phone_number)
    
    elif user:  # Authenticated user flows
        # For existing users, the flow is:
        # Step 1: PIN entry -> Verify and show main menu
        # Step 2+: Menu navigation -> Skip PIN, handle menu selections
        
        if steps == 1:
            # Just entered PIN, verify it
            if bcrypt.check_password_hash(user.password_hash, input_list[0]):
                return main_menu(user)
            else:
                return "END Invalid PIN. Please try again."
        else:
            # Menu navigation - PIN was already verified in step 1
            # input_list[0] = PIN (skip this)
            # input_list[1] = Main menu selection (1-9)  
            # input_list[2+] = Submenu selections
            menu_input_list = input_list[1:]  # Remove PIN from input
            logger.info(f"Menu navigation: Original input={input_list}, Menu input={menu_input_list}")
            return handle_menu_navigation(user, menu_input_list)
    
    else:
        return "END Session expired. Please start again."

def handle_registration_flow(input_list, phone_number):
    """Handle user registration flow"""
    steps = len(input_list)
    
    if steps == 2:  # Name entered
        name = input_list[1].strip()
        if len(name) < 2:
            return "END Name too short. Minimum 2 characters required."
        elif len(name) > 50:
            return "END Name too long. Maximum 50 characters allowed."
        else:
            return "CON Choose account type:\n1. Parent/Guardian\n2. Adolescent/Teen"
    
    elif steps == 3:  # User type selected
        if input_list[2] in ['1', '2']:
            return "CON Create a secure 4-digit PIN:"
        else:
            return "END Invalid selection. Please try again."
    
    elif steps == 4:  # PIN entered
        pin = input_list[3]
        if len(pin) != 4 or not pin.isdigit():
            return "END Invalid PIN. Must be exactly 4 digits."
        
        # Validate name again
        name = input_list[1].strip()
        if len(name) < 2:
            return "END Invalid name length."
            
        try:
            # Create new user
            new_user = User(
                name=name,
                phone_number=phone_number,
                password_hash=bcrypt.generate_password_hash(pin).decode('utf-8'),
                user_type='parent' if input_list[2] == '1' else 'adolescent'
            )
            db.session.add(new_user)
            db.session.flush()  # Get the user ID
            
            # Create associated profile
            if new_user.user_type == 'parent':
                parent = Parent(user_id=new_user.id)
                db.session.add(parent)
            else:
                adolescent = Adolescent(user_id=new_user.id)
                db.session.add(adolescent)
            
            # Create welcome notification
            welcome_msg = f"Welcome to The Lady's Essence, {name}! Your account has been created successfully."
            notification = Notification(
                user_id=new_user.id,
                message=welcome_msg,
                notification_type='welcome'
            )
            db.session.add(notification)
            
            db.session.commit()
            return f"END ✅ Registration successful!\nWelcome {name}!\nYou can now access our services."
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Registration error: {str(e)}")
            return "END Registration failed. Please try again."

def handle_login_flow(input_list, phone_number):
    """Handle user login flow"""
    if len(input_list) == 2:
        pin = input_list[1]
        user = User.query.filter_by(phone_number=phone_number).first()
        
        if not user:
            return "END No account found with this phone number."
        
        if len(pin) == 4 and pin.isdigit():
            if bcrypt.check_password_hash(user.password_hash, pin):
                return main_menu(user)
            else:
                return "END Invalid PIN. Please try again."
        else:
            return "END PIN must be exactly 4 digits."
    
    return "END Invalid login attempt."

def handle_menu_navigation(user, input_list):
    """Handle main menu navigation for authenticated users"""
    # User is already authenticated at this point, no need to verify PIN again
    steps = len(input_list)
    
    logger.info(f"Menu Navigation: User={user.name}, Steps={steps}, Input={input_list}")
    
    if steps < 1:
        return main_menu(user)
    
    current_selection = input_list[0]  # First element is the menu selection
    
    try:
        logger.info(f"Processing menu selection: {current_selection}")
        
        if current_selection == '1':
            return handle_cycle_tracking(user, input_list)
        elif current_selection == '2':
            return handle_meal_logging(user, input_list)
        elif current_selection == '3':
            return handle_appointments(user, input_list)
        elif current_selection == '4':
            return handle_education(user, input_list)
        elif current_selection == '5':
            return handle_notifications(user, input_list)
        elif current_selection == '6' and user.user_type == 'parent':
            return handle_parent_dashboard(user, input_list)
        elif current_selection == '7':
            return handle_settings(user, input_list)
        elif current_selection == '8':
            return handle_feedback_submission(user, input_list)
        elif current_selection == '9':
            return handle_help_menu(user, input_list)
        elif current_selection == '0':
            return "END Thank you for using The Lady's Essence! Take care! 🌸"
        else:
            return "END Invalid menu selection."
    except Exception as e:
        logger.error(f"Menu navigation error: {str(e)}")
        return "END Error processing request. Please try again."

def handle_help_menu(user, input_list):
    """Handle help menu navigation"""
    steps = len(input_list)
    
    # Check for backflow navigation
    backflow_result = check_backflow_navigation(user, input_list, steps, 'help')
    if backflow_result:
        return backflow_result
    
    if steps == 1:
        return """CON 🆘 Help & Support:
1. How to use this service
2. Health emergency contacts
3. Technical support
4. Privacy information
5. Terms of service
0. Back to main menu
00. Main Menu"""
    
    elif steps == 2:
        selection = input_list[1]
        
        if selection == '1':
            return get_usage_instructions()
        elif selection == '2':
            return f"CON {get_emergency_contacts()}\n0. Back\n00. Main Menu"
        elif selection == '3':
            return get_technical_support()
        elif selection == '4':
            return get_privacy_info()
        elif selection == '5':
            return get_terms_of_service()
        elif selection == '0':
            return main_menu(user)
        else:
            return "END Invalid selection."
    
    return "END Invalid help flow."

def get_usage_instructions():
    """Return usage instructions"""
    return """CON 📖 How to Use:
• Use numbers to navigate menus
• Follow prompts for data entry
• Press 0 to go back
• Press 00 for main menu
• All personal data is encrypted
• Track cycles, meals, appointments
• Parents can monitor children
• Get health education content
0. Back
00. Main Menu"""

def get_technical_support():
    """Return technical support information"""
    return """CON 🔧 Technical Support:
• Service issues: *123*911#
• Lost access: Contact clinic
• Data problems: Report via feedback
• Emergency access: Call directly
• Hours: 24/7 support available
0. Back
00. Main Menu"""

def get_privacy_info():
    """Return privacy information"""
    return """CON 🔒 Privacy & Security:
• All data encrypted in transit
• Medical data stored securely
• Only authorized access allowed
• Parents see child summary only
• Delete account removes all data
• HIPAA compliant system
0. Back
00. Main Menu"""

def get_terms_of_service():
    """Return terms of service summary"""
    return """CON 📄 Terms of Service:
• Service for health tracking only
• Not a substitute for medical care
• Emergency: Call 911 immediately
• Data accuracy not guaranteed
• User responsible for data entry
• Service may be unavailable
0. Back
00. Main Menu"""

def main_menu(user):
    """Generate main menu based on user type"""
    return enhanced_main_menu(user)

def handle_cycle_tracking(user, input_list):
    """Enhanced cycle tracking with better navigation and features"""
    steps = len(input_list)
    
    # Check for universal back navigation first
    if steps > 1:
        last_input = input_list[-1]
        if last_input == '00':
            return main_menu(user)
        elif last_input == '0' and steps > 1:
            # Go back to previous level
            if steps == 2:
                return main_menu(user)
            elif steps >= 3:
                return handle_cycle_tracking(user, input_list[:-1])
    
    if steps == 1:
        return ("CON 🔄 Cycle Tracking:\n1. Log Period Start\n2. Log Period End\n"
                "3. Current Status\n4. Cycle History\n5. Cycle Predictions\n"
                "6. Update Cycle Info\n0. Back to Main Menu\n00. Main Menu")
    
    elif steps == 2:
        selection = input_list[1]
        
        if selection == '1':
            # Check if user has provided cycle info
            if not user.has_provided_cycle_info:
                return ("CON First time logging? Let's get your cycle info!\n"
                       "Do you know your usual cycle length?\n1. Yes, I know it\n"
                       "2. No, I'm not sure\n0. Back\n00. Main Menu")
        
        elif selection == '2':
            # Find current active cycle
            active_cycle = CycleLog.query.filter_by(user_id=user.id, end_date=None).order_by(CycleLog.start_date.desc()).first()
            if not active_cycle:
                return "END No active period to end."
            return ("CON Log Period End\nEnter date (DD-MM-YYYY)\n"
                   "or press 1 for today:\n0. Back\n00. Main Menu")
        
        elif selection == '3':
            return get_cycle_status(user)
        
        elif selection == '4':
            return get_cycle_history(user)
        
        elif selection == '5':
            return get_cycle_predictions(user)
        
        elif selection == '6':
            return ("CON 🔧 Update Cycle Info:\n"
                   "Current info:\n"
                   f"Cycle length: {user.personal_cycle_length or 'Not set'} days\n"
                   f"Period length: {user.personal_period_length or 'Not set'} days\n\n"
                   "1. Update cycle length\n2. Update period length\n"
                   "3. Reset to use calculated averages\n0. Back\n00. Main Menu")
        
        elif selection == '0':
            return main_menu(user)
        
        else:
            return "END Invalid selection. Try 0 for back or 00 for main menu."
    
    elif steps == 3:
        selection = input_list[2]
        
        if input_list[1] == '1':  # Log period start flow
            if selection == '0':
                return handle_cycle_tracking(user, input_list[:2])
            elif selection == '00':
                return main_menu(user)
            elif not user.has_provided_cycle_info:
                # Handle cycle info collection
                if selection == '1':  # User knows cycle length
                    return ("CON Great! Enter your usual cycle length\n(in days, e.g., 28):\n"
                           "0. Back\n00. Main Menu")
                elif selection == '2':  # User not sure
                    # Skip cycle info and proceed with standard
                    return ("CON No problem! We'll use standard estimates.\n"
                           "Enter period start date (DD-MM-YYYY)\nor press 1 for today:\n"
                           "0. Back\n00. Main Menu")
                else:
                    return "END Invalid selection. Try again."
            else:
                # User already provided cycle info, so this is the date input
                return ("CON Log Period Start\nEnter date (DD-MM-YYYY)\n"
                       "or press 1 for today:\n0. Back\n00. Main Menu")
        
        elif input_list[1] == '2':  # Log period end
            if selection == '0':
                return handle_cycle_tracking(user, input_list[:2])
            elif selection == '00':
                return main_menu(user)
            else:
                return handle_period_end(user, selection)
        
        elif input_list[1] == '6':  # Update cycle info
            if selection == '0':
                return handle_cycle_tracking(user, input_list[:2])
            elif selection == '00':
                return main_menu(user)
            elif selection == '1':
                return ("CON Enter new cycle length (21-40 days):\n"
                       "0. Back\n00. Main Menu")
            elif selection == '2':
                return ("CON Enter new period length (3-8 days):\n"
                       "0. Back\n00. Main Menu")
            elif selection == '3':
                # Reset to use calculated averages
                user.has_provided_cycle_info = False
                user.personal_cycle_length = None
                user.personal_period_length = None
                db.session.commit()
                return "END ✅ Cycle info reset! Future predictions will use your cycle history."
            else:
                return "END Invalid selection."
    
    elif steps == 4:
        if input_list[1] == '1':  # Log period start flow
            selection = input_list[3]
            
            if selection == '0':
                return handle_cycle_tracking(user, input_list[:3])
            elif selection == '00':
                return main_menu(user)
            elif not user.has_provided_cycle_info and input_list[2] == '1':  # User provided cycle length
                try:
                    cycle_length = int(selection)
                    if 21 <= cycle_length <= 40:  # Reasonable range
                        return ("CON Perfect! Now enter your usual period length\n"
                               "(in days, e.g., 5):\n0. Back\n00. Main Menu")
                    else:
                        return "END Cycle length should be between 21-40 days."
                except ValueError:
                    return "END Please enter a valid number."
            elif not user.has_provided_cycle_info and input_list[2] == '2':  # User not sure, proceeding with date
                # Mark as info not provided and handle period start
                return handle_period_start(user, selection)
            elif user.has_provided_cycle_info:  # User already has cycle info, this is date input
                return handle_period_start(user, selection)
        
        elif input_list[1] == '6':  # Update cycle info
            selection = input_list[3]
            
            if selection == '0':
                return handle_cycle_tracking(user, input_list[:3])
            elif selection == '00':
                return main_menu(user)
            elif input_list[2] == '1':  # Update cycle length
                try:
                    cycle_length = int(selection)
                    if 21 <= cycle_length <= 40:
                        user.personal_cycle_length = cycle_length
                        user.has_provided_cycle_info = True
                        db.session.commit()
                        return "END ✅ Cycle length updated successfully!"
                    else:
                        return "END Cycle length should be between 21-40 days."
                except ValueError:
                    return "END Please enter a valid number."
            elif input_list[2] == '2':  # Update period length
                try:
                    period_length = int(selection)
                    if 3 <= period_length <= 8:
                        user.personal_period_length = period_length
                        user.has_provided_cycle_info = True
                        db.session.commit()
                        return "END ✅ Period length updated successfully!"
                    else:
                        return "END Period length should be between 3-8 days."
                except ValueError:
                    return "END Please enter a valid number."
    
    elif steps == 5:
        if input_list[1] == '1' and input_list[2] == '1' and not user.has_provided_cycle_info:
            selection = input_list[4]
            
            if selection == '0':
                return handle_cycle_tracking(user, input_list[:4])
            elif selection == '00':
                return main_menu(user)
            else:
                try:
                    period_length = int(selection)
                    cycle_length = int(input_list[3])
                    
                    if 3 <= period_length <= 8:  # Reasonable range
                        # Save user's cycle info
                        user.personal_cycle_length = cycle_length
                        user.personal_period_length = period_length
                        user.has_provided_cycle_info = True
                        db.session.commit()
                        
                        return ("CON Excellent! Your cycle info saved.\n"
                               "Now enter period start date (DD-MM-YYYY)\n"
                               "or press 1 for today:\n0. Back\n00. Main Menu")
                    else:
                        return "END Period length should be between 3-8 days."
                except ValueError:
                    return "END Please enter a valid number."
    
    elif steps == 6:
        if input_list[1] == '1':
            selection = input_list[5]
            if selection == '0':
                return handle_cycle_tracking(user, input_list[:5])
            elif selection == '00':
                return main_menu(user)
            else:
                return handle_period_start(user, selection)
    
    return "END Invalid flow. Try 0 for back or 00 for main menu."

def handle_period_start(user, date_input):
    """Handle period start logging with user's personal cycle info"""
    try:
        if date_input == '1':
            start_date = datetime.now()
        else:
            start_date = datetime.strptime(date_input, '%d-%m-%Y')
        
        # Check for overlapping cycles
        existing = CycleLog.query.filter_by(user_id=user.id, end_date=None).first()
        if existing:
            return "END You have an active period. End it first before starting a new one."
        
        # Use user's personal cycle length or calculate from history
        predicted_cycle_length = 28  # Default
        
        if user.has_provided_cycle_info and user.personal_cycle_length:
            predicted_cycle_length = user.personal_cycle_length
        else:
            # Calculate from history if available
            recent_cycles = CycleLog.query.filter_by(user_id=user.id).filter(
                CycleLog.end_date.isnot(None)
            ).order_by(CycleLog.start_date.desc()).limit(3).all()
            
            if recent_cycles:
                total_length = sum(c.cycle_length for c in recent_cycles if c.cycle_length)
                predicted_cycle_length = total_length // len(recent_cycles) if total_length else 28
        
        new_cycle = CycleLog(
            user_id=user.id,
            start_date=start_date,
            cycle_length=predicted_cycle_length
        )
        db.session.add(new_cycle)
        
        # Create notification for period tracking
        notification = Notification(
            user_id=user.id,
            message=f"Period started on {start_date.strftime('%d %b %Y')}. Remember to stay hydrated and take care!",
            notification_type='cycle'
        )
        db.session.add(notification)
        
        db.session.commit()
        return f"END ✅ Period start logged for {start_date.strftime('%d %b %Y')}!"
        
    except ValueError:
        return "END Invalid date format. Use DD-MM-YYYY"
    except Exception as e:
        db.session.rollback()
        logger.error(f"Period start error: {str(e)}")
        return "END Error logging period start."

def handle_period_end(user, date_input):
    """Handle period end logging"""
    try:
        if date_input == '1':
            end_date = datetime.now()
        else:
            end_date = datetime.strptime(date_input, '%d-%m-%Y')
        
        # Find active cycle
        active_cycle = CycleLog.query.filter_by(user_id=user.id, end_date=None).order_by(CycleLog.start_date.desc()).first()
        if not active_cycle:
            return "END No active period found to end."
        
        if end_date < active_cycle.start_date:
            return "END End date cannot be before start date."
        
        # Calculate period length
        period_length = (end_date - active_cycle.start_date).days + 1
        
        active_cycle.end_date = end_date
        active_cycle.period_length = period_length
        
        # Create notification
        notification = Notification(
            user_id=user.id,
            message=f"Period ended on {end_date.strftime('%d %b %Y')}. Duration: {period_length} days.",
            notification_type='cycle'
        )
        db.session.add(notification)
        
        db.session.commit()
        return f"END ✅ Period ended on {end_date.strftime('%d %b %Y')}!\nDuration: {period_length} days"
        
    except ValueError:
        return "END Invalid date format. Use DD-MM-YYYY"
    except Exception as e:
        db.session.rollback()
        logger.error(f"Period end error: {str(e)}")
        return "END Error logging period end."

def get_cycle_status(user):
    """Get current cycle status"""
    active_cycle = CycleLog.query.filter_by(user_id=user.id, end_date=None).order_by(CycleLog.start_date.desc()).first()
    
    if active_cycle:
        days_since_start = (datetime.now() - active_cycle.start_date).days
        return f"END 🔄 Current Status:\nPeriod active since {active_cycle.start_date.strftime('%d %b')}\nDay {days_since_start + 1} of current period"
    
    # Check last completed cycle
    last_cycle = CycleLog.query.filter_by(user_id=user.id).filter(
        CycleLog.end_date.isnot(None)
    ).order_by(CycleLog.start_date.desc()).first()
    
    if last_cycle:
        days_since_last = (datetime.now() - last_cycle.end_date).days
        predicted_next = last_cycle.end_date + timedelta(days=last_cycle.cycle_length - last_cycle.period_length)
        
        if datetime.now().date() > predicted_next.date():
            return f"END ⚠️ Period may be late!\nLast ended: {last_cycle.end_date.strftime('%d %b')}\nExpected: {predicted_next.strftime('%d %b')}"
        else:
            return f"END 📅 Next period expected:\n{predicted_next.strftime('%d %b %Y')}\n({(predicted_next - datetime.now()).days} days)"
    
    return "END No cycle data available. Start tracking your period!"

def get_cycle_history(user):
    """Get cycle history with navigation"""
    cycles = CycleLog.query.filter_by(user_id=user.id).order_by(CycleLog.start_date.desc()).limit(5).all()
    
    if not cycles:
        return "END No cycle history available."
    
    response = "CON 📊 Last 5 Cycles:\n"
    for idx, cycle in enumerate(cycles, 1):
        status = "Active" if not cycle.end_date else f"{cycle.period_length}d"
        response += f"{idx}. {cycle.start_date.strftime('%d %b')} - {status}\n"
    
    return response + "0. Back\n00. Main Menu"

def get_cycle_predictions(user):
    """Enhanced cycle predictions using personal info and completed cycles"""
    recent_cycles = CycleLog.query.filter_by(user_id=user.id).filter(
        CycleLog.end_date.isnot(None),
        CycleLog.cycle_length.isnot(None)
    ).order_by(CycleLog.start_date.desc()).limit(6).all()
    
    completed_cycles_count = len(recent_cycles)
    use_personal_info = user.has_provided_cycle_info and user.personal_cycle_length
    
    # Determine prediction accuracy and source
    if completed_cycles_count >= 3:
        # Use actual cycle data for accurate predictions
        avg_cycle = sum(c.cycle_length for c in recent_cycles) / len(recent_cycles)
        avg_period = sum(c.period_length for c in recent_cycles if c.period_length) / len([c for c in recent_cycles if c.period_length])
        prediction_source = "historical"
        accuracy_note = "📊 Accurate predictions based on your cycle history"
    elif use_personal_info:
        # Use personal cycle information
        avg_cycle = user.personal_cycle_length
        avg_period = user.personal_period_length if user.personal_period_length else 5
        prediction_source = "personal"
        accuracy_note = "📋 Predictions based on your provided cycle info"
    else:
        # Use standard estimates
        avg_cycle = 28
        avg_period = 5
        prediction_source = "standard"
        accuracy_note = "⚠️ Estimated predictions using standard cycle lengths"
    
    # Add accuracy disclaimer for non-historical predictions
    if prediction_source != "historical":
        accuracy_note += f"\n🔮 Complete 3 cycles for real accurate predictions"
    
    avg_luteal = 14  # Luteal phase is usually ~14 days
    avg_follicular = avg_cycle - avg_luteal

    # Get last cycle for prediction base
    if recent_cycles:
        last_cycle = recent_cycles[0]
        next_start = last_cycle.start_date + timedelta(days=int(avg_cycle))
    else:
        # If no cycles logged, use current date as base
        next_start = datetime.now() + timedelta(days=int(avg_cycle))

    response = f"CON 🔮 Cycle Predictions\n{accuracy_note}\n\n"
    response += f"Avg Cycle: {avg_cycle:.0f} days | Period: {avg_period:.0f} days\n"
    response += f"Data source: {prediction_source.title()}\n"
    response += f"Completed cycles: {completed_cycles_count}\n\n"
    
    response += "Next 3 cycles:\n"
    for i in range(3):
        cycle_start = next_start + timedelta(days=int(avg_cycle) * i)
        period_start = cycle_start
        period_end = period_start + timedelta(days=int(avg_period) - 1)
        follicular_end = period_end
        ovulation_day = cycle_start + timedelta(days=int(avg_follicular) - 1)
        luteal_start = ovulation_day + timedelta(days=1)
        cycle_end = cycle_start + timedelta(days=int(avg_cycle) - 1)

        response += f"\nCycle {i+1}: {cycle_start.strftime('%d %b')} - {cycle_end.strftime('%d %b')}\n"
        response += f"• Menstrual: {period_start.strftime('%d %b')} - {period_end.strftime('%d %b')}\n"
        response += f"• Follicular: {period_end.strftime('%d %b')} - {ovulation_day.strftime('%d %b')}\n"
        response += f"• Ovulation: {ovulation_day.strftime('%d %b')}\n"
        response += f"• Luteal: {luteal_start.strftime('%d %b')} - {cycle_end.strftime('%d %b')}\n"

    if prediction_source == "standard":
        response += "\n💡 Tip: Log your periods to get personalized predictions!"
    elif prediction_source == "personal":
        response += f"\n💡 After {3 - completed_cycles_count} more completed cycles, predictions will be based on your actual data!"
    
    response += "\n\nPhases:\n"
    response += "• Menstrual: Bleeding days\n"
    response += "• Follicular: Prepares egg, ends at ovulation\n"
    response += "• Ovulation: Most fertile day\n"
    response += "• Luteal: After ovulation, before next period\n"
    response += "0. Back\n00. Main Menu"
    return response

def handle_education(user, input_list):
    """Enhanced education content with better navigation"""
    steps = len(input_list)
    
    # Check for backflow navigation
    backflow_result = check_backflow_navigation(user, input_list, steps, 'education')
    if backflow_result:
        return backflow_result
    
    if steps == 1:
        categories = ContentCategory.query.all()
        if not categories:
            return "END No education content available at the moment."
        
        menu = "CON 📚 Health Education:\n"
        for idx, cat in enumerate(categories, 1):
            menu += f"{idx}. {cat.name}\n"
        menu += "0. Back\n00. Main Menu"
        return menu
    
    elif steps == 2:
        try:
            category_index = int(input_list[1]) - 1
            categories = ContentCategory.query.all()
            
            if input_list[1] == '0':
                return main_menu(user)
            
            if 0 <= category_index < len(categories):
                category = categories[category_index]
                items = ContentItem.query.filter_by(category_id=category.id).all()
                
                if not items:
                    return "END No content available in this category."
                
                menu = f"CON 📖 {category.name}:\n"
                for idx, item in enumerate(items, 1):
                    # Truncate long titles
                    title = item.title[:30] + "..." if len(item.title) > 30 else item.title
                    menu += f"{idx}. {title}\n"
                menu += "0. Back\n00. Main Menu"
                return menu
            else:
                return "END Invalid category selection."
                
        except ValueError:
            return "END Invalid selection."
    
    elif steps == 3:
        try:
            if input_list[2] == '0':
                return handle_education(user, input_list[:1])
            
            category_index = int(input_list[1]) - 1
            item_index = int(input_list[2]) - 1
            
            categories = ContentCategory.query.all()
            if 0 <= category_index < len(categories):
                category = categories[category_index]
                items = ContentItem.query.filter_by(category_id=category.id).all()
                
                if 0 <= item_index < len(items):
                    item = items[item_index]
                    pages = format_content(item.content, 140)  # Leave room for navigation
                    
                    # Store reading activity
                    notification = Notification(
                        user_id=user.id,
                        message=f"Read: {item.title}",
                        notification_type='education'
                    )
                    db.session.add(notification)
                    db.session.commit()
                    
                    if len(pages) > 1:
                        return f"CON {item.title}\n\n{pages[0]}\n\n1. Next page\n0. Back\n00. Main Menu"
                    else:
                        return f"CON {item.title}\n\n{pages[0]}\n\n0. Back\n00. Main Menu"
                else:
                    return "END Invalid article selection."
            else:
                return "END Invalid category."
                
        except ValueError:
            return "END Invalid selection."
    
    elif steps == 4:
        # Handle pagination
        if input_list[3] == '1':  # Next page
            try:
                category_index = int(input_list[1]) - 1
                item_index = int(input_list[2]) - 1
                
                categories = ContentCategory.query.all()
                category = categories[category_index]
                items = ContentItem.query.filter_by(category_id=category.id).all()
                item = items[item_index]
                
                pages = format_content(item.content, 140)
                if len(pages) > 1:
                    return f"CON {item.title} (2/{len(pages)})\n\n{pages[1]}\n\n2. Next\n9. Previous\n0. Back"
                
            except (ValueError, IndexError):
                pass
        
        return "END Invalid navigation."
    
    return "END Invalid flow."

def handle_notifications(user, input_list):
    """Enhanced notification management with backflow navigation"""
    steps = len(input_list)
    
    # Check for backflow navigation
    backflow_result = check_backflow_navigation(user, input_list, steps, 'notifications')
    if backflow_result:
        return backflow_result
    
    if steps == 1:
        unread_count = Notification.query.filter_by(user_id=user.id, read=False).count()
        return (f"CON 🔔 Notifications ({unread_count} unread):\n"
                "1. View Unread\n2. View All\n3. Mark All Read\n4. Clear Old\n\n"
                "0. Back\n00. Main Menu")
    
    elif steps == 2:
        selection = input_list[1]
        
        if selection == '1':
            return get_unread_notifications(user)
        elif selection == '2':
            return get_all_notifications(user)
        elif selection == '3':
            return mark_all_notifications_read(user)
        elif selection == '4':
            return clear_old_notifications(user)
        else:
            return "END Invalid selection. Try again."
    
    elif steps == 3:
        if input_list[1] in ['1', '2']:  # Viewing notifications
            return handle_notification_details(user, input_list)
    
    return "END Invalid flow. Please start again."

def get_unread_notifications(user):
    """Get unread notifications"""
    notifications = Notification.query.filter_by(
        user_id=user.id, read=False
    ).order_by(Notification.created_at.desc()).limit(10).all()
    
    if not notifications:
        return "END No unread notifications."
    
    response = "CON 📬 Unread Notifications:\n"
    for idx, notif in enumerate(notifications, 1):
        # Truncate long messages
        message = notif.message[:40] + "..." if len(notif.message) > 40 else notif.message
        type_emoji = get_notification_emoji(notif.notification_type)
        response += f"{idx}. {type_emoji} {message}\n"
    
    response += "0. Back"
    return response

def get_all_notifications(user):
    """Get all recent notifications"""
    notifications = Notification.query.filter_by(
        user_id=user.id
    ).order_by(Notification.created_at.desc()).limit(10).all()
    
    if not notifications:
        return "END No notifications found."
    
    response = "CON 📋 All Notifications:\n"
    for idx, notif in enumerate(notifications, 1):
        read_status = "✓" if notif.read else "●"
        message = notif.message[:35] + "..." if len(notif.message) > 35 else notif.message
        type_emoji = get_notification_emoji(notif.notification_type)
        response += f"{idx}. {read_status}{type_emoji} {message}\n"
    
    response += "0. Back"
    return response

def mark_all_notifications_read(user):
    """Mark all notifications as read"""
    try:
        Notification.query.filter_by(user_id=user.id, read=False).update({'read': True})
        db.session.commit()
        return "END ✅ All notifications marked as read."
    except Exception as e:
        db.session.rollback()
        logger.error(f"Mark notifications read error: {str(e)}")
        return "END Error updating notifications."

def clear_old_notifications(user):
    """Clear notifications older than 30 days"""
    try:
        thirty_days_ago = datetime.now() - timedelta(days=30)
        old_notifications = Notification.query.filter_by(user_id=user.id).filter(
            Notification.created_at < thirty_days_ago
        )
        count = old_notifications.count()
        old_notifications.delete()
        db.session.commit()
        return f"END ✅ Cleared {count} old notifications."
    except Exception as e:
        db.session.rollback()
        logger.error(f"Clear notifications error: {str(e)}")
        return "END Error clearing notifications."

def handle_notification_details(user, input_list):
    """Show notification details"""
    try:
        notif_index = int(input_list[2]) - 1
        
        if input_list[1] == '1':  # Unread notifications
            notifications = Notification.query.filter_by(
                user_id=user.id, read=False
            ).order_by(Notification.created_at.desc()).limit(10).all()
        else:  # All notifications
            notifications = Notification.query.filter_by(
                user_id=user.id
            ).order_by(Notification.created_at.desc()).limit(10).all()
        
        if 0 <= notif_index < len(notifications):
            notification = notifications[notif_index]
            # Mark as read
            notification.read = True
            db.session.commit()
            
            date_str = notification.created_at.strftime('%d %b %H:%M')
            type_emoji = get_notification_emoji(notification.notification_type)
            
            return f"CON {type_emoji} Notification\n{date_str}\n\n{notification.message}\n\n0. Back"
        else:
            return "END Invalid notification selection."
            
    except (ValueError, IndexError):
        return "END Invalid selection."

def get_notification_emoji(notification_type):
    """Get emoji for notification type"""
    emojis = {
        'cycle': '🔄',
        'appointment': '📅',
        'nutrition': '🍽️',
        'education': '📚',
        'family': '👨‍👩‍👧',
        'welcome': '🌸',
        'reminder': '⏰',
        'health': '❤️'
    }
    return emojis.get(notification_type, '📢')

def handle_parent_dashboard(user, input_list):
    """Enhanced parent dashboard with comprehensive child management"""
    parent = Parent.query.filter_by(user_id=user.id).first()
    if not parent:
        return "END Parent profile not found"
    
    steps = len(input_list)
    
    # Check for backflow navigation
    backflow_result = check_backflow_navigation(user, input_list, steps, 'parent_dashboard')
    if backflow_result:
        return backflow_result
    
    if steps == 1:
        children_count = ParentChild.query.filter_by(parent_id=parent.id).count()
        return (f"CON 👨‍👩‍👧 Parent Dashboard ({children_count} children):\n"
                "1. View Children\n2. Add Child\n3. Remove Child\n"
                "4. Child Health Summary\n0. Back\n00. Main Menu")
    
    elif steps == 2:
        selection = input_list[1]
        
        if selection == '1':
            return handle_view_children(parent, input_list)
        elif selection == '2':
            return handle_add_child(parent, input_list)
        elif selection == '3':
            return handle_remove_child(parent, input_list)
        elif selection == '4':
            return handle_child_health_summary(parent)
        elif selection == '0':
            return main_menu(user)
        else:
            return "END Invalid selection."
    
    # Handle subsequent steps for each option
    elif steps >= 3:
        if input_list[1] == '1':
            return handle_view_children(parent, input_list)
        elif input_list[1] == '2':
            return handle_add_child(parent, input_list)
        elif input_list[1] == '3':
            return handle_remove_child(parent, input_list)
    
    return main_menu(user)

def handle_view_children(parent, input_list):
    """View children with detailed information"""
    children = ParentChild.query.filter_by(parent_id=parent.id).all()
    
    if len(input_list) == 2:
        if not children:
            return "END No children linked to your account."
        
        response = "CON 👶 Your Children:\n"
        for idx, relation in enumerate(children, 1):
            try:
                adolescent = Adolescent.query.get(relation.adolescent_id)
                child_user = User.query.get(adolescent.user_id)
                response += f"{idx}. {child_user.name} ({relation.relationship_type})\n"
            except AttributeError:
                response += f"{idx}. Unknown child\n"
        
        response += "Select to view details\n0. Back\n00. Main Menu"
        return response
    
    elif len(input_list) == 3:
        try:
            child_index = int(input_list[2]) - 1
            if input_list[2] == '0':
                return handle_parent_dashboard(parent.user, input_list[:1])
            
            if 0 <= child_index < len(children):
                relation = children[child_index]
                adolescent = Adolescent.query.get(relation.adolescent_id)
                child_user = User.query.get(adolescent.user_id)
                
                # Get child's recent activity
                recent_cycles = CycleLog.query.filter_by(user_id=child_user.id).count()
                recent_meals = MealLog.query.filter_by(user_id=child_user.id).filter(
                    MealLog.meal_time >= datetime.now() - timedelta(days=7)
                ).count()
                
                response = f"CON 👤 {child_user.name}\n"
                response += f"Relationship: {relation.relationship_type}\n"
                response += f"Cycles tracked: {recent_cycles}\n"
                response += f"Meals this week: {recent_meals}\n"
                response += "0. Back\n00. Main Menu"
                
                return response
            else:
                return "END Invalid selection."
                
        except (ValueError, IndexError, AttributeError):
            return "END Invalid selection."
    
    return handle_parent_dashboard(parent.user, input_list[:1])

def handle_add_child(parent, input_list):
    """Enhanced child addition with validation"""
    steps = len(input_list)
    
    if steps == 2:
        return "CON Add Child\nEnter child's phone number\n(Must be registered adolescent):\n0. Back\n00. Main Menu"
    
    elif steps == 3:
        phone = input_list[2].strip()
        
        # Enhanced phone validation
        if not re.match(r'^\+?[\d\s\-\(\)]{10,15}$', phone):
            return "END Invalid phone format. Use international format."
        
        # Clean phone number
        cleaned_phone = re.sub(r'[\s\-\(\)]', '', phone)
        
        # Check if adolescent exists
        child_user = User.query.filter_by(phone_number=cleaned_phone, user_type='adolescent').first()
        if not child_user:
            return "END No adolescent account found with this number."
        
        # Check if already linked
        existing = ParentChild.query.join(Adolescent).filter(
            ParentChild.parent_id == parent.id,
            Adolescent.user_id == child_user.id
        ).first()
        
        if existing:
            return "END This child is already linked to your account."
        
        return ("CON Select your relationship:\n1. Mother\n2. Father\n"
                "3. Guardian\n4. Other Family\n0. Cancel\n00. Main Menu")
    
    elif steps == 4:
        if input_list[3] == '0':
            return handle_parent_dashboard(parent.user, input_list[:1])
        
        relationship_map = {
            '1': 'Mother',
            '2': 'Father', 
            '3': 'Guardian',
            '4': 'Other Family'
        }
        
        relationship = relationship_map.get(input_list[3])
        if not relationship:
            return "END Invalid relationship selection."
        
        # Get child user again
        phone = re.sub(r'[\s\-\(\)]', '', input_list[2])
        child_user = User.query.filter_by(phone_number=phone, user_type='adolescent').first()
        
        if not child_user:
            return "END Child user not found."
        
        try:
            adolescent = Adolescent.query.filter_by(user_id=child_user.id).first()
            
            # Create parent-child relationship
            new_relation = ParentChild(
                parent_id=parent.id,
                adolescent_id=adolescent.id,
                relationship_type=relationship
            )
            db.session.add(new_relation)
            
            # Send notification to adolescent
            notification = Notification(
                user_id=child_user.id,
                message=f"{parent.user.name} has been added as your {relationship}. They can now view your health progress.",
                notification_type='family'
            )
            db.session.add(notification)
            
            # Send confirmation to parent
            parent_notification = Notification(
                user_id=parent.user.id,
                message=f"Successfully linked {child_user.name} as your child.",
                notification_type='family'
            )
            db.session.add(parent_notification)
            
            db.session.commit()
            return f"END ✅ {child_user.name} added successfully as your child!"
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Add child error: {str(e)}")
            return "END Error adding child. Please try again."
    
    return "END Invalid flow."

def handle_remove_child(parent, input_list):
    """Enhanced child removal with confirmation"""
    children = ParentChild.query.filter_by(parent_id=parent.id).all()
    
    if len(input_list) == 2:
        if not children:
            return "END No children to remove."
        
        response = "CON ⚠️ Remove Child:\n"
        for idx, relation in enumerate(children, 1):
            try:
                adolescent = Adolescent.query.get(relation.adolescent_id)
                child_user = User.query.get(adolescent.user_id)
                response += f"{idx}. {child_user.name}\n"
            except AttributeError:
                response += f"{idx}. Unknown child\n"
        
        response += "0. Cancel\n00. Main Menu"
        return response
    
    elif len(input_list) == 3:
        if input_list[2] == '0':
            return handle_parent_dashboard(parent.user, input_list[:1])
        
        try:
            selection = int(input_list[2]) - 1
            if 0 <= selection < len(children):
                relation = children[selection]
                adolescent = Adolescent.query.get(relation.adolescent_id)
                child_user = User.query.get(adolescent.user_id)
                
                return f"CON Confirm removal of {child_user.name}?\n1. Yes, remove\n0. Cancel\n00. Main Menu"
            else:
                return "END Invalid selection."
                
        except (ValueError, IndexError, AttributeError):
            return "END Invalid selection."
    
    elif len(input_list) == 4:
        if input_list[3] == '1':  # Confirm removal
            try:
                selection = int(input_list[2]) - 1
                relation = children[selection]
                adolescent = Adolescent.query.get(relation.adolescent_id)
                child_user = User.query.get(adolescent.user_id)
                
                # Send notification to child
                notification = Notification(
                    user_id=child_user.id,
                    message=f"{parent.user.name} is no longer linked as your {relation.relationship_type}.",
                    notification_type='family'
                )
                db.session.add(notification)
                
                # Remove relationship
                db.session.delete(relation)
                db.session.commit()
                
                return f"END ✅ {child_user.name} removed successfully."
                
            except Exception as e:
                db.session.rollback()
                logger.error(f"Remove child error: {str(e)}")
                return "END Error removing child."
        else:
            return handle_parent_dashboard(parent.user, input_list[:1])
    
    return "END Invalid flow."

def handle_child_health_summary(parent):
    """Provide health summary for all children"""
    try:
        children = ParentChild.query.filter_by(parent_id=parent.id).all()
        
        if not children:
            return "END No children linked to view health summary."
        
        response = "CON 📊 Children's Health Summary:\n"
        
        for relation in children:
            adolescent = Adolescent.query.get(relation.adolescent_id)
            child_user = User.query.get(adolescent.user_id)
            
            # Get recent health data
            recent_cycles = CycleLog.query.filter_by(user_id=child_user.id).filter(
                CycleLog.start_date >= datetime.now() - timedelta(days=90)
            ).count()
            
            recent_meals = MealLog.query.filter_by(user_id=child_user.id).filter(
                MealLog.meal_time >= datetime.now() - timedelta(days=7)
            ).count()
            
            pending_appointments = Appointment.query.filter_by(
                user_id=child_user.id, status='pending'
            ).count()
            
            response += f"\n{child_user.name}:\n"
            response += f"Cycles (3mo): {recent_cycles}\n"
            response += f"Meals (7d): {recent_meals}\n"
            response += f"Pending appointments: {pending_appointments}\n"
        
        response += "\n0. Back"
        return response
        
    except Exception as e:
        logger.error(f"Child health summary error: {str(e)}")
        return "END Error retrieving health summary."

def handle_meal_logging(user, input_list):
    """Enhanced meal logging with nutritional tracking and backflow navigation"""
    steps = len(input_list)
    
    # Check for backflow navigation
    backflow_result = check_backflow_navigation(user, input_list, steps, 'meal_logging')
    if backflow_result:
        return backflow_result
    
    if steps == 1:
        return ("CON 🍽️ Meal Logging:\n1. Log New Meal\n2. Today's Meals\n"
                "3. Weekly Summary\n4. Nutrition Tips\n\n0. Back\n00. Main Menu")
    
    elif steps == 2:
        selection = input_list[1]
        
        if selection == '1':
            return ("CON Select meal type:\n1. Breakfast\n2. Lunch\n"
                   "3. Dinner\n4. Snack\n\n0. Back\n00. Main Menu")
        
        elif selection == '2':
            return get_todays_meals(user)
        
        elif selection == '3':
            return get_weekly_meal_summary(user)
        
        elif selection == '4':
            return get_nutrition_tips(user)
        
        else:
            return "END Invalid selection. Try again."
    
    elif steps == 3 and input_list[1] == '1':
        meal_types = {'1': 'breakfast', '2': 'lunch', '3': 'dinner', '4': 'snack'}
        if input_list[2] in meal_types:
            return ("CON Describe your meal:\n(e.g., Rice, beans, vegetables)\n\n"
                   "0. Back\n00. Main Menu")
        else:
            return "END Invalid meal type. Try again."
    
    elif steps == 4 and input_list[1] == '1':
        return handle_meal_entry(user, input_list)
    
    return "END Invalid flow. Please start again."

def handle_meal_entry(user, input_list):
    """Handle meal entry with basic nutritional estimation"""
    try:
        meal_types = {'1': 'breakfast', '2': 'lunch', '3': 'dinner', '4': 'snack'}
        meal_type = meal_types[input_list[2]]
        description = input_list[3].strip()
        
        if len(description) < 3:
            return "END Meal description too short."
        
        # Basic calorie estimation (this could be enhanced with a nutrition API)
        estimated_calories = estimate_calories(description, meal_type)
        
        new_meal = MealLog(
            user_id=user.id,
            meal_type=meal_type,
            meal_time=datetime.now(),
            description=description,
            calories=estimated_calories
        )
        
        db.session.add(new_meal)
        
        # Create notification for meal tracking
        notification = Notification(
            user_id=user.id,
            message=f"{meal_type.title()} logged: {description} (~{estimated_calories} cal)",
            notification_type='nutrition'
        )
        db.session.add(notification)
        
        db.session.commit()
        return f"END ✅ {meal_type.title()} logged!\n{description}\nEst. {estimated_calories} calories"
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Meal logging error: {str(e)}")
        return "END Error logging meal."

def estimate_calories(description, meal_type):
    """Basic calorie estimation based on keywords"""
    # Simple keyword-based estimation
    high_cal_foods = ['rice', 'bread', 'pasta', 'oil', 'butter', 'meat', 'chicken', 'fish']
    med_cal_foods = ['beans', 'eggs', 'milk', 'cheese', 'potato']
    low_cal_foods = ['vegetables', 'fruits', 'salad', 'tomato', 'cucumber']
    
    description_lower = description.lower()
    base_calories = {'breakfast': 300, 'lunch': 500, 'dinner': 600, 'snack': 150}
    
    calorie_modifier = 0
    for food in high_cal_foods:
        if food in description_lower:
            calorie_modifier += 100
    for food in med_cal_foods:
        if food in description_lower:
            calorie_modifier += 50
    for food in low_cal_foods:
        if food in description_lower:
            calorie_modifier += 25
    
    return base_calories.get(meal_type, 400) + calorie_modifier

def get_todays_meals(user):
    """Get today's meal summary"""
    today = datetime.now().date()
    meals = MealLog.query.filter_by(user_id=user.id).filter(
        db.func.date(MealLog.meal_time) == today
    ).order_by(MealLog.meal_time).all()
    
    if not meals:
        return "END No meals logged today."
    
    response = "CON 📋 Today's Meals:\n"
    total_calories = 0
    
    for meal in meals:
        time_str = meal.meal_time.strftime('%H:%M')
        calories = meal.calories or 0
        total_calories += calories
        response += f"{meal.meal_type.title()} ({time_str}): {calories}cal\n"
    
    response += f"\nTotal: {total_calories} calories\n0. Back"
    return response

def get_weekly_meal_summary(user):
    """Get weekly meal summary"""
    week_ago = datetime.now() - timedelta(days=7)
    meals = MealLog.query.filter_by(user_id=user.id).filter(
        MealLog.meal_time >= week_ago
    ).all()
    
    if not meals:
        return "END No meals logged this week."
    
    # Calculate daily averages
    total_calories = sum(meal.calories or 0 for meal in meals)
    daily_avg = total_calories / 7
    meal_count = len(meals)
    
    response = f"CON 📊 Weekly Summary:\nMeals logged: {meal_count}\n"
    response += f"Total calories: {total_calories}\n"
    response += f"Daily average: {daily_avg:.0f} cal\n"
    response += "0. Back"
    
    return response

def get_nutrition_tips(user):
    """Provide personalized nutrition tips"""
    tips = [
        "🥗 Include vegetables in every meal",
        "💧 Drink 8-10 glasses of water daily",
        "🥜 Add protein to maintain energy",
        "🍎 Choose whole fruits over juices",
        "🥖 Opt for whole grains when possible",
        "🐟 Include fish twice a week",
        "🥛 Don't skip dairy or alternatives"
    ]
    
    # Get a tip based on recent meal patterns
    recent_meals = MealLog.query.filter_by(user_id=user.id).filter(
        MealLog.meal_time >= datetime.now() - timedelta(days=3)
    ).all()
    
    import random
    tip = random.choice(tips)
    
    response = f"CON 💡 Nutrition Tip:\n{tip}\n\n"
    
    if len(recent_meals) < 6:
        response += "Log more meals for personalized tips!\n"
    
    response += "0. Back"
    return response

def handle_appointments(user, input_list):
    """Enhanced appointment management with backflow navigation"""
    steps = len(input_list)
    
    # Check for backflow navigation
    backflow_result = check_backflow_navigation(user, input_list, steps, 'appointments')
    if backflow_result:
        return backflow_result
    
    if steps == 1:
        return ("CON 📅 Appointments:\n1. Book New Appointment\n2. View Appointments\n"
                "3. Cancel Appointment\n4. Appointment Reminders\n\n0. Back\n00. Main Menu")
    
    elif steps == 2:
        selection = input_list[1]
        
        if selection == '1':
            if user.user_type == 'parent':
                return ("CON Book appointment for:\n1. Myself\n2. My Child\n\n"
                       "0. Back\n00. Main Menu")
            else:
                return ("CON Describe your health concern:\n\n"
                       "0. Back\n00. Main Menu")
        
        elif selection == '2':
            return get_user_appointments(user)
        
        elif selection == '3':
            return cancel_appointment_menu(user)
        
        elif selection == '4':
            return get_appointment_reminders(user)
        
        else:
            return "END Invalid selection. Try again."
    
    elif steps == 3:
        if input_list[1] == '1':  # Booking flow
            if user.user_type == 'parent' and input_list[2] in ['1', '2']:
                return ("CON Describe the health concern:\n\n"
                       "0. Back\n00. Main Menu")
            elif user.user_type == 'adolescent':
                return handle_appointment_booking(user, input_list[2], 'self')
        
        elif input_list[1] == '3':  # Cancel flow
            return handle_appointment_cancellation(user, input_list[2])
    
    elif steps == 4 and input_list[1] == '1':
        # Complete booking
        appointment_for = 'self' if input_list[2] == '1' else 'child'
        return handle_appointment_booking(user, input_list[3], appointment_for)
    
    return "END Invalid flow. Please start again."

def handle_appointment_booking(user, issue_description, appointment_for):
    """Handle appointment booking"""
    try:
        if len(issue_description.strip()) < 5:
            return "END Issue description too short. Please be more specific."
        
        # Create appointment with pending status
        new_appointment = Appointment(
            user_id=user.id,
            appointment_for=appointment_for,
            appointment_date=datetime.now() + timedelta(days=1),  # Default to tomorrow
            issue=issue_description.strip(),
            status='pending'
        )
        
        db.session.add(new_appointment)
        
        # Create notification
        notification = Notification(
            user_id=user.id,
            message=f"Appointment request submitted for {appointment_for}. Issue: {issue_description[:50]}...",
            notification_type='appointment'
        )
        db.session.add(notification)
        
        db.session.commit()
        
        return ("END ✅ Appointment requested!\nYou will receive a confirmation "
                "with date and time within 24 hours.")
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Appointment booking error: {str(e)}")
        return "END Error booking appointment. Please try again."

def get_user_appointments(user):
    """Get user's appointments"""
    appointments = Appointment.query.filter_by(user_id=user.id).order_by(
        Appointment.appointment_date.desc()
    ).limit(5).all()
    
    if not appointments:
        return "END No appointments found."
    
    response = "CON 📋 Your Appointments:\n"
    for idx, apt in enumerate(appointments, 1):
        status_emoji = {"pending": "⏳", "confirmed": "✅", "cancelled": "❌"}
        emoji = status_emoji.get(apt.status, "❓")
        
        date_str = apt.appointment_date.strftime('%d %b')
        response += f"{idx}. {date_str} - {apt.appointment_for} {emoji}\n"
    
    response += "0. Back"
    return response

def cancel_appointment_menu(user):
    """Show cancellable appointments"""
    appointments = Appointment.query.filter_by(
        user_id=user.id, status='pending'
    ).order_by(Appointment.appointment_date).all()
    
    if not appointments:
        return "END No pending appointments to cancel."
    
    response = "CON Select appointment to cancel:\n"
    for idx, apt in enumerate(appointments, 1):
        date_str = apt.appointment_date.strftime('%d %b')
        response += f"{idx}. {date_str} - {apt.appointment_for}\n"
    
    response += "0. Back"
    return response

def handle_appointment_cancellation(user, selection):
    """Handle appointment cancellation"""
    try:
        apt_index = int(selection) - 1
        appointments = Appointment.query.filter_by(
            user_id=user.id, status='pending'
        ).order_by(Appointment.appointment_date).all()
        
        if 0 <= apt_index < len(appointments):
            appointment = appointments[apt_index]
            appointment.status = 'cancelled'
            
            # Create notification
            notification = Notification(
                user_id=user.id,
                message=f"Appointment for {appointment.appointment_for} on {appointment.appointment_date.strftime('%d %b')} has been cancelled.",
                notification_type='appointment'
            )
            db.session.add(notification)
            
            db.session.commit()
            return "END ✅ Appointment cancelled successfully."
        else:
            return "END Invalid selection."
            
    except (ValueError, IndexError):
        return "END Invalid selection."
    except Exception as e:
        db.session.rollback()
        logger.error(f"Appointment cancellation error: {str(e)}")
        return "END Error cancelling appointment."

def get_appointment_reminders(user):
    """Get upcoming appointment reminders"""
    upcoming = Appointment.query.filter_by(
        user_id=user.id, status='confirmed'
    ).filter(
        Appointment.appointment_date >= datetime.now()
    ).order_by(Appointment.appointment_date).limit(3).all()
    
    if not upcoming:
        return "END No upcoming confirmed appointments."
    
    response = "CON 🔔 Upcoming Appointments:\n"
    for apt in upcoming:
        days_until = (apt.appointment_date - datetime.now()).days
        date_str = apt.appointment_date.strftime('%d %b %Y')
        response += f"• {date_str} ({days_until}d) - {apt.appointment_for}\n"
    
    response += "0. Back"
    return response

def handle_settings(user, input_list):
    """Enhanced settings and profile management"""
    steps = len(input_list)
    
    # Check for backflow navigation
    backflow_result = check_backflow_navigation(user, input_list, steps, 'settings')
    if backflow_result:
        return backflow_result
    
    if steps == 1:
        return ("CON ⚙️ Settings:\n1. Change PIN\n2. Update Profile\n"
                "3. Notification Settings\n4. Data Export\n5. Delete Account\n"
                "0. Back\n00. Main Menu")
    
    elif steps == 2:
        selection = input_list[1]
        
        if selection == '1':
            return "CON Change PIN\nEnter current PIN:\n0. Back\n00. Main Menu"
        elif selection == '2':
            return "CON Update Profile\nEnter new name:\n0. Back\n00. Main Menu"
        elif selection == '3':
            return handle_notification_settings(user)
        elif selection == '4':
            return export_user_data(user)
        elif selection == '5':
            return "CON ⚠️ Delete Account\nThis action cannot be undone!\n1. Confirm\n0. Cancel\n00. Main Menu"
        elif selection == '0':
            return main_menu(user)
        else:
            return "END Invalid selection."
    
    elif steps == 3:
        if input_list[1] == '1':  # Change PIN - verify current
            if bcrypt.check_password_hash(user.password_hash, input_list[2]):
                return "CON Enter new 4-digit PIN:\n0. Back\n00. Main Menu"
            else:
                return "END Incorrect current PIN."
        
        elif input_list[1] == '2':  # Update name
            return handle_name_update(user, input_list[2])
        
        elif input_list[1] == '5' and input_list[2] == '1':  # Confirm deletion
            return handle_account_deletion(user)
    
    elif steps == 4 and input_list[1] == '1':  # Complete PIN change
        return handle_pin_change(user, input_list[3])
    
    return "END Invalid flow."

def handle_pin_change(user, new_pin):
    """Handle PIN change"""
    try:
        if len(new_pin) != 4 or not new_pin.isdigit():
            return "END New PIN must be exactly 4 digits."
        
        user.password_hash = bcrypt.generate_password_hash(new_pin).decode('utf-8')
        user.updated_at = datetime.now()
        
        # Create notification
        notification = Notification(
            user_id=user.id,
            message="Your PIN has been changed successfully.",
            notification_type='security'
        )
        db.session.add(notification)
        
        db.session.commit()
        return "END ✅ PIN changed successfully!"
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"PIN change error: {str(e)}")
        return "END Error changing PIN."

def handle_name_update(user, new_name):
    """Handle name update"""
    try:
        new_name = new_name.strip()
        if len(new_name) < 2:
            return "END Name too short. Minimum 2 characters."
        elif len(new_name) > 50:
            return "END Name too long. Maximum 50 characters."
        
        old_name = user.name
        user.name = new_name
        user.updated_at = datetime.now()
        
        # Create notification
        notification = Notification(
            user_id=user.id,
            message=f"Profile updated: Name changed from {old_name} to {new_name}",
            notification_type='profile'
        )
        db.session.add(notification)
        
        db.session.commit()
        return f"END ✅ Name updated to {new_name}!"
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Name update error: {str(e)}")
        return "END Error updating name."

def handle_notification_settings(user):
    """Handle notification preferences"""
    # This could be expanded to include actual notification preferences
    return ("CON 🔔 Notification Settings:\n"
            "All notifications are currently enabled.\n"
            "Contact support to customize.\n0. Back\n00. Main Menu")

def export_user_data(user):
    """Provide data export summary"""
    try:
        # Count user data
        cycles = CycleLog.query.filter_by(user_id=user.id).count()
        meals = MealLog.query.filter_by(user_id=user.id).count()
        appointments = Appointment.query.filter_by(user_id=user.id).count()
        notifications = Notification.query.filter_by(user_id=user.id).count()
        
        response = f"CON 📊 Your Data Summary:\n"
        response += f"Cycles logged: {cycles}\n"
        response += f"Meals logged: {meals}\n"
        response += f"Appointments: {appointments}\n"
        response += f"Notifications: {notifications}\n"
        response += "Contact support for full export.\n0. Back\n00. Main Menu"
        
        return response
        
    except Exception as e:
        logger.error(f"Data export error: {str(e)}")
        return "END Error retrieving data summary."

def handle_account_deletion(user):
    """Handle account deletion (soft delete by deactivating)"""
    try:
        # Instead of actual deletion, we could mark as inactive
        # For this demo, we'll show a message
        return ("END ⚠️ Account deletion requires manual verification.\n"
                "Please contact support to proceed with account deletion.")
        
    except Exception as e:
        logger.error(f"Account deletion error: {str(e)}")
        return "END Error processing deletion request."

# Additional USSD enhancements

def get_emergency_contacts():
    """Return emergency contact information"""
    return """🚨 Emergency Contacts:
• Emergency: 911
• Women's Health Hotline: 1-800-WOMEN
• Sexual Health Info: 1-800-SEX-INFO
• Mental Health Crisis: 988

For serious health concerns, please contact a healthcare provider immediately."""

def handle_health_emergency():
    """Handle health emergency requests"""
    return f"END {get_emergency_contacts()}"

def handle_quick_actions(user, input_list):
    """Handle quick action shortcuts"""
    if len(input_list) < 2:
        return main_menu(user)
    
    action = input_list[1].lower()
    
    # Quick shortcuts
    shortcuts = {
        '911': handle_health_emergency,
        'emergency': handle_health_emergency,
        'help': lambda: get_help_menu(user),
        'status': lambda: get_quick_status(user)
    }
    
    if action in shortcuts:
        return shortcuts[action]()
    
    return main_menu(user)

def get_help_menu(user):
    """Comprehensive help menu"""
    return """CON 🆘 Help & Support:
1. How to use this service
2. Health emergency contacts
3. Technical support
4. Privacy information
5. Terms of service
0. Back to main menu"""

def get_quick_status(user):
    """Quick status overview"""
    try:
        # Get latest cycle info
        latest_cycle = CycleLog.query.filter_by(user_id=user.id).order_by(
            CycleLog.start_date.desc()
        ).first()
        
        # Get recent notifications
        unread_count = Notification.query.filter_by(user_id=user.id, read=False).count()
        
        # Get upcoming appointments
        upcoming_appointments = Appointment.query.filter_by(
            user_id=user.id, status='confirmed'
        ).filter(
            Appointment.appointment_date >= datetime.now()
        ).count()
        
        status = f"CON 📊 Quick Status - {user.name}:\n"
        
        if latest_cycle:
            if not latest_cycle.end_date:
                days_active = (datetime.now() - latest_cycle.start_date).days + 1
                status += f"Period: Day {days_active} (active)\n"
            else:
                days_since = (datetime.now() - latest_cycle.end_date).days
                status += f"Last period: {days_since} days ago\n"
        else:
            status += "No cycle data available\n"
        
        status += f"Unread notifications: {unread_count}\n"
        status += f"Upcoming appointments: {upcoming_appointments}\n"
        status += "0. Back"
        
        return status
        
    except Exception as e:
        logger.error(f"Quick status error: {str(e)}")
        return "END Error retrieving status."

def handle_feedback_submission(user, input_list):
    """Handle user feedback submission"""
    steps = len(input_list)
    
    # Check for backflow navigation
    backflow_result = check_backflow_navigation(user, input_list, steps, 'feedback')
    if backflow_result:
        return backflow_result
    
    if steps == 1:
        return ("CON 💬 Send Feedback:\n1. Report a Bug\n2. Suggest Feature\n"
                "3. General Feedback\n4. Rate Service\n0. Back\n00. Main Menu")
    
    elif steps == 2:
        feedback_types = {
            '1': 'bug',
            '2': 'feature',
            '3': 'general',
            '4': 'rating'
        }
        
        if input_list[1] in feedback_types:
            if input_list[1] == '4':
                return "CON Rate our service (1-5):\n1. Poor\n2. Fair\n3. Good\n4. Very Good\n5. Excellent\n0. Back\n00. Main Menu"
            else:
                return "CON Please describe your feedback\n(Keep it brief for USSD):\n0. Back\n00. Main Menu"
        elif input_list[1] == '0':
            return main_menu(user)
        else:
            return "END Invalid selection."
    
    elif steps == 3:
        try:
            if input_list[1] == '4':  # Rating
                rating = int(input_list[2])
                if 1 <= rating <= 5:
                    feedback_text = f"Service rating: {rating}/5"
                else:
                    return "END Invalid rating. Use 1-5."
            else:
                feedback_text = input_list[2].strip()
                if len(feedback_text) < 5:
                    return "END Feedback too short. Please be more specific."
            
            feedback_types = {'1': 'bug', '2': 'feature', '3': 'general', '4': 'rating'}
            feedback_type = feedback_types[input_list[1]]
            
            # Create feedback record
            feedback = Feedback(
                user_id=user.id,
                feedback_type=feedback_type,
                message=feedback_text,
                status='pending'
            )
            db.session.add(feedback)
            
            # Create notification for user
            notification = Notification(
                user_id=user.id,
                message=f"Thank you for your {feedback_type} feedback. We'll review it soon!",
                notification_type='feedback'
            )
            db.session.add(notification)
            
            db.session.commit()
            return "END ✅ Thank you for your feedback! We appreciate your input."
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Feedback submission error: {str(e)}")
            return "END Error submitting feedback. Please try again."
    
    return "END Invalid feedback flow."

# Enhanced main menu with additional options
def enhanced_main_menu(user):
    """Enhanced main menu with quick actions and better organization"""
    unread_notifications = Notification.query.filter_by(user_id=user.id, read=False).count()
    notification_indicator = f" ({unread_notifications})" if unread_notifications > 0 else ""
    
    menu = f"CON 🌸 The Lady's Essence - {user.name}\n"
    menu += "━━━━━━━━━━━━━━━━━━━━\n"
    menu += "1. 🔄 Cycle Tracking\n"
    menu += "2. 🍽️ Meal Logging\n"
    menu += "3. 📅 Appointments\n"
    menu += "4. 📚 Health Education\n"
    menu += f"5. 🔔 Notifications{notification_indicator}\n"
    
    if user.user_type == 'parent':
        children_count = ParentChild.query.join(Parent).filter(Parent.user_id == user.id).count()
        menu += f"6. 👨‍👩‍👧 Parent Dashboard ({children_count})\n"
    
    menu += "7. ⚙️ Settings\n"
    menu += "8. 💬 Send Feedback\n"
    menu += "9. 🆘 Help\n"
    menu += "0. Exit"
    
    return menu