import React from 'react';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend 
} from 'recharts';

interface NutritionDonutProps {
  protein?: number;
  carbs?: number;
  fats?: number;
}

export const NutritionDonut: React.FC<NutritionDonutProps> = ({
  protein = 12,
  carbs = 45,
  fats = 10,
}) => {
  const data = [
    { name: 'Protein (Sage)', value: protein || 1, color: '#8FAF8A' },
    { name: 'Carbs (Terracotta)', value: carbs || 1, color: '#C4785A' },
    { name: 'Fats (Mauve)', value: fats || 1, color: '#7A4F6D' }
  ];

  const total = protein + carbs + fats || 1;
  const isZero = protein === 0 && carbs === 0 && fats === 0;

  const demoData = [
    { name: 'Protein (Sage)', value: 15, color: '#8FAF8A' },
    { name: 'Carbs (Terracotta)', value: 50, color: '#C4785A' },
    { name: 'Fats (Mauve)', value: 10, color: '#7A4F6D' }
  ];

  return (
    <div className="w-full font-sans select-none flex flex-col items-center">
      <div className="w-full h-48 relative">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={isZero ? demoData : data}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={70}
              paddingAngle={4}
              dataKey="value"
            >
              {(isZero ? demoData : data).map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.color} 
                  opacity={isZero ? 0.35 : 1}
                />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: '#FDFAF6',
                border: '1px solid #E8DDD4',
                borderRadius: '8px',
                fontFamily: 'DM Sans',
                fontSize: '12px'
              }}
            />
          </PieChart>
        </ResponsiveContainer>

        {/* Central calorie or macro summary overlay */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-[11px] font-semibold text-muted tracking-wider uppercase">Macros</span>
          <span className="text-xl font-extrabold font-heading text-ink">{total}g</span>
          <span className="text-[9px] text-muted">Intake</span>
        </div>
      </div>

      {/* Structured Legend for manual responsive sizing */}
      <div className="flex justify-center gap-4 mt-1 text-xs font-semibold">
        {data.map((item, index) => (
          <div key={index} className="flex items-center gap-1.5 text-muted">
            <span 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: item.color }} 
            />
            <span>
              {item.name.split(' ')[0]}:{' '}
              <strong className="text-ink">
                {isZero ? 0 : item.value}g
              </strong>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
export default NutritionDonut;
