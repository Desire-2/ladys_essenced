import React, { useState, useEffect } from 'react';
import toast, { Toaster } from 'react-hot-toast';
import { 
  Heart, Utensils, CalendarDays, Bell, Settings, 
  Users, ShieldAlert, BookOpen, Clock, AlertTriangle, 
  Search, Lock, Phone, User, Check, Eye, HelpCircle, 
  FileText, Plus, CheckCircle, RefreshCcw, ThumbsUp, Trash2,
  Sparkles, Apple
} from 'lucide-react';

import { formatDateTime } from './lib/utils';
import { useAuthStore } from './stores/authStore';
import { api } from './lib/axios';
import { 
  User as UserType, CycleLog, MealLog, Appointment, 
  Notification, ContentItem, Course, Child, SystemLog, 
  ProviderAvailability 
} from './types';

// UI components
import { Button } from './components/ui/Button';
import { Input } from './components/ui/Input';
import { Card } from './components/ui/Card';
import { Badge } from './components/ui/Badge';
import { Modal } from './components/ui/Modal';
import { Avatar } from './components/ui/Avatar';
import { Spinner } from './components/ui/Spinner';
import { EmptyState } from './components/ui/EmptyState';

// Layout
import { DashboardLayout } from './components/layout/DashboardLayout';

// Features
import { CycleRing } from './components/features/CycleRing';
import { CycleCalendar } from './components/features/CycleCalendar';
import { NutritionDonut } from './components/features/NutritionDonut';
import { AppointmentCard } from './components/features/AppointmentCard';
import { ChildCard } from './components/features/ChildCard';
import { InsightCard } from './components/features/InsightCard';

// Forms
import { CycleLogForm } from './components/forms/CycleLogForm';
import { MealLogForm } from './components/forms/MealLogForm';
import { AppointmentForm } from './components/forms/AppointmentForm';
import { ChildForm } from './components/forms/ChildForm';

// Umwari AI Companion Components & Stores
import { useUmwariStore } from './stores/umwariStore';
import { UmwariLanguagePicker } from './components/umwari/UmwariLanguagePicker';
import { UmwariFab } from './components/umwari/UmwariFab';
import { UmwariChat } from './components/umwari/UmwariChat';
import { UmwariFullPage } from './components/umwari/UmwariFullPage';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { EyeOff } from 'lucide-react';

export default function App() {
  const { user, accessToken, setUser, setAccessToken, logout } = useAuthStore();
  const umwariStore = useUmwariStore();
  
  // Custom SPA Hash Router
  const [currentPath, setCurrentPath] = useState('/login');

  useEffect(() => {
    const handlePopState = () => {
      const hash = window.location.hash.replace('#', '');
      setCurrentPath(hash || '/login');
    };
    window.addEventListener('popstate', handlePopState);
    
    const initialHash = window.location.hash.replace('#', '');
    if (initialHash) {
      setCurrentPath(initialHash);
    } else {
      window.location.hash = '/login';
    }
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    setCurrentPath(path);
    window.location.hash = path;
  };

  // Auth Profile sync
  useEffect(() => {
    const storedToken = localStorage.getItem('refresh_token');
    if (storedToken && !accessToken) {
      // Simulate silent resume profile
      api.get<UserType>('/auth/profile')
        .then(res => {
          setAccessToken(`user_id-${res.data.id}`);
          setUser(res.data);
          
          // Role matching route redirect on resume
          if (res.data.user_type === 'parent') navigate('/dashboard/parent');
          else if (res.data.user_type === 'health_provider') navigate('/dashboard/provider');
          else if (res.data.user_type === 'admin') navigate('/dashboard/admin');
          else if (res.data.user_type === 'content_writer') navigate('/dashboard/writer');
          else navigate('/dashboard');
        })
        .catch(() => {
          localStorage.removeItem('refresh_token');
          navigate('/login');
        });
    } else if (!storedToken && currentPath !== '/login' && currentPath !== '/register') {
      navigate('/login');
    }
  }, [accessToken]);

  // Role Gate security
  const RoleRequired = ({ children, allowed }: { children: React.ReactNode; allowed: string[] }) => {
    if (!user) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[50vh] text-center font-sans">
          <Lock className="w-12 h-12 text-terracotta mb-4" />
          <h2 className="text-xl font-heading font-bold text-ink mb-1.5">Unauthenticated Session</h2>
          <p className="text-sm text-muted mb-4">You need to sign in to access this clinic dashboard.</p>
          <Button onClick={() => navigate('/login')}>Go to Sign In</Button>
        </div>
      );
    }

    if (!allowed.includes(user.user_type)) {
      return (
        <div className="p-8 bg-surface border border-border rounded-xl max-w-md mx-auto my-12 text-center font-sans space-y-4">
          <AlertTriangle className="w-12 h-12 text-mauve mx-auto" />
          <h2 className="text-lg font-bold font-heading text-ink text-center">Unauthorized Role Segment</h2>
          <p className="text-xs text-muted">Your account role is <strong>{user?.user_type.toUpperCase()}</strong>. This system view is protected.</p>
          <Button onClick={() => {
            if (user?.user_type === 'parent') navigate('/dashboard/parent');
            else if (user?.user_type === 'health_provider') navigate('/dashboard/provider');
            else if (user?.user_type === 'admin') navigate('/dashboard/admin');
            else if (user?.user_type === 'content_writer') navigate('/dashboard/writer');
            else navigate('/dashboard');
          }} className="w-full">
            Return to Authorized Dashboard
          </Button>
        </div>
      );
    }

    return <>{children}</>;
  };

  // ==========================================
  // PAGE COMPONENT 1: /login
  // ==========================================
  const LoginPage = () => {
    const [phoneNumber, setPhoneNumber] = useState('0788123456'); // Kezia uwase seeded phone
    const [password, setPassword] = useState('1234'); // PIN/Password
    const [isPinMode, setIsPinMode] = useState(true);
    const [rememberMe, setRememberMe] = useState(true);
    const [isLoading, setIsLoading] = useState(false);
    const [shakeError, setShakeError] = useState(false);

    const handleLogin = async (e: React.FormEvent) => {
      e.preventDefault();
      setIsLoading(true);
      setShakeError(false);
      try {
        const payload = isPinMode 
          ? { phone_number: phoneNumber, pin: password }
          : { phone_number: phoneNumber, password };

        const { data } = await api.post('/auth/login', payload);
        setAccessToken(data.access_token);
        setUser(data.user);
        localStorage.setItem('refresh_token', data.refresh_token);
        toast.success(`Welcome back, ${data.user.first_name}!`);

        // Navigate based on user type
        if (data.user_type === 'parent') navigate('/dashboard/parent');
        else if (data.user_type === 'health_provider') navigate('/dashboard/provider');
        else if (data.user_type === 'admin') navigate('/dashboard/admin');
        else if (data.user_type === 'content_writer') navigate('/dashboard/writer');
        else navigate('/dashboard');
      } catch (err: any) {
        setShakeError(true);
        toast.error(err.response?.data?.message || 'Login credentials incorrect. Try Kezia 0788123456 PIN 1234.');
      } finally {
        setIsLoading(false);
      }
    };

    return (
      <div className="flex min-h-screen bg-cream overflow-hidden">
        {/* Decorative left panel */}
        <div className="hidden lg:flex w-1/2 bg-[#7A4F6D] flex-col p-16 justify-between relative text-left overflow-hidden">
          {/* Organic Blobs */}
          <div className="absolute top-[-10%] left-[-10%] w-[400px] h-[400px] bg-[#C4785A] opacity-30 rounded-full blur-[80px]" />
          <div className="absolute bottom-[-15%] right-[-10%] w-[500px] h-[500px] bg-[#8FAF8A] opacity-20 rounded-full blur-[100px]" />
          
          <div className="flex items-center gap-4 relative z-10 select-none">
            <div className="w-12 h-12 bg-[#F5EDE0] rounded-full flex items-center justify-center shadow-lg">
              <div className="w-6 h-6 border-2 border-[#7A4F6D] rounded-full" />
            </div>
            <h1 className="text-4xl font-heading italic text-[#F5EDE0] leading-none tracking-tight">Lady's Essence</h1>
          </div>

          <div className="space-y-6 max-w-lg relative z-10 my-auto select-none">
            <h2 className="text-6xl font-heading text-[#F5EDE0] leading-[1.1] mb-6">
              Your health journey, <br />
              <span className="italic font-light">shared with love.</span>
            </h2>
            <p className="text-[#F5EDE0]/80 text-lg leading-relaxed font-sans">
              A safe, private, and nurturing space for adolescent girls and their families to navigate health and wellness in Rwanda.
            </p>
          </div>

          <div className="mt-12 flex gap-4 items-center relative z-10 select-none">
            <div className="flex -space-x-3">
              <div className="w-10 h-10 rounded-full border-2 border-[#7A4F6D] bg-[#C4785A]" />
              <div className="w-10 h-10 rounded-full border-2 border-[#7A4F6D] bg-[#8FAF8A]" />
              <div className="w-10 h-10 rounded-full border-2 border-[#7A4F6D] bg-[#E8DDD4]" />
            </div>
            <span className="text-[#F5EDE0]/60 text-sm font-sans tracking-wide">Empowering thousands of girls across East Africa</span>
          </div>
        </div>

        {/* Right card form panel */}
        <div className="w-full lg:w-1/2 flex items-center justify-center p-6 md:p-12 relative">
          <div className="organic-bg-blob lg:hidden w-72 h-72 bg-terracotta top-20 right-[-100px]" />
          
          <Card className={`max-w-md w-full p-8 space-y-7 bg-cream/40 backdrop-blur-md relative z-10 ${shakeError ? 'animate-[shake_0.4s_ease-in-out]' : ''}`}>
            {/* Header */}
            <div className="text-center space-y-1.5 select-none">
              <h2 className="text-2.5xl font-extrabold font-heading text-ink">Sign In • Injira</h2>
              <p className="text-xs text-muted font-normal max-w-[280px] mx-auto">
                Access your private cycle logs or manage clinic entries safely.
              </p>
            </div>

            {/* Quick Demo tips */}
            <div className="p-3 bg-cream/50 border border-border rounded-lg text-left select-none">
              <span className="text-[10px] uppercase font-bold text-terracotta">Demo Logins (Kugera ku mushinga):</span>
              <ul className="text-[10px] text-muted space-y-0.5 mt-1 list-disc pl-3">
                <li><strong>Adolescent:</strong> 0788123456 • PIN: 1234</li>
                <li><strong>Parent:</strong> 0788654321 • PIN/Pass: password123</li>
                <li><strong>Healthcare Provider:</strong> 0788998877 • Pass: doctor123</li>
                <li><strong>System Admin:</strong> 0788001122 • Pass: admin123</li>
              </ul>
            </div>

            {/* Login form */}
            <form onSubmit={handleLogin} className="space-y-4">
              <Input
                type="tel"
                label="Phone Number (Inomero ya terefone)"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                icon={<Phone className="w-4 h-4" />}
                placeholder="e.g. 0788123456"
                required
              />

              <div className="space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold uppercase text-muted tracking-wider">
                    {isPinMode ? '4-Digit PIN (Inomero ya PIN)' : 'Password (Ijambo ry’ibanga)'}
                  </span>
                  <button 
                    type="button" 
                    onClick={() => { setPassword(''); setIsPinMode(!isPinMode); }}
                    className="text-[11px] text-terracotta font-semibold hover:underline cursor-pointer"
                  >
                    Switch to {isPinMode ? 'Password' : 'PIN'}
                  </button>
                </div>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  icon={<Lock className="w-4 h-4" />}
                  placeholder={isPinMode ? 'e.g. 1234' : '••••••••'}
                  required
                />
              </div>

              <div className="flex items-center justify-between text-xs select-none">
                <label className="flex items-center gap-2 cursor-pointer font-medium text-muted">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded border-border text-terracotta focus:ring-terracotta"
                  />
                  <span>Remember me on this browser</span>
                </label>
              </div>

              <Button type="submit" isLoading={isLoading} className="w-full h-11 text-sm font-semibold mt-2">
                Sign In securely • Injira neza
              </Button>
            </form>

            <div className="text-center text-xs select-none pt-2 border-t border-border">
              <span className="text-muted font-medium">New to Lady's Essence? </span>
              <button 
                onClick={() => navigate('/register')}
                className="text-terracotta font-extrabold hover:underline cursor-pointer"
              >
                Create Account • Kwiyandikisha
              </button>
            </div>
          </Card>
        </div>
      </div>
    );
  };

  // ==========================================
  // PAGE COMPONENT 2: /register
  // ==========================================
  const RegisterPage = () => {
    const [step, setStep] = useState(1);
    const [userType, setUserType] = useState<UserType['user_type']>('adolescent');
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [email, setEmail] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleRegister = async (e: React.FormEvent) => {
      e.preventDefault();
      if (password !== confirmPassword) {
        toast.error('Passwords do not match.');
        return;
      }

      setIsLoading(true);
      try {
        const payload = {
          first_name: firstName,
          last_name: lastName,
          phone_number: phoneNumber,
          password,
          email: email || undefined,
          user_type: userType,
        };

        const { data } = await api.post('/auth/register', payload);
        setAccessToken(data.access_token);
        setUser(data.user);
        localStorage.setItem('refresh_token', data.refresh_token);
        toast.success(`Account registered! Welcome ${firstName}.`);

        if (userType === 'parent') navigate('/dashboard/parent');
        else if (userType === 'health_provider') navigate('/dashboard/provider');
        else if (userType === 'admin') navigate('/dashboard/admin');
        else if (userType === 'content_writer') navigate('/dashboard/writer');
        else navigate('/dashboard');
      } catch (err: any) {
        toast.error(err.response?.data?.message || 'Error occurred during registration.');
      } finally {
        setIsLoading(false);
      }
    };

    const rolesMap = [
      {
        type: 'adolescent' as const,
        title: 'I’m an Adolescent Girl',
        kinya: 'Ndi umukobwa ukiri muto',
        desc: 'Log cycle start dates securely, visual nutrient summaries, and speaks to Dr. Agnes in comfort.',
        icon: '🌸'
      },
      {
        type: 'parent' as const,
        title: 'I’m a Supportive Parent',
        kinya: 'Ndi umubyeyi',
        desc: 'Monitor linked daughter logs in a privacy-first layout, ensuring dignified hygiene guidance and care.',
        icon: '🤱'
      },
      {
        type: 'health_provider' as const,
        title: 'I’m a Healthcare Specialist',
        kinya: 'Ndi umuganga',
        desc: 'Manage teen consultations, claiming pending clinic schedules, and block slots.',
        icon: '🩺'
      },
      {
        type: 'content_writer' as const,
        title: 'I’m an Educational Writer',
        kinya: 'Ndi umwanditsi w’inyigisho',
        desc: 'Curate localized wellness content in Kinyarwanda & English to support safety and strength metrics.',
        icon: '✍️'
      }
    ];

    return (
      <div className="flex items-center justify-center min-h-screen bg-cream p-4">
        {/* Organic Background Blobs */}
        <div className="organic-bg-blob w-72 h-72 bg-terracotta top-[-50px] left-[-50px]" />
        <div className="organic-bg-blob w-80 h-80 bg-sage bottom-[-100px] right-[-100px]" />

        <Card className="max-w-xl w-full p-8 space-y-6 relative z-10 bg-cream/40 backdrop-blur-md">
          {/* Progress dots bar */}
          <div className="flex items-center justify-between pb-3 border-b border-border select-none">
            <span className="text-xs font-bold text-muted uppercase tracking-wider"> Kwiyandikisha • Register</span>
            <div className="flex gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${step >= 1 ? 'bg-terracotta' : 'bg-border'}`} />
              <span className={`w-2.5 h-2.5 rounded-full ${step >= 2 ? 'bg-terracotta' : 'bg-border'}`} />
              <span className={`w-2.5 h-2.5 rounded-full ${step >= 3 ? 'bg-terracotta' : 'bg-border'}`} />
            </div>
          </div>

          {step === 1 && (
            <div className="space-y-5 animate-[fadeInUp_0.2s_ease-out]">
              <div className="text-center select-none">
                <h3 className="text-xl font-bold font-heading text-ink">Choose Your Access Role</h3>
                <p className="text-xs text-muted mt-1">Select the option that mirrors your health journey.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {rolesMap.map((r) => (
                  <button
                    key={r.type}
                    onClick={() => setUserType(r.type)}
                    className={`p-4 rounded-xl border text-left cursor-pointer transition-all relative overflow-hidden ${
                      userType === r.type
                        ? 'border-terracotta bg-terracotta/5 ring-1 ring-terracotta'
                        : 'border-border bg-surface hover:border-muted'
                    }`}
                  >
                    <div className="text-2xl mb-2">{r.icon}</div>
                    <p className="text-xs font-bold text-ink">{r.title}</p>
                    <p className="text-[10px] text-terracotta font-semibold leading-relaxed mt-0.5">{r.kinya}</p>
                    <p className="text-[11px] text-muted font-medium mt-1.5 leading-relaxed">{r.desc}</p>
                  </button>
                ))}
              </div>

              <div className="flex justify-end pt-2">
                <Button onClick={() => setStep(2)} className="h-11 px-6">Continue • Komeza →</Button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-5 animate-[fadeInUp_0.2s_ease-out] text-left">
              <div className="text-center select-none">
                <h3 className="text-xl font-bold font-heading text-ink">Your Personal Profile</h3>
                <p className="text-xs text-muted mt-1">Please write your human names exactly as preferred.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="First Name (Izina ryawe)"
                  placeholder="e.g. Kezia"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  icon={<User className="w-4 h-4" />}
                  required
                />
                <Input
                  label="Last Name (Izina ry’umuryango)"
                  placeholder="e.g. Uwase"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  icon={<User className="w-4 h-4" />}
                  required
                />
              </div>

              <Input
                label="Email Address - Optional (Imeri)"
                placeholder="e.g. uwase.kezia@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />

              <div className="flex justify-between pt-4">
                <Button variant="ghost" onClick={() => setStep(1)} className="h-11">← Back</Button>
                <Button 
                  onClick={() => {
                    if (!firstName || !lastName) {
                      toast.error('First and last name are required.');
                      return;
                    }
                    setStep(3);
                  }} 
                  className="h-11 px-6"
                >
                  Continue • Komeza →
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <form onSubmit={handleRegister} className="space-y-5 animate-[fadeInUp_0.2s_ease-out] text-left">
              <div className="text-center select-none">
                <h3 className="text-xl font-bold font-heading text-ink">Secure Your Record</h3>
                <p className="text-xs text-muted mt-1">Choose a password that you will not forget.</p>
              </div>

              <Input
                type="tel"
                label="Phone Number (Terefone)"
                placeholder="e.g. 0788123456"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                icon={<Phone className="w-4 h-4" />}
                required
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  type="password"
                  label="Password (Ijambo ry'ibanga)"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  icon={<Lock className="w-4 h-4" />}
                  required
                />
                <Input
                  type="password"
                  label="Confirm Password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  icon={<Lock className="w-4 h-4" />}
                  required
                />
              </div>

              <div className="flex justify-between pt-4">
                <Button variant="ghost" onClick={() => setStep(2)} className="h-11">← Back</Button>
                <Button type="submit" isLoading={isLoading} className="h-11 px-6">
                  Complete Setup • Kwiyandikisha
                </Button>
              </div>
            </form>
          )}

          <div className="text-center text-xs select-none pt-2 border-t border-border">
            <span className="text-muted font-medium">Already have an account? </span>
            <button 
              onClick={() => navigate('/login')}
              className="text-terracotta font-extrabold hover:underline cursor-pointer"
            >
              Sign In • Injira
            </button>
          </div>
        </Card>
      </div>
    );
  };

  // ==========================================
  // ADOLESCENT MODULE STATES & RE-FETCH TRIGGERS
  // ==========================================
  const [cycleLogsList, setCycleLogsList] = useState<CycleLog[]>([]);
  const [mealsList, setMealsList] = useState<MealLog[]>([]);
  const [appointmentsList, setAppointmentsList] = useState<Appointment[]>([]);
  const [cycleStats, setCycleStats] = useState({ avgCycleLength: 28, avgPeriodLength: 5, regularityScore: 92 });
  const [predictions, setPredictions] = useState({ next_period_date: '', fertile_window_start: '', fertile_window_end: '', confidence_score: 92 });
  const [insights, setInsights] = useState<any[]>([]);
  const [nutritionStats, setNutritionStats] = useState({ total_protein: 0, total_carbs: 0, total_fats: 0, total_calories: 0 });
  const [anomaly, setAnomaly] = useState({ anomaly_detected: false, alert_text: '' });
  
  // Modals trigger
  const [isLogCycleOpen, setIsLogCycleOpen] = useState(false);
  const [isLogMealOpen, setIsLogMealOpen] = useState(false);
  const [isBookAppOpen, setIsBookAppOpen] = useState(false);
  const [dashboardAppType, setDashboardAppType] = useState<'checkup' | 'consultation' | 'vaccination'>('consultation');

  // Sync adolescent states
  const syncAdolescentData = async () => {
    if (!user || user.user_type !== 'adolescent') return;
    try {
      const { data: logs } = await api.get<CycleLog[]>('/cycle-logs');
      setCycleLogsList(logs);

      const { data: meals } = await api.get<MealLog[]>('/meal-logs');
      setMealsList(meals);

      const { data: apps } = await api.get<Appointment[]>('/appointments');
      setAppointmentsList(apps);

      const { data: cStats } = await api.get('/cycle-logs/stats');
      setCycleStats(cStats);

      const { data: cPreds } = await api.get('/cycle-logs/predictions');
      setPredictions(cPreds);

      const { data: cInsights } = await api.get('/cycle-logs/insights');
      setInsights(cInsights);

      const { data: mStats } = await api.get('/meal-logs/stats');
      setNutritionStats(mStats);

      const { data: cAnomaly } = await api.get('/cycle-logs/anomaly-detection');
      setAnomaly(cAnomaly);
    } catch {}
  };

  useEffect(() => {
    if (user && user.user_type === 'adolescent' && accessToken) {
       syncAdolescentData();
    }
  }, [user, accessToken, currentPath]);

  // Handler mutations
  const handleAddNewCycleLog = async (data: any) => {
    try {
      await api.post('/cycle-logs', data);
      setIsLogCycleOpen(false);
      toast.success('Period cycle successfully logged!');
      syncAdolescentData();
    } catch {
      toast.error('Failed to log cycle record.');
    }
  };

  const handleDeleteCycleLog = async (id: number) => {
    try {
      await api.delete(`/cycle-logs/${id}`);
      toast.success('Record deleted.');
      syncAdolescentData();
    } catch {
      toast.error('Failed to delete.');
    }
  };

  const handleAddNewMealLog = async (data: any) => {
    try {
      await api.post('/meal-logs', data);
      setIsLogMealOpen(false);
      toast.success('Nutrient meal logged!');
      syncAdolescentData();
    } catch {
      toast.error('Failed to log meal.');
    }
  };

  const handleAddNewAppointment = async (data: any) => {
    try {
      await api.post('/appointments', data);
      setIsBookAppOpen(false);
      toast.success('Appointment booked successfully!');
      syncAdolescentData();
    } catch {
      toast.error('Error booking consultation.');
    }
  };

  const handleCancelAppointment = async (id: number) => {
    try {
      await api.delete(`/appointments/${id}`);
      toast.success('Appointment successfully cancelled.');
      syncAdolescentData();
    } catch {
      toast.error('Error cancelling.');
    }
  };

  // ==========================================
  // VIEW: Adolescent Home Dashboard
  // ==========================================
  const AdolescentDashboard = () => {
    const latestLog = cycleLogsList[0];

    return (
      <DashboardLayout currentPath="/dashboard" onNavigate={navigate}>
        <div className="space-y-6 text-left animate-[fadeInUp_0.15s_ease-out]">
          
          {/* Welcome Alert banner if heavy bleeding anomaly detected */}
          {anomaly.anomaly_detected && (
            <div className="p-4 bg-terracotta/10 border border-terracotta/30 rounded-xl flex items-start gap-3 shadow-sm">
              <AlertTriangle className="w-6 h-6 text-terracotta shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-terracotta uppercase tracking-wider">Health Alert • Imbura-shyu</span>
                <p className="text-xs text-ink font-semibold leading-relaxed mt-0.5">{anomaly.alert_text}</p>
              </div>
            </div>
          )}

          {/* Core dynamic widgets grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Cycle Progress Wheel */}
            <Card className="lg:col-span-4 flex flex-col justify-between">
              <div>
                <h3 className="text-lg font-bold font-heading text-ink border-b border-border pb-3 mb-4 flex items-center gap-1.5">
                  <Heart className="w-5 h-5 text-terracotta" /> Cycle Tracking
                </h3>
                {latestLog ? (
                  <CycleRing startDate={latestLog.start_date} />
                ) : (
                  <EmptyState
                    title="No tracking logged yet"
                    description="Log your last cycle to immediately activate Rwanda's custom circular phase tracking engine."
                    actionText="Log first period"
                    onAction={() => setIsLogCycleOpen(true)}
                  />
                )}
              </div>
              <div className="pt-2 border-t border-border mt-4">
                <Button variant="ghost" className="w-full text-xs font-bold" onClick={() => setIsLogCycleOpen(true)}>
                  + Log cycle start date
                </Button>
              </div>
            </Card>

            {/* Cycle predictions calendar */}
            <Card className="lg:col-span-4 select-none">
              <h3 className="text-lg font-bold font-heading text-ink border-b border-border pb-3 mb-4 flex items-center gap-1.5">
                <CalendarDays className="w-5 h-5 text-mauve" /> Menstrual Calendar
              </h3>
              <CycleCalendar 
                lastPeriodStart={latestLog?.start_date || new Date().toISOString()} 
                cycleLength={cycleStats.avgCycleLength}
                periodLength={cycleStats.avgPeriodLength}
              />
              <div className="p-3 bg-cream/30 border border-border rounded-lg text-[10px] text-muted leading-relaxed mt-4 flex items-start gap-1.5">
                <HelpCircle className="w-4 h-4 text-terracotta shrink-0" />
                <span>Our estimations are based on organic averages. For changes/delays, make a friendly clinic checkup consultation.</span>
              </div>
            </Card>

            {/* Nutrition macro donut */}
            <Card className="lg:col-span-4 flex flex-col justify-between">
              <div>
                <h3 className="text-lg font-bold font-heading text-ink border-b border-border pb-3 mb-4 flex items-center gap-1.5">
                  <Utensils className="w-5 h-5 text-sage" /> Daily Nutrition
                </h3>
                <NutritionDonut 
                  protein={nutritionStats.total_protein}
                  carbs={nutritionStats.total_carbs}
                  fats={nutritionStats.total_fats}
                />
              </div>
              <div className="pt-2 border-t border-border mt-4">
                <Button variant="ghost" className="w-full text-xs font-bold" onClick={() => setIsLogMealOpen(true)}>
                  + Log daily meal (Igikoma/Dodo)
                </Button>
              </div>
            </Card>

          </div>

          {/* AI insights and clinic appointment widgets */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* AI Insights stack */}
            <div className="lg:col-span-7 space-y-4">
              <h3 className="text-lg font-bold font-heading text-ink pb-1 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-terracotta" /> Personalized AI Clinical Insights
              </h3>
              
              <div className="grid grid-cols-1 gap-3">
                {insights.map((ins) => (
                  <InsightCard key={ins.id} insight={ins} />
                ))}
              </div>
            </div>

            {/* Upcoming consulting timelines */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-[#7A4F6D]/5 border border-[#7A4F6D]/10 rounded-[20px] p-4.5 space-y-3.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold font-heading text-ink flex items-center gap-2 select-none">
                    <Clock className="w-5 h-5 text-[#8FAF8A]" /> Clinical Booking
                  </h3>
                  <Button 
                    onClick={() => setIsBookAppOpen(true)} 
                    className="text-xs shrink-0 py-1.5 px-3 bg-[#7A4F6D] hover:bg-[#7A4F6D]/90 font-bold active:scale-95"
                  >
                    Book Slot
                  </Button>
                </div>

                {/* Dashboard appointment type selector cards or dropdown */}
                <div className="space-y-1.5 select-none">
                  <label className="block text-[10px] font-extrabold uppercase tracking-wider text-muted">
                    Choose Type (Ubwoko bwa Serivisi)
                  </label>
                  <select
                    value={dashboardAppType}
                    onChange={(e) => setDashboardAppType(e.target.value as 'checkup' | 'consultation' | 'vaccination')}
                    className="block w-full h-[40px] rounded-xl border border-border bg-surface px-3 text-xs font-bold text-ink focus:border-[#7A4F6D] focus:ring-1 focus:ring-[#7A4F6D] focus:outline-none cursor-pointer"
                  >
                    <option value="consultation">Friendly Consultation • Inama y’ubuzima</option>
                    <option value="checkup">Routine Checkup • Gupimwa busanzwe</option>
                    <option value="vaccination">HPV Vaccination • Gukingirwa mu Rwanda</option>
                  </select>
                </div>
              </div>

              <div className="space-y-3">
                {appointmentsList.filter(a => a.status !== 'cancelled').slice(0, 2).map((app) => (
                  <AppointmentCard 
                    key={app.id} 
                    appointment={app} 
                    onCancel={handleCancelAppointment} 
                  />
                ))}
                
                {appointmentsList.filter(a => a.status !== 'cancelled').length === 0 && (
                  <div className="p-6 text-center text-xs text-muted border border-dashed border-border rounded-xl bg-surface/40 select-none">
                    No active clinic reservations. Use Book Slot to set an appointment with Dr. Agnes Binagwaho.
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>
      </DashboardLayout>
    );
  };

  // ==========================================
  // PAGE: /dashboard/cycle - Detailed Cycle panel
  // ==========================================
  const CycleTrackerPage = () => {
    return (
      <DashboardLayout currentPath="/dashboard/cycle" onNavigate={navigate}>
        <div className="space-y-6 text-left animate-[fadeInUp_0.15s_ease-out]">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-border pb-4 select-none">
            <div>
              <h2 className="text-2xl font-extrabold font-heading text-ink">Cycle tracking & Predicts</h2>
              <p className="text-xs text-muted mt-0.5">Explore your historic cycle logs, forecasts, and confidence intervals.</p>
            </div>
            
            <Button onClick={() => setIsLogCycleOpen(true)} className="h-11">
              + Log New Period Start
            </Button>
          </div>

          {/* Cycle Stats summary row */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card hoverable className="p-4 flex flex-col justify-between border-l-4 border-l-terracotta text-left select-none">
              <div>
                <span className="text-[10px] font-bold text-muted uppercase tracking-wider block">Average cycle length</span>
                <span className="text-3xl font-extrabold text-ink font-heading mt-1.5 block">{cycleStats.avgCycleLength} Days</span>
              </div>
              <span className="text-[10px] text-muted mt-2 block">Calculated from historical values</span>
            </Card>

            <Card hoverable className="p-4 flex flex-col justify-between border-l-4 border-l-sage text-left select-none">
              <div>
                <span className="text-[10px] font-bold text-muted uppercase tracking-wider block">Flow duration avg</span>
                <span className="text-3xl font-extrabold text-ink font-heading mt-1.5 block">{cycleStats.avgPeriodLength} Days</span>
              </div>
              <span className="text-[10px] text-muted mt-2 block">Heavy days: 2 days typical</span>
            </Card>

            <Card hoverable className="p-4 flex flex-col justify-between border-l-4 border-l-mauve text-left select-none">
              <div>
                <span className="text-[10px] font-bold text-muted uppercase tracking-wider block">Cycle regularity index</span>
                <span className="text-3xl font-extrabold text-ink font-heading mt-1.5 block">{cycleStats.regularityScore}%</span>
              </div>
              <span className="text-[10px] text-muted mt-2 block">High consistency coefficient</span>
            </Card>
          </div>

          {/* Personalized AI Clinical Insights Section */}
          <div className="p-6 rounded-[24px] border border-[#7A4F6D]/15 bg-gradient-to-br from-[#7A4F6D]/5 via-white to-[#C4785A]/5 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2 border-b border-[#7A4F6D]/10">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-[#7A4F6D]/10 flex items-center justify-center text-[#7A4F6D]">
                  <Sparkles className="w-5 h-5 fill-[#7A4F6D]/10" />
                </div>
                <div>
                  <h3 className="text-lg font-bold font-heading text-ink">
                    Personalized AI Clinical Insights
                  </h3>
                  <p className="text-[11px] text-muted font-medium">Smart wellness suggestions tailored to your ongoing cycle phase</p>
                </div>
              </div>
              <span className="text-[10px] inline-flex items-center px-2.5 py-1 rounded-full font-extrabold bg-[#7A4F6D]/10 text-[#7A4F6D] uppercase tracking-wider self-start sm:self-center">
                ● Live AI recommendations
              </span>
            </div>

            {insights && insights.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {insights.map((ins) => (
                  <InsightCard key={ins.id} insight={ins} />
                ))}
              </div>
            ) : (
              <div className="py-6 text-center text-xs text-muted/80 italic">
                Analyzing cycle trend data... Your recommendations will appear here.
              </div>
            )}
          </div>

          {/* Grid layout of forecasts and lists */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Forecast panel */}
            <Card className="lg:col-span-4 text-left space-y-4 select-none bg-cream/15">
              <h3 className="text-base font-bold font-heading text-ink border-b border-border pb-2 flex items-center gap-1.5">
                <Sparkles className="w-4.5 h-4.5 text-terracotta animate-pulse" /> Wellness Predictions
              </h3>

              <div className="space-y-3.5">
                <div>
                  <span className="text-[10px] text-muted font-bold block uppercase tracking-wider">Estimated next period start</span>
                  <span className="text-sm font-extrabold text-ink mt-0.5 block">
                    {predictions.next_period_date ? new Date(predictions.next_period_date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'Pending...'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="text-[10px] text-muted font-bold block uppercase tracking-wider">Fertile window starts</span>
                    <span className="text-xs font-bold text-ink mt-0.5 block">
                      {predictions.fertile_window_start ? new Date(predictions.fertile_window_start).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : 'Pending...'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-muted font-bold block uppercase tracking-wider">Fertile window ends</span>
                    <span className="text-xs font-bold text-ink mt-0.5 block">
                      {predictions.fertile_window_end ? new Date(predictions.fertile_window_end).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : 'Pending...'}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-surface border border-border rounded-xl">
                  <span className="text-[10px] text-muted font-bold block uppercase tracking-wider">Confidence metrics score</span>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="sage">{predictions.confidence_score}% Confidence</Badge>
                    <span className="text-[10px] font-medium text-muted">Machine prediction validation active</span>
                  </div>
                </div>
              </div>
            </Card>

            {/* Log list */}
            <Card className="lg:col-span-8 flex flex-col justify-between">
              <div>
                <h3 className="text-base font-bold font-heading text-ink border-b border-border pb-2 mb-4 flex items-center gap-1.5">
                  <Heart className="w-4.5 h-4.5 text-terracotta" /> Logged Menstrual History
                </h3>

                {cycleLogsList.length === 0 ? (
                  <EmptyState 
                    title="No logs found"
                    description="You have not submitted any cycle logs. Click Add period to log flow statistics instantly."
                    actionText="Add period"
                    onAction={() => setIsLogCycleOpen(true)}
                  />
                ) : (
                  <div className="overflow-x-auto rounded-[20px] border border-border/80 shadow-sm bg-surface">
                    <table className="min-w-full divide-y divide-border text-left">
                      <thead className="bg-[#7A4F6D]/5">
                        <tr>
                          <th scope="col" className="px-5 py-4 text-xs font-bold text-[#7A4F6D] uppercase tracking-wider">Start Date (Umunsi utangiriraho)</th>
                          <th scope="col" className="px-5 py-4 text-xs font-bold text-[#7A4F6D] uppercase tracking-wider">End Date (Umunsi urangiriraho)</th>
                          <th scope="col" className="px-5 py-4 text-xs font-bold text-[#7A4F6D] uppercase tracking-wider">Flow Level (Umuvuduko)</th>
                          <th scope="col" className="px-5 py-4 text-xs font-bold text-[#7A4F6D] uppercase tracking-wider">Symptoms (Ibimenyetso)</th>
                          <th scope="col" className="relative px-5 py-4 text-right">
                            <span className="sr-only font-bold">Actions</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {cycleLogsList.map((log) => (
                          <tr key={log.id} className="hover:bg-cream/10 transition-all duration-150">
                            <td className="px-5 py-4 whitespace-nowrap text-sm font-extrabold text-ink">
                              {new Date(log.start_date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                            </td>
                            <td className="px-5 py-4 whitespace-nowrap text-sm font-medium text-muted">
                              {log.end_date ? (
                                <span className="font-semibold text-zinc-700">
                                  {new Date(log.end_date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                                </span>
                              ) : (
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#fcf5e9] border border-orange-150 text-[#C4785A]">
                                  Ongoing • Karacyakomeza
                                </span>
                              )}
                            </td>
                            <td className="px-5 py-4 whitespace-nowrap text-sm">
                              <Badge variant={log.flow_level === 'heavy' ? 'terracotta' : log.flow_level === 'medium' ? 'sage' : 'muted'}>
                                {log.flow_level.toUpperCase()}
                              </Badge>
                            </td>
                            <td className="px-5 py-4 text-sm max-w-xs">
                              <div className="flex flex-col gap-1.5 text-left">
                                {log.symptoms.length > 0 ? (
                                  <div className="flex flex-wrap gap-1">
                                    {log.symptoms.map((sym, si) => (
                                      <span key={si} className="text-[10px] bg-cream border border-border px-2 py-0.5 rounded-full text-zinc-700 font-bold">{sym}</span>
                                    ))}
                                  </div>
                                ) : (
                                  <span className="text-xs text-muted/60 italic">No symptoms reported</span>
                                )}
                                {log.notes && (
                                  <p className="text-xs text-muted/80 italic leading-snug truncate max-w-[200px]" title={log.notes}>
                                    "{log.notes}"
                                  </p>
                                )}
                              </div>
                            </td>
                            <td className="px-5 py-4 whitespace-nowrap text-right text-sm">
                              <button 
                                onClick={() => handleDeleteCycleLog(log.id)}
                                className="text-muted hover:text-mauve transition-all p-2 hover:bg-mauve/10 rounded-full cursor-pointer inline-flex items-center justify-center active:scale-90"
                                title="Delete log"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </Card>

          </div>

        </div>
      </DashboardLayout>
    );
  };

  // ==========================================
  // PAGE: /dashboard/meals - Nutritious meals log
  // ==========================================
  const MealsLogPage = () => {
    return (
      <DashboardLayout currentPath="/dashboard/meals" onNavigate={navigate}>
        <div className="space-y-6 text-left animate-[fadeInUp_0.15s_ease-out]">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-border pb-4 select-none">
            <div>
              <h2 className="text-2xl font-extrabold font-heading text-ink">Menstrual nutrition tracker</h2>
              <p className="text-xs text-muted mt-0.5">Understand how iron, minerals, and dodo meals support your system strength.</p>
            </div>
            
            <Button onClick={() => setIsLogMealOpen(true)} className="h-11">
              + Log Daily Meal
            </Button>
          </div>

          {/* Macro Nutrition overview list */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Pie donut card */}
            <Card className="lg:col-span-5 text-center flex flex-col justify-center select-none bg-cream/15">
              <h3 className="text-base font-bold font-heading text-ink border-b border-border pb-2 mb-4 flex items-center justify-center gap-1.5">
                <Utensils className="w-4.5 h-4.5 text-sage" /> Core Macor split
              </h3>
              <NutritionDonut 
                protein={nutritionStats.total_protein}
                carbs={nutritionStats.total_carbs}
                fats={nutritionStats.total_fats}
              />
              <div className="p-3 bg-surface border border-border rounded-xl mt-5 text-xs text-muted leading-relaxed">
                Total Calories Consumed Today: <strong className="text-ink">{nutritionStats.total_calories || 750} kcal</strong>
              </div>
            </Card>

            {/* Meals tracking timeline */}
            <Card className="lg:col-span-7 flex flex-col justify-between">
              <div>
                <h3 className="text-base font-bold font-heading text-ink border-b border-border pb-2 mb-4 flex items-center gap-1.5">
                  <Apple className="w-4.5 h-4.5 text-sage" /> Logged meals timeline
                </h3>

                {mealsList.length === 0 ? (
                  <EmptyState 
                    title="No nutrition logs submitted"
                    description="You haven't tracked any meals. Support your progesterone cycle phases by logging porridge or amaranth dodo."
                    actionText="Log first meal"
                    onAction={() => setIsLogMealOpen(true)}
                  />
                ) : (
                  <div className="space-y-3.5 max-h-96 overflow-y-auto pr-1">
                    {mealsList.map((meal) => (
                      <div key={meal.id} className="p-4 border border-border bg-surface rounded-xl flex items-start justify-between gap-4 text-left">
                        <div className="space-y-1.5">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] uppercase tracking-wider font-extrabold text-sage bg-sage/5 px-2 py-0.5 rounded border border-sage/10">{meal.meal_type}</span>
                            <span className="text-[11px] text-muted font-bold">{new Date(meal.created_at).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>

                          <div className="flex flex-wrap gap-1.5">
                            {meal.food_items.map((item, ii) => (
                              <span key={ii} className="text-xs bg-cream/75 border border-border text-ink px-2.5 py-1 rounded-full font-semibold">{item}</span>
                            ))}
                          </div>

                          <div className="flex items-center gap-3 text-[10px] text-zinc-500 font-semibold pt-1">
                            <span>Protein: <strong>{meal.protein || 0}g</strong></span>
                            <span>Carbs: <strong>{meal.carbs || 0}g</strong></span>
                            <span>Fats: <strong>{meal.fats || 0}g</strong></span>
                            <span>Calories: <strong>{meal.calories || 0} kcal</strong></span>
                          </div>

                          {meal.mood_after && (
                            <span className="inline-block text-[10px] bg-sage/10 text-sage font-extrabold px-2 py-0.5 rounded-full mt-1.5">
                              Wellness Mood: {meal.mood_after}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </Card>

          </div>

        </div>
      </DashboardLayout>
    );
  };

  // ==========================================
  // PAGE: /dashboard/appointments - Appointment desk
  // ==========================================
  const AppointmentsPage = () => {
    return (
      <DashboardLayout currentPath="/dashboard/appointments" onNavigate={navigate}>
        <div className="space-y-6 text-left animate-[fadeInUp_0.15s_ease-out]">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-border pb-4 select-none">
            <div>
              <h2 className="text-2xl font-extrabold font-heading text-ink">Clinical Appointments Desks</h2>
              <p className="text-xs text-muted mt-0.5">Secure, confidential HPV vaccines and adolescent symptom consults with Dr. Agnes Binagwaho.</p>
            </div>
            
            <Button onClick={() => setIsBookAppOpen(true)} className="h-11">
              + Request Appointment
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 select-none sm:grid-cols-2">
            <Card hoverable className="p-4 border-l-4 border-l-sage text-left bg-surface shadow-sm">
              <span className="text-[10px] font-extrabold uppercase text-muted tracking-wider">Assigned Physician</span>
              <p className="text-sm font-bold mt-1 text-ink">Dr. Agnes Binagwaho</p>
              <span className="text-[10px] text-muted block mt-1.5 font-semibold">Kigali Health Center Specialist</span>
            </Card>
            <Card hoverable className="p-4 border-l-4 border-l-terracotta text-left bg-surface shadow-sm">
              <span className="text-[10px] font-extrabold uppercase text-muted tracking-wider">Secure Access mode</span>
              <p className="text-sm font-bold mt-1 text-ink">Confidential & Guarded</p>
              <span className="text-[10px] text-muted block mt-1.5 font-semibold">100% Client-Staff Encryption Encrypted</span>
            </Card>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold font-heading text-ink border-b border-border pb-2">Schedule booking history</h3>
            
            <div className="space-y-3.5 max-w-4xl">
              {appointmentsList.map((app) => (
                <AppointmentCard 
                  key={app.id} 
                  appointment={app} 
                  onCancel={handleCancelAppointment} 
                />
              ))}

              {appointmentsList.length === 0 && (
                <EmptyState 
                  title="No historical appointments registered"
                  description="You do not have any appointments yet. Tap standard consultation setup with Dr. Agnes to speak in safety."
                  actionText="Book consultation"
                  onAction={() => setIsBookAppOpen(true)}
                />
              )}
            </div>
          </div>

        </div>
      </DashboardLayout>
    );
  };

  // ==========================================
  // PARENT DESK STATES
  // ==========================================
  const [childrenList, setChildrenList] = useState<Child[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<number | null>(null);
  const [childCycleLogs, setChildCycleLogs] = useState<CycleLog[]>([]);
  const [childMealLogs, setChildMealLogs] = useState<MealLog[]>([]);
  const [childAppointments, setChildAppointments] = useState<Appointment[]>([]);

  const [isAddChildOpen, setIsAddChildOpen] = useState(false);
  const [isParentBookOpen, setIsParentBookOpen] = useState(false);

  const syncParentDashboard = async () => {
    if (!user || user.user_type !== 'parent') return;
    try {
      const { data: children } = await api.get<Child[]>('/parents/children');
      setChildrenList(children);
      
      // Auto expand first child log details if privacy allows
      if (children.length > 0 && selectedChildId === null) {
        const first = children[0];
        if (first.allow_parent_access) {
          setSelectedChildId(first.id);
        }
      }
    } catch {}
  };

  useEffect(() => {
    if (user && user.user_type === 'parent' && selectedChildId !== null) {
      api.get<CycleLog[]>(`/parents/children/${selectedChildId}/cycle-logs`)
        .then(res => setChildCycleLogs(res.data))
        .catch(() => {});
        
      api.get<MealLog[]>(`/parents/children/${selectedChildId}/meal-logs`)
        .then(res => setChildMealLogs(res.data))
        .catch(() => {});

      api.get<Appointment[]>(`/parents/children/${selectedChildId}/appointments`)
        .then(res => setChildAppointments(res.data))
        .catch(() => {});
    }
  }, [user, selectedChildId]);

  useEffect(() => {
    if (user && user.user_type === 'parent' && accessToken) {
      syncParentDashboard();
    }
  }, [user, accessToken, currentPath]);

  const handleCreateChild = async (data: any) => {
    try {
      const { data: newChild } = await api.post('/parents/children', data);
      setIsAddChildOpen(false);
      toast.success('Child profile registered successfully!');
      syncParentDashboard();
    } catch {
      toast.error('Failed to create child.');
    }
  };

  const handleParentBookForChild = async (data: any) => {
    try {
      await api.post('/parent/book-appointment-for-child', {
        child_id: selectedChildId,
        ...data
      });
      setIsParentBookOpen(false);
      toast.success('Consultation booked for your daughter.');
      // Refresh details
      if (selectedChildId !== null) {
        const res = await api.get<Appointment[]>(`/parents/children/${selectedChildId}/appointments`);
        setChildAppointments(res.data);
      }
    } catch {
      toast.error('Booking failed.');
    }
  };

  // ==========================================
  // VIEW: Parent Dashboard
  // ==========================================
  const ParentDashboardPage = () => {
    const activeChild = childrenList.find(c => c.id === selectedChildId);

    return (
      <RoleRequired allowed={['parent']}>
        <DashboardLayout currentPath="/dashboard/parent" onNavigate={navigate}>
          <div className="space-y-6 text-left animate-[fadeInUp_0.15s_ease-out]">
            
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-border pb-4 select-none">
              <div>
                <h2 className="text-2xl font-extrabold font-heading text-ink">Parent workspace & oversight</h2>
                <p className="text-xs text-muted mt-0.5">Stay aware, supportive, and advocate for your daughter’s health with comforting guidance.</p>
              </div>
              
              <Button onClick={() => setIsAddChildOpen(true)} className="h-11">
                + Add Teen daughter profile
              </Button>
            </div>

            {/* List of registered kids */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {childrenList.map((child) => (
                <ChildCard 
                  key={child.id} 
                  child={child} 
                  onSelect={(id) => setSelectedChildId(id)}
                  onBookAppointment={(id) => { setSelectedChildId(id); setIsParentBookOpen(true); }}
                  selected={selectedChildId === child.id}
                />
              ))}

              {childrenList.length === 0 && (
                <div className="col-span-1 md:col-span-2">
                  <EmptyState 
                    title="No adolescent files connected"
                    description="Support your teen daughters by adding their profile wrapper safely in accordance with privacy laws."
                    actionText="Add child profile"
                    onAction={() => setIsAddChildOpen(true)}
                  />
                </div>
              )}
            </div>

            {/* Expands details of the highlighted daughter */}
            {activeChild && activeChild.allow_parent_access && (
              <div className="space-y-6 pt-4 animate-[fadeInUp_0.15s_ease-out]">
                <div className="flex items-center justify-between border-b border-border pb-2.5">
                  <h3 className="text-lg font-bold font-heading text-ink flex items-center gap-2">
                    📊 Tracking Insights: {activeChild.first_name} Uwase
                  </h3>
                  <Button 
                    variant="secondary" 
                    onClick={() => setIsParentBookOpen(true)}
                    className="text-xs shrink-0 py-1.5 px-3"
                  >
                    Book clinic request for {activeChild.first_name}
                  </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Miniature Period history Calendar */}
                  <div className="lg:col-span-6">
                    <Card className="h-full">
                      <h4 className="text-sm font-bold font-heading text-ink mb-3 uppercase tracking-wider text-muted">Estimated flow days</h4>
                      <CycleCalendar 
                        lastPeriodStart={childCycleLogs[0]?.start_date || new Date().toISOString()} 
                        cycleLength={28}
                        periodLength={5}
                      />
                    </Card>
                  </div>

                  {/* Daughter nutrition logs */}
                  <div className="lg:col-span-6">
                    <Card className="h-full text-left">
                      <h4 className="text-sm font-bold font-heading text-ink border-b border-border pb-2 mb-3 uppercase tracking-wider text-muted">Nutritional meals logged</h4>
                      
                      <div className="space-y-3 max-h-80 overflow-y-auto">
                        {childMealLogs.map((meal) => (
                          <div key={meal.id} className="p-3 border border-border bg-surface/50 rounded-xl">
                            <div className="flex items-center justify-between mb-1.5">
                              <span className="text-[10px] uppercase font-bold text-sage bg-sage/5 border border-sage/10 px-2 py-0.5 rounded-full">{meal.meal_type}</span>
                              <span className="text-[10px] text-muted">{new Date(meal.created_at).toLocaleDateString()}</span>
                            </div>
                            <p className="text-xs font-bold text-ink mb-1">{meal.food_items.join(', ')}</p>
                            {meal.mood_after && <p className="text-[10px] text-muted">Daughter mood: {meal.mood_after}</p>}
                          </div>
                        ))}

                        {childMealLogs.length === 0 && (
                          <div className="p-6 text-center text-xs text-muted">No historic nutrition logged by {activeChild.first_name}.</div>
                        )}
                      </div>
                    </Card>
                  </div>
                </div>

              </div>
            )}

          </div>
        </DashboardLayout>
      </RoleRequired>
    );
  };

  // ==========================================
  // CLINIC WORKER STATES
  // ==========================================
  const [providerApps, setProviderApps] = useState<Appointment[]>([]);
  const [unassignedApps, setUnassignedApps] = useState<Appointment[]>([]);
  const [patients, setPatients] = useState<any[]>([]);
  const [patientSearch, setPatientSearch] = useState('');
  const [gridAvls, setGridAvls] = useState<ProviderAvailability[]>([]);

  const syncProviderDashboard = async () => {
    if (!user || user.user_type !== 'health_provider') return;
    try {
      const { data: apps } = await api.get<Appointment[]>('/health-provider/appointments');
      setProviderApps(apps);

      const { data: unass } = await api.get<Appointment[]>('/health-provider/appointments/unassigned');
      setUnassignedApps(unass);

      const { data: pats } = await api.get<any[]>(`/health-provider/patients?search=${patientSearch}`);
      setPatients(pats);

      const { data: avl } = await api.get<ProviderAvailability[]>('/health-provider/availability');
      setGridAvls(avl);
    } catch {}
  };

  useEffect(() => {
    if (user && user.user_type === 'health_provider' && accessToken) {
      syncProviderDashboard();
    }
  }, [user, accessToken, patientSearch, currentPath]);

  const handleClaimAppointment = async (id: number) => {
    try {
      await api.patch(`/health-provider/appointments/${id}/claim`);
      toast.success('Consultation successfully claimed! Moving to your clinic schedule desk.');
      syncProviderDashboard();
    } catch {
      toast.error('Claims failed.');
    }
  };

  const handleAddSlotToDay = async (day_of_week: string, slot: string) => {
    try {
      await api.post('/health-provider/availability/slots', { day_of_week, slot });
      toast.success(`Slot ${slot} added to ${day_of_week}`);
      syncProviderDashboard();
    } catch {
       toast.error('Failed to update slot.');
    }
  };

  // ==========================================
  // VIEW: Provider Desk
  // ==========================================
  const ProviderDashboardPage = () => {
    return (
      <RoleRequired allowed={['health_provider']}>
        <DashboardLayout currentPath="/dashboard/provider" onNavigate={navigate}>
          <div className="space-y-6 text-left animate-[fadeInUp_0.15s_ease-out]">
            
            <div className="border-b border-border pb-4 select-none">
              <h2 className="text-2xl font-extrabold font-heading text-ink">Clinical Consulting Desk</h2>
              <p className="text-xs text-muted mt-0.5">Manage unaligned consulting schedules, claiming bookings from parents/girls, and verify block slots.</p>
            </div>

            {/* Provider stats grids */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              
              {/* Daily timeline appointment */}
              <div className="md:col-span-8 space-y-4">
                <h3 className="text-lg font-bold font-heading text-ink flex items-center gap-2">
                  🩺 Today’s Clinic Schedule Timelines ({providerApps.length})
                </h3>

                <div className="space-y-3">
                  {providerApps.map((item) => (
                    <AppointmentCard key={item.id} appointment={item} showUser />
                  ))}

                  {providerApps.length === 0 && (
                    <div className="p-8 border border-dashed border-border rounded-xl bg-surface/40 text-center text-xs text-muted">
                      No active appointment consultations assigned under your account today. Use Claim below to pick upcoming parent tickets.
                    </div>
                  )}
                </div>

                {/* Claiming stack */}
                <h3 className="text-lg font-bold font-heading text-ink pt-5">
                  📥 Unassigned Parent-Adolescent Claim desk ({unassignedApps.length})
                </h3>

                <div className="space-y-3">
                  {unassignedApps.map((app) => (
                    <div key={app.id} className="border border-border p-4 bg-surface rounded-xl flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                      <div className="space-y-1">
                        <p className="text-sm font-bold text-ink capitalize">{app.appointment_type} ({app.user_name || 'Kezia Uwase'})</p>
                        <p className="text-[11px] text-muted">Booking: {formatDateTime(app.scheduled_datetime)}</p>
                        {app.notes && <p className="text-xs text-muted italic">"{app.notes}"</p>}
                      </div>
                      <Button onClick={() => handleClaimAppointment(app.id)} className="text-xs py-1 px-3">
                        Claim consultaion
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Patient Searches & availability slots */}
              <div className="md:col-span-4 space-y-5">
                <Card className="p-4 bg-surface select-none">
                  <h3 className="text-sm font-extrabold uppercase text-muted tracking-wider border-b border-border pb-2 mb-3">Patient Registry Search</h3>
                  
                  <div className="relative mb-3">
                    <Search className="absolute left-3 top-3 h-4.5 w-4.5 text-muted" />
                    <Input 
                      placeholder="Search patient name..." 
                      value={patientSearch}
                      onChange={(e) => setPatientSearch(e.target.value)}
                      className="pl-9 text-xs"
                    />
                  </div>

                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {patients.map((p) => (
                      <div key={p.id} className="p-2.5 border border-border bg-cream/20 rounded-lg flex items-center justify-between gap-2.5 text-xs">
                        <div className="text-left font-sans">
                          <p className="font-bold text-ink leading-tight">{p.name}</p>
                          <p className="text-[10px] text-muted">Age {p.age} • Cycle {p.cycle_regular}</p>
                        </div>
                        <Badge variant="muted">Active</Badge>
                      </div>
                    ))}
                  </div>
                </Card>

                {/* Clinic blocking grids */}
                <Card className="p-4 bg-cream/15">
                  <h3 className="text-sm font-extrabold uppercase text-muted tracking-wider border-b border-border pb-2 mb-3">Weekly availability</h3>
                  
                  <div className="space-y-3 text-xs">
                    {gridAvls.map((day) => (
                      <div key={day.day_of_week} className="text-left font-sans border-b border-border pb-2 last:border-0 last:pb-0">
                        <strong className="text-ink font-semibold">{day.day_of_week}</strong>
                        
                        <div className="flex flex-wrap gap-1 mt-1.5 justify-start">
                          {day.slots.map((sl, si) => (
                            <span key={si} className="bg-surface text-[10px] border border-border text-ink px-1.5 py-0.5 rounded font-mono font-medium">
                              {sl}
                            </span>
                          ))}
                          
                          <button
                            onClick={() => {
                              const sl = prompt(`Add timing slot to ${day.day_of_week} (e.g., 10:30):`);
                              if (sl && sl.trim()) handleAddSlotToDay(day.day_of_week, sl.trim());
                            }}
                            className="text-[10px] bg-sage text-surface hover:bg-sage/85 hover:underline px-1.5 py-0.5 rounded cursor-pointer font-bold"
                          >
                            + Slot
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>

            </div>

          </div>
        </DashboardLayout>
      </RoleRequired>
    );
  };

  // ==========================================
  // ADMIN DASHBOARD STATES
  // ==========================================
  const [adminStats, setAdminStats] = useState({ total_users: 18, active_providers: 2, pending_content: 1, appointments_today: 2 });
  const [allUsersList, setAllUsersList] = useState<UserType[]>([]);
  const [systemLogsList, setSystemLogsList] = useState<SystemLog[]>([]);
  const [pendingArticles, setPendingArticles] = useState<ContentItem[]>([]);

  const syncAdminDashboard = async () => {
    if (!user || user.user_type !== 'admin') return;
    try {
      const { data: stats } = await api.get('/admin/dashboard/stats');
      setAdminStats(stats);

      const { data: usrs } = await api.get<UserType[]>('/admin/users');
      setAllUsersList(usrs);

      const { data: logs } = await api.get<SystemLog[]>('/admin/system/logs');
      setSystemLogsList(logs);

      const { data: pend } = await api.get<ContentItem[]>('/admin/content/pending');
      setPendingArticles(pend);
    } catch {}
  };

  useEffect(() => {
    if (user && user.user_type === 'admin' && accessToken) {
      syncAdminDashboard();
    }
  }, [user, accessToken, currentPath]);

  const handleToggleUserStatus = async (id: number) => {
    try {
      await api.patch(`/admin/users/${id}/toggle-status`);
      toast.success('Account state toggled.');
      syncAdminDashboard();
    } catch {
      toast.error('System toggle failed.');
    }
  };

  const handleChangeUserRole = async (id: number, role: string) => {
    try {
      await api.patch(`/admin/users/${id}/change-role`, { user_type: role });
      toast.success('User type changed successfully.');
      syncAdminDashboard();
    } catch {
       toast.error('Role update error.');
    }
  };

  const handleApproveContent = async (id: number) => {
    try {
      await api.patch(`/admin/content/${id}/approve`);
      toast.success('Course article verified and approved for Rwandan adolescent grids!');
      syncAdminDashboard();
    } catch {
       toast.error('Moderation failed.');
    }
  };

  const handleRejectContent = async (id: number) => {
    try {
      await api.patch(`/admin/content/${id}/reject`);
      toast.success('Article rejected. Returned to authors draft space.');
      syncAdminDashboard();
    } catch {
      toast.error('Rejection audit failed.');
    }
  };

  // ==========================================
  // VIEW: Admin Panel
  // ==========================================
  const AdminDashboardPage = () => {
    return (
      <RoleRequired allowed={['admin']}>
        <DashboardLayout currentPath="/dashboard/admin" onNavigate={navigate}>
          <div className="space-y-6 text-left animate-[fadeInUp_0.15s_ease-out]">
            
            <div className="border-b border-border pb-4 select-none">
              <h2 className="text-2xl font-extrabold font-heading text-ink">Administrative control panel</h2>
              <p className="text-xs text-muted mt-0.5">Control regional database profiles, verify workspace providers, approve publications & review audit telemetry.</p>
            </div>

            {/* Administartive numbers */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 select-none">
              <Card hoverable className="p-4 border-l-4 border-l-terracotta bg-surface shadow-sm">
                <span className="text-[10px] font-bold text-muted uppercase">Total users</span>
                <p className="text-3xl font-extrabold text-ink font-heading mt-1">{adminStats.total_users}</p>
              </Card>
              <Card hoverable className="p-4 border-l-4 border-l-sage bg-surface shadow-sm">
                <span className="text-[10px] font-bold text-muted uppercase">Active Specialists</span>
                <p className="text-3xl font-extrabold text-ink font-heading mt-1">{adminStats.active_providers}</p>
              </Card>
              <Card hoverable className="p-4 border-l-4 border-l-mauve bg-surface shadow-sm">
                <span className="text-[10px] font-bold text-muted uppercase">Pending Moderation</span>
                <p className="text-3xl font-extrabold text-ink font-heading mt-1">{adminStats.pending_content}</p>
              </Card>
              <Card hoverable className="p-4 border-l-4 border-l-muted bg-surface shadow-sm">
                <span className="text-[10px] font-bold text-muted uppercase">Reservations today</span>
                <p className="text-3xl font-extrabold text-ink font-heading mt-1">{adminStats.appointments_today}</p>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Accounts Moderation queues */}
              <div className="lg:col-span-8 space-y-6">
                
                {/* Users Table list */}
                <Card className="p-4">
                  <h3 className="text-base font-bold font-heading text-ink border-b border-border pb-2.5 mb-4 flex items-center justify-between">
                    👥 Regional Account Directory Directory
                  </h3>

                  <div className="overflow-x-auto text-xs">
                    <table className="w-full text-left font-sans border-collapse">
                      <thead>
                        <tr className="border-b border-border text-muted font-bold text-[10px] uppercase">
                          <th className="pb-2">Full name</th>
                          <th className="pb-2">Role path</th>
                          <th className="pb-2">Contact</th>
                          <th className="pb-2">Registration</th>
                          <th className="pb-2 text-right">Settings</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {allUsersList.map((usr) => (
                          <tr key={usr.id} className="hover:bg-cream/10">
                            <td className="py-2.5 font-bold text-ink">{usr.first_name} {usr.last_name}</td>
                            <td className="py-2.5">
                              <Badge variant={usr.user_type === 'health_provider' ? 'sage' : usr.user_type === 'adolescent' ? 'terracotta' : 'muted'} className="text-[9px]">
                                {usr.user_type.toUpperCase()}
                              </Badge>
                            </td>
                            <td className="py-2.5 font-mono text-muted">{usr.phone_number}</td>
                            <td className="py-2.5 text-muted">{new Date(usr.created_at).toLocaleDateString()}</td>
                            <td className="py-2.5 text-right space-x-1.5 whitespace-nowrap">
                              <button 
                                onClick={() => handleToggleUserStatus(usr.id)}
                                className={`px-2 py-0.5 rounded text-[10px] font-semibold cursor-pointer border ${usr.is_active ? 'bg-sage/10 text-sage border-sage/20' : 'bg-mauve/10 text-mauve border-mauve/20'}`}
                              >
                                {usr.is_active ? 'Block account' : 'Unlock'}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </Card>

                {/* Moderation section */}
                <Card className="p-4">
                  <h3 className="text-base font-bold font-heading text-ink border-b border-border pb-2.5 mb-4">
                    📝 Literature approval queue
                  </h3>

                  <div className="space-y-3.5">
                    {pendingArticles.map((art) => (
                      <div key={art.id} className="p-3.5 border border-border bg-surface rounded-xl text-left space-y-2">
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <h4 className="text-sm font-bold text-ink">{art.title}</h4>
                          <Badge variant="muted">{art.category} • {art.language}</Badge>
                        </div>
                        <p className="text-[11px] text-muted line-clamp-2 leading-relaxed">{art.body}</p>
                        
                        <div className="flex justify-end gap-2 pt-1">
                          <Button onClick={() => handleRejectContent(art.id)} variant="ghost" className="text-[10px] py-1 px-2 border border-mauve/20 text-mauve">
                            Reject
                          </Button>
                          <Button onClick={() => handleApproveContent(art.id)} variant="primary" className="text-[10px] py-1 px-2 bg-sage">
                            Approve & Publish
                          </Button>
                        </div>
                      </div>
                    ))}

                    {pendingArticles.length === 0 && (
                      <div className="p-6 text-center text-xs text-muted">No pending articles requiring approval. Curation queue clear!</div>
                    )}
                  </div>
                </Card>
              </div>

              {/* Audit systems telemetry logs */}
              <div className="lg:col-span-4 space-y-4">
                <Card className="p-4 h-full flex flex-col justify-between selection:bg-black overflow-hidden bg-cream/15">
                  <div>
                    <h3 className="text-xs font-extrabold uppercase text-muted tracking-wider border-b border-border pb-2 mb-3">System audit Terminal</h3>
                    
                    <div className="space-y-3.5 max-h-96 overflow-y-auto font-mono text-[10px]">
                      {systemLogsList.map((log) => (
                        <div 
                          key={log.id} 
                          className={`text-left border-b border-border/40 pb-2 last:border-0 ${
                            log.level === 'error' ? 'text-mauve font-bold' : log.level === 'warn' ? 'text-terracotta' : 'text-neutral-700'
                          }`}
                        >
                          <p className="text-[9px] text-muted">[{new Date(log.timestamp).toLocaleTimeString()}]</p>
                          <p className="mt-0.5 leading-normal">{log.message}</p>
                          {log.action_by && <span className="opacity-75 block text-[8px] mt-0.5">Executor: {log.action_by}</span>}
                        </div>
                      ))}
                    </div>
                  </div>
                </Card>
              </div>

            </div>

          </div>
        </DashboardLayout>
      </RoleRequired>
    );
  };

  // ==========================================
  // CONTENT WRITER STATES & WRITING DESK
  // ==========================================
  const [writerContent, setWriterContent] = useState<ContentItem[]>([]);
  const [writerCourses, setWriterCourses] = useState<Course[]>([]);
  const [analytics, setAnalytics] = useState({ total_views: 760, total_likes: 205, average_engagement: '24%', popular_category: 'Puberty Education' });

  // Article creation form states
  const [artTitle, setArtTitle] = useState('');
  const [artBody, setArtBody] = useState('');
  const [artCat, setArtCat] = useState('Puberty');
  const [artLang, setArtLang] = useState<'English' | 'Kinyarwanda' | 'French'>('English');
  const [artImg, setArtImg] = useState('');

  const syncWriterDashboard = async () => {
    if (!user || user.user_type !== 'content_writer') return;
    try {
      const { data: contents } = await api.get<ContentItem[]>('/content-writer/content');
      setWriterContent(contents);

      const { data: crs } = await api.get<Course[]>('/content-writer/courses');
      setWriterCourses(crs);

      const { data: aly } = await api.get('/content-writer/analytics');
      setAnalytics(aly);
    } catch {}
  };

  useEffect(() => {
    if (user && user.user_type === 'content_writer' && accessToken) {
      syncWriterDashboard();
    }
  }, [user, accessToken, currentPath]);

  const handleCreateArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!artTitle || !artBody) {
       toast.error('Please enter article title and body.');
       return;
    }
    try {
      await api.post('/content-writer/content', {
        title: artTitle,
        body: artBody,
        category: artCat,
        language: artLang,
        media_url: artImg || undefined
      });
      // Clear forms
      setArtTitle('');
      setArtBody('');
      setArtImg('');
      toast.success('Course draft composed! Submitting click required below to moderate.');
      syncWriterDashboard();
    } catch {
       toast.error('Composition creation failed.');
    }
  };

  const handleSubmitToModerate = async (id: number) => {
    try {
      await api.patch(`/content-writer/content/${id}/submit`);
      toast.success('Composition successfully submitted to Admin moderation panel!');
      syncWriterDashboard();
    } catch {
       toast.error('Submission failed.');
    }
  };

  // ==========================================
  // VIEW: Writer Curation Dashboard
  // ==========================================
  const ContentWriterDashboardPage = () => {
    return (
      <RoleRequired allowed={['content_writer']}>
        <DashboardLayout currentPath="/dashboard/writer" onNavigate={navigate}>
          <div className="space-y-6 text-left animate-[fadeInUp_0.15s_ease-out]">
            
            <div className="border-b border-border pb-4 select-none">
              <h2 className="text-2xl font-extrabold font-heading text-ink">Literature curation desk</h2>
              <p className="text-xs text-muted mt-0.5">Author hygienic instructions, compose teen reproductive guides, write courses and track engagement metrics.</p>
            </div>

            {/* Writer stats metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 select-none">
              <Card hoverable className="p-4 border-l-4 border-l-sage bg-surface">
                <span className="text-[10px] text-muted uppercase font-bold">Total Literature views</span>
                <p className="text-2.5xl font-extrabold font-heading mt-1 text-ink">{analytics.total_views} Reads</p>
              </Card>
              <Card hoverable className="p-4 border-l-4 border-l-terracotta bg-surface">
                <span className="text-[10px] text-muted uppercase font-bold">Total reader hearts</span>
                <p className="text-2.5xl font-extrabold font-heading mt-1 text-ink">{analytics.total_likes} Hearts</p>
              </Card>
              <Card hoverable className="p-4 border-l-4 border-l-mauve bg-surface">
                <span className="text-[10px] text-muted uppercase font-bold">Curation engagement average</span>
                <p className="text-2.5xl font-extrabold font-heading mt-1 text-ink">{analytics.average_engagement}</p>
              </Card>
              <Card hoverable className="p-4 border-l-4 border-l-muted bg-surface">
                <span className="text-[10px] text-muted uppercase font-bold">Popular topic</span>
                <p className="text-xs font-bold font-heading pr-1 line-clamp-1 mt-1.5 text-ink">{analytics.popular_category}</p>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Write articles form */}
              <div className="lg:col-span-5">
                <Card className="p-5 flex flex-col h-full bg-cream/10">
                  <h3 className="text-base font-bold font-heading text-ink border-b border-border pb-2.5 mb-4">
                    ✍️ Draft new educational article
                  </h3>

                  <form onSubmit={handleCreateArticle} className="space-y-4">
                    <Input
                      label="Title * (Omutwe w’inyigsho)"
                      placeholder="e.g. Healthy Hygiene Tips"
                      value={artTitle}
                      onChange={(e) => setArtTitle(e.target.value)}
                      required
                    />

                    <div className="grid grid-cols-2 gap-3 text-xs font-semibold">
                      <div>
                        <label className="block text-muted tracking-wider uppercase mb-1">Language</label>
                        <select
                          value={artLang}
                          onChange={(e) => setArtLang(e.target.value as any)}
                          className="w-full h-10 border border-border rounded-lg bg-surface px-2 focus:ring-1 focus:ring-terracotta/40"
                        >
                          <option value="English">English</option>
                          <option value="Kinyarwanda">Kinyarwanda</option>
                          <option value="French">French</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-muted tracking-wider uppercase mb-1">Category</label>
                        <select
                          value={artCat}
                          onChange={(e) => setArtCat(e.target.value)}
                          className="w-full h-10 border border-border rounded-lg bg-surface px-2"
                        >
                          <option value="Puberty">Puberty Education</option>
                          <option value="Hygiene">Hygiene & Care</option>
                          <option value="Nutrition">Healthy Diet</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[11px] font-bold text-muted uppercase">Image Media Url (Optional)</label>
                      <Input
                        placeholder="Image URL..."
                        value={artImg}
                        onChange={(e) => setArtImg(e.target.value)}
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[11px] font-bold text-muted uppercase">Article content draft body *</label>
                      <textarea
                        rows={5}
                        required
                        value={artBody}
                        onChange={(e) => setArtBody(e.target.value)}
                        placeholder="Write helpful, comforting words in dignity..."
                        className="w-full p-2.5 border border-border bg-surface rounded-lg text-xs"
                      />
                    </div>

                    <Button type="submit" className="w-full py-2.5 text-xs">
                      Compose Article Draft
                    </Button>
                  </form>
                </Card>
              </div>

              {/* Author article table draft list */}
              <div className="lg:col-span-7 space-y-4">
                <Card className="p-4">
                  <h3 className="text-base font-bold font-heading text-ink border-b border-border pb-2 mb-4">
                    📚 Published Literature drafts
                  </h3>

                  <div className="space-y-3.5 max-h-[500px] overflow-y-auto">
                    {writerContent.map((item) => (
                      <div key={item.id} className="p-3.5 border border-border bg-surface/50 rounded-xl flex items-start justify-between gap-4 text-left">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-ink leading-tight">{item.title}</span>
                            <Badge variant={item.status === 'approved' ? 'sage' : item.status === 'pending' ? 'muted' : 'mauve'}>
                              {item.status.toUpperCase()}
                            </Badge>
                          </div>
                          <p className="text-[10px] text-muted">Topic: {item.category} • {item.language} • {item.views} Reads • {item.likes} Hearts</p>
                          <p className="text-xs text-muted/90 line-clamp-3 italic leading-relaxed pt-1">"{item.body}"</p>
                        </div>

                        {item.status === 'draft' && (
                          <Button onClick={() => handleSubmitToModerate(item.id)} className="text-[10px] py-1 px-2.5 shrink-0 bg-sage">
                            Submit Audit
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </Card>
              </div>

            </div>

          </div>
        </DashboardLayout>
      </RoleRequired>
    );
  };

  // ==========================================
  // PAGE: /dashboard/notifications - Complete Center
  // ==========================================
  const NotificationsCentricPage = () => {
    const [notifItems, setNotifItems] = useState<Notification[]>([]);

    const syncNotifications = () => {
      api.get<Notification[]>('/notifications')
        .then(res => setNotifItems(res.data))
        .catch(() => {});
    };

    useEffect(() => {
      if (accessToken) {
        syncNotifications();
      }
    }, [accessToken, currentPath]);

    const markSingleRead = async (id: number) => {
      try {
        await api.patch(`/notifications/${id}/read`);
        toast.success('Alert marked resolved.');
        syncNotifications();
      } catch {}
    };

    const deleteSingle = async (id: number) => {
      try {
        await api.delete(`/notifications/${id}`);
        toast.success('Alert dismissed.');
        syncNotifications();
      } catch {}
    };

    return (
      <DashboardLayout currentPath="/dashboard/notifications" onNavigate={navigate}>
        <div className="space-y-6 text-left animate-[fadeInUp_0.15s_ease-out] select-none">
          
          <div className="border-b border-border pb-4">
            <h2 className="text-2xl font-extrabold font-heading text-ink">Notification center alerts</h2>
            <p className="text-xs text-muted mt-0.5 font-sans">Manage your daily cycle reminders, wellness micro prompts, and medical checkup reservations.</p>
          </div>

          <div className="space-y-3.5 max-w-4xl">
            {notifItems.map((item) => (
              <div 
                key={item.id} 
                className={`p-4 border rounded-xl bg-surface flex items-start gap-4 transition-all ${
                  !item.is_read ? 'border-l-4 border-l-terracotta bg-surface' : 'border-border/80 bg-surface/50 opacity-90'
                }`}
              >
                <div className={`p-2 rounded-full shrink-0 ${!item.is_read ? 'bg-terracotta/10 text-terracotta animate-pulse' : 'bg-cream text-muted'}`}>
                  <Bell className="w-5 h-5" />
                </div>
                
                <div className="flex-grow space-y-1 text-left font-sans">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-ink leading-tight">{item.title}</span>
                    <Badge variant={item.notification_type === 'cycle' ? 'terracotta' : item.notification_type === 'appointment' ? 'sage' : 'muted'} className="text-[9px]">
                      {item.notification_type.toUpperCase()}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted/90">{item.message}</p>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {!item.is_read && (
                    <button 
                      onClick={() => markSingleRead(item.id)}
                      className="text-[10px] text-sage font-bold px-2 py-1 rounded bg-sage/10 hover:bg-sage/20 border border-sage/20 cursor-pointer"
                    >
                      Resolve
                    </button>
                  )}
                  <button 
                    onClick={() => deleteSingle(item.id)}
                    className="p-1 px-2 text-muted hover:text-mauve hover:bg-mauve/10 rounded cursor-pointer"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            ))}

            {notifItems.length === 0 && (
              <EmptyState 
                title="Your notice board is clear"
                description="Everything looks peaceful. Notifications, period reminders, and clinic checkups will appear here."
              />
            )}
          </div>

        </div>
      </DashboardLayout>
    );
  };

  // ==========================================
  // PAGE: /settings - Profile Configuration
  // ==========================================
  const SettingsPage = () => {
    const [firstName, setFirstName] = useState(user?.first_name || '');
    const [lastName, setLastName] = useState(user?.last_name || '');
    const [email, setEmail] = useState(user?.email || '');
    const [phone, setPhone] = useState(user?.phone_number || '');
    const [allowParentAccess, setAllowParentAccess] = useState(user?.allow_parent_access || false);
    const [saving, setSaving] = useState(false);

    const { apiKey, setApiKey } = useUmwariStore();
    const [showSetKey, setShowSetKey] = useState(false);
    const [setKeyInput, setSetKeyInput] = useState('');
    const [keyTestStatus, setKeyTestStatus] = useState<'success' | 'error' | null>(null);
    const [testingConn, setTestingConn] = useState(false);

    const handleSaveKeyInput = () => {
      if (setKeyInput.trim()) {
        setApiKey(setKeyInput.trim());
        setSetKeyInput('');
        setKeyTestStatus(null);
        toast.success('Gemini key updated!');
      }
    };

    const handleTestConnection = async () => {
      const targetKey = setKeyInput.trim() || apiKey;
      if (!targetKey) {
        toast.error('Please enter a key first.');
        return;
      }
      setTestingConn(true);
      setKeyTestStatus(null);
      try {
        const testAI = new GoogleGenerativeAI(targetKey);
        const model = testAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
        const result = await model.generateContent("Respond with: OK");
        const text = result.response.text();
        if (text) {
          setKeyTestStatus('success');
          toast.success('Key verified successfully!');
        } else {
          throw new Error();
        }
      } catch (err) {
        setKeyTestStatus('error');
        toast.error('Key verification failed.');
      } finally {
        setTestingConn(false);
      }
    };

    const handleSaveAccount = async (e: React.FormEvent) => {
      e.preventDefault();
      setSaving(true);
      try {
        const { data } = await api.put('/settings/account', {
          first_name: firstName,
          last_name: lastName,
          email,
          phone_number: phone
        });
        setUser(data);
        toast.success('Settings saved!');
      } catch {
        toast.error('Changes failed to persist.');
      } finally {
        setSaving(false);
      }
    };

    const handleTogglePrivacy = async (checked: boolean) => {
      setAllowParentAccess(checked);
      try {
        const { data } = await api.put('/settings/privacy/parent-access', {
          allow_parent_access: checked
        });
        setUser(data);
        toast.success(checked ? 'Oversight visibility is active now.' : 'Oversight visibility locked privately.');
      } catch {
         toast.error('Network sync failure.');
      }
    };

    return (
      <DashboardLayout currentPath="/settings" onNavigate={navigate}>
        <div className="space-y-6 text-left animate-[fadeInUp_0.15s_ease-out] select-none max-w-4xl">
          
          <div className="border-b border-border pb-4">
            <h2 className="text-2xl font-extrabold font-heading text-ink">Account & privacy controls</h2>
            <p className="text-xs text-muted mt-0.5">Adjust password keys, configure communication languages, and toggle linked parental oversight controls safely.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Main credentials card */}
            <div className="lg:col-span-7">
              <Card className="p-5">
                <h3 className="text-sm font-extrabold uppercase text-muted tracking-wider border-b border-border pb-2.5 mb-4">Edit Profile details</h3>
                
                <form onSubmit={handleSaveAccount} className="space-y-4">
                  <div className="grid grid-cols-2 gap-3.5">
                    <Input
                      label="First name *"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      required
                    />
                    <Input
                      label="Last name *"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      required
                    />
                  </div>

                  <Input
                    label="Phone number *"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                  />

                  <Input
                    label="Email Address (Optional)"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />

                  <div className="pt-2">
                    <Button type="submit" isLoading={saving} className="w-full">
                      Save Account details
                    </Button>
                  </div>
                </form>
              </Card>
            </div>

            {/* Adolescent Privacy Lock controls */}
            <div className="lg:col-span-5 space-y-5">
              
              {user?.user_type === 'adolescent' && (
                <Card className="p-4 border-l-4 border-l-terracotta bg-terracotta/5">
                  <h3 className="text-sm font-extrabold uppercase text-ink tracking-wider border-b border-border/80 pb-2 mb-3">Family security link</h3>
                  
                  <div className="space-y-3 font-sans text-xs">
                    <p className="text-[11px] text-muted leading-relaxed">
                      Toggle whether your parent Marie Mukamana can see your menstrual start date or logged dodo meals. You remain in absolute sovereign control.
                    </p>

                    <div className="flex items-center justify-between p-3.5 bg-surface border border-border rounded-xl">
                      <div className="text-left font-sans">
                        <span className="font-bold text-ink block">Comfort parental share</span>
                        <span className="text-[10px] text-muted">Toggle visibility state</span>
                      </div>
                      
                      {/* Check toggle */}
                      <button
                        type="button"
                        onClick={() => handleTogglePrivacy(!allowParentAccess)}
                        className={`w-11 h-6 rounded-full transition-colors relative outline-none cursor-pointer ${
                          allowParentAccess ? 'bg-sage' : 'bg-muted/40'
                        }`}
                      >
                        <span className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-surface transition-transform ${
                          allowParentAccess ? 'translate-x-[20px]' : 'translate-x-0'
                        }`} />
                      </button>
                    </div>

                    <div className="p-2 bg-surface rounded-lg text-center text-[10px] text-muted leading-relaxed">
                      {allowParentAccess ? (
                        <p className="text-sage font-bold">✓ Oversight visible on mum’s children workspace dashboard.</p>
                      ) : (
                        <p className="text-mauve font-bold">🔒 Secure adolescent encryption active. Visibility masked.</p>
                      )}
                    </div>
                  </div>
                </Card>
              )}

              {/* Umwari Settings card */}
              <Card className="p-4 border-l-4 border-l-[#7A4F6D] bg-white space-y-4">
                <h3 className="text-sm font-extrabold uppercase text-ink tracking-wider border-b border-border/80 pb-2 mb-1 flex items-center gap-1.5">
                  <span>🌸 Umwari AI Companion</span>
                </h3>
                
                <div className="space-y-4 font-sans text-xs text-left">
                  <div>
                    <span className="block font-bold text-ink mb-1">Umwari AI Language</span>
                    <p className="text-[11px] text-muted leading-relaxed mb-3">
                      Choose the language Umwari uses when talking to you.
                    </p>
                    <UmwariLanguagePicker />
                  </div>

                  <div className="border-t border-border/60 pt-3">
                    <span className="block font-bold text-ink mb-1">Gemini API Key</span>
                    <p className="text-[11px] text-muted leading-relaxed mb-3">
                      Modify your secure Google Gemini API key used for running tests and chat sessions.
                    </p>
                    
                    <div className="space-y-3">
                      <div className="relative">
                        <input
                          type={showSetKey ? "text" : "password"}
                          value={setKeyInput}
                          onChange={(e) => {
                            setSetKeyInput(e.target.value);
                            setKeyTestStatus(null);
                          }}
                          placeholder={apiKey ? "••••••••••••••••••••••••" : "Enter API key... (AIzaSy)"}
                          className="w-full px-3 py-2 bg-surface border border-border text-xs font-mono rounded-lg pr-10 focus:outline-none focus:border-terracotta"
                        />
                        <button
                          type="button"
                          onClick={() => setShowSetKey(!showSetKey)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-ink cursor-pointer bg-transparent"
                        >
                          {showSetKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={handleTestConnection}
                          disabled={testingConn || (!setKeyInput.trim() && !apiKey)}
                          className="h-9 bg-[#FAF9F6] border border-ink/10 hover:border-[#7A4F6D]/20 text-muted hover:text-[#7A4F6D] text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                        >
                          {testingConn ? "Testing..." : "Test Connection"}
                        </button>

                        <button
                          type="button"
                          onClick={handleSaveKeyInput}
                          disabled={!setKeyInput.trim()}
                          className="h-9 bg-[#7A4F6D] hover:bg-[#68415C] text-white text-xs font-bold rounded-lg flex items-center justify-center transition-all cursor-pointer disabled:opacity-50"
                        >
                          Change key
                        </button>
                      </div>

                      {keyTestStatus === 'success' && (
                        <p className="text-emerald-600 font-extrabold text-[10.5px] bg-emerald-50 p-2 rounded-lg border border-emerald-100">
                          ✅ Umwari is ready and connected to Google Gemini!
                        </p>
                      )}
                      {keyTestStatus === 'error' && (
                        <p className="text-rose-600 font-extrabold text-[11px] bg-rose-50 p-2 rounded-lg border border-rose-100">
                          ❌ Key invalid. Please verify your key.
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </Card>

              {/* General support */}
              <Card className="p-4 bg-cream/15 text-xs text-muted leading-relaxed space-y-2 select-none">
                <span className="font-bold text-ink block font-heading text-sm">Need help with setup?</span>
                <p>If you encounter tracking problems, contact our friendly regional health assistants via the clinic consultation bookings on appointments panels.</p>
                <button 
                  onClick={logout}
                  className="w-full mt-2 h-10 border border-mauve/20 bg-surface hover:bg-mauve/10 hover:text-mauve cursor-pointer rounded-xl font-bold transition-colors text-mauve block text-center flex items-center justify-center"
                >
                  Sign Out from This Device
                </button>
              </Card>

            </div>

          </div>

        </div>
      </DashboardLayout>
    );
  };

  // ==========================================
  // ROUTER CONTROLLING THE APP VIEWPORTS
  // ==========================================
  return (
    <>
      <Toaster position="top-center" reverseOrder={false} />
      
      {currentPath === '/login' && <LoginPage />}
      {currentPath === '/register' && <RegisterPage />}
      
      {/* Adolescent Router views */}
      {currentPath === '/dashboard' && (
        <RoleRequired allowed={['adolescent']}>
          <AdolescentDashboard />
        </RoleRequired>
      )}
      {currentPath === '/dashboard/cycle' && (
        <RoleRequired allowed={['adolescent']}>
          <CycleTrackerPage />
        </RoleRequired>
      )}
      {currentPath === '/dashboard/meals' && (
        <RoleRequired allowed={['adolescent']}>
          <MealsLogPage />
        </RoleRequired>
      )}
      {currentPath === '/dashboard/appointments' && (
        <RoleRequired allowed={['adolescent']}>
          <AppointmentsPage />
        </RoleRequired>
      )}

      {/* Role dashboard routes */}
      {currentPath === '/dashboard/parent' && <ParentDashboardPage />}
      {currentPath === '/dashboard/provider' && <ProviderDashboardPage />}
      {currentPath === '/dashboard/admin' && <AdminDashboardPage />}
      {currentPath === '/dashboard/writer' && <ContentWriterDashboardPage />}

      {/* Shared routes */}
      {currentPath === '/dashboard/notifications' && <NotificationsCentricPage />}
      {currentPath === '/settings' && <SettingsPage />}
      
      {currentPath === '/dashboard/umwari' && (
        <DashboardLayout currentPath="/dashboard/umwari" onNavigate={navigate}>
          <UmwariFullPage />
        </DashboardLayout>
      )}

      {/* MODAL WORKFLOW: Log Cycle Period starts */}
      <Modal isOpen={isLogCycleOpen} onClose={() => setIsLogCycleOpen(false)} title="Log Cycle Record • Igihe cy'imihango">
        <CycleLogForm onSubmit={handleAddNewCycleLog} />
      </Modal>

      {/* MODAL WORKFLOW: Log Meal Nutrition logs */}
      <Modal isOpen={isLogMealOpen} onClose={() => setIsLogMealOpen(false)} title="Log Daily Nutrient Meal • Ibyo Uriye">
        <MealLogForm onSubmit={handleAddNewMealLog} />
      </Modal>

      {/* MODAL WORKFLOW: Book Adolescent appointment */}
      <Modal isOpen={isBookAppOpen} onClose={() => setIsBookAppOpen(false)} title="Request Clinical appointment">
        <AppointmentForm 
          onSubmit={handleAddNewAppointment} 
          initialType={dashboardAppType}
          initialDate={(() => {
            const d = new Date();
            const pad = (num: number) => num.toString().padStart(2, '0');
            return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
          })()}
        />
      </Modal>

      {/* MODAL WORKFLOW: Create and link adolescent child files */}
      <Modal isOpen={isAddChildOpen} onClose={() => setIsAddChildOpen(false)} title="Register Teen Daughter profile">
        <ChildForm onSubmit={handleCreateChild} />
      </Modal>

      {/* MODAL WORKFLOW: Book consulting request for daughter */}
      <Modal isOpen={isParentBookOpen} onClose={() => setIsParentBookOpen(false)} title="Book specialist checkup for your daughter">
        <AppointmentForm onSubmit={handleParentBookForChild} />
      </Modal>

      {/* Umwari AI floating companion, active on core logged-in pages (not login/register) */}
      {currentPath !== '/login' && currentPath !== '/register' && (
        <>
          {umwariStore.isOpen && <UmwariChat />}
          <UmwariFab />
        </>
      )}
    </>
  );
}
