import { useCallback } from 'react';
import { useUmwariStore } from '../stores/umwariStore';
import { useAuthStore } from '../stores/authStore';
import { buildSystemPrompt } from '../lib/gemini';
import { useUmwariContext } from './useUmwariContext';
import type { UmwariMessage } from '../types/umwari';
import { nanoid } from 'nanoid';

export function useUmwari() {
  const store = useUmwariStore();
  const { data: healthContext, refetch: refetchContext } = useUmwariContext();

  const sendMessage = useCallback(async (userText: string) => {
    // Refresh context on message send to ensure up-to-date data
    refetchContext();

    // Create a normalized health context if none is loaded yet
    const resolvedContext = healthContext || {
      user: { firstName: 'Friend', userType: 'adolescent' }
    };

    // If it's a real user message (not the behind-the-scenes greeting trigger), add it
    let userMsg: UmwariMessage | null = null;
    if (userText !== '__GREETING__') {
      userMsg = {
        id: nanoid(),
        role: 'user',
        content: userText,
        timestamp: new Date().toISOString(),
      };
      store.addMessage(userMsg);
    }

    store.setStreaming(true);

    // Add empty placeholder Umwari message that we will stream text into
    const umwariMsg: UmwariMessage = {
      id: nanoid(),
      role: 'umwari',
      content: '',
      timestamp: new Date().toISOString(),
    };
    store.addMessage(umwariMsg);

    try {
      const systemPrompt = buildSystemPrompt(resolvedContext, store.language);

      // Build safe conversation history for Gemini chat thread
      // Exclude the currently created empty model response and the current user message (will be sent in chat history)
      const history = store.messages
        .filter((m) => m.id !== umwariMsg.id && (userMsg ? m.id !== userMsg.id : m.content !== '__GREETING__'))
        .map((m) => ({
          role: m.role === 'user' ? 'user' : 'model',
          parts: [{ text: m.content }],
        }));

      // Special handling for GREETING prompt
      const promptToSend = userText === '__GREETING__' 
        ? 'Please begin our session with your structured, warm greeting tailored to my data.' 
        : userText;

      const contents = [
        { role: 'user', parts: [{ text: systemPrompt }] },
        { role: 'model', parts: [{ text: 'Mwaramutse! Ndi Umwari, inshuti yawe yizewe ku bujyanama bw\'ubuzima. Mbafashe iki uyu munsi? Hello! I am Umwari, your trusted health companion. How can I help you today?' }] },
        ...history,
        { role: 'user', parts: [{ text: promptToSend }] }
      ];

      const token = useAuthStore.getState().accessToken;

      const response = await fetch('/api/umwari/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          parts: contents,
          modelName: 'gemini-3.5-flash',
          config: {}
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP error ${response.status}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunkText = decoder.decode(value, { stream: true });
          
          if (chunkText.includes('[ServerError:')) {
            const errMatch = chunkText.match(/\[ServerError:\s*(.*?)\]/);
            throw new Error(errMatch ? errMatch[1] : 'Internal generator error');
          }
          
          store.updateLastMessage(chunkText);
        }
      }

    } catch (err: any) {
      console.error('Umwari Gemini Error:', err);
      
      const isConfigErr = err?.message?.toLowerCase().includes('configured') || err?.message?.toLowerCase().includes('apikey') || err?.status === 500;
      
      let errorMsg = store.language === 'rw'
        ? 'Mumbabarire, hari ikibazo cyakarere kibaye muri sisitemu. Nyamuneka mugerageze mukanya.'
        : 'Something went wrong while connecting with Gemini. Please try again in a moment.';

      if (isConfigErr) {
        errorMsg = store.language === 'rw'
          ? 'Mumbabarire cyane, serivisi ya AI ya Umwari ntabwo irasozwa gusanwa cyangwa gushyirwaho neza. Nyamuneka reba niba urufunguzo rwa Gemini API key ruri muri Settings > Secrets.'
          : 'I sincerely apologize, but the Umwari AI services are not fully configured yet on the backend server. Please verify the Gemini API key inside Settings > Secrets.';
      }

      store.updateLastMessage(errorMsg);
    } finally {
      store.setStreaming(false);
    }
  }, [store, healthContext, refetchContext]);

  // Safely parse doctor recommendations JSON anywhere inside the generated response
  const extractDoctorRecommendations = useCallback((content: string) => {
    const matches = content.match(/\{"umwari_recommend":\s*(\{[^}]+\})\}/g) ?? [];
    return matches.map((m) => {
      try {
        const cleanedMatch = m.replace(/[\n\r]/g, '');
        const parsed = JSON.parse(cleanedMatch);
        return parsed.umwari_recommend;
      } catch (e) {
        console.error('Error parsing doctor recommendation block:', e);
        return null;
      }
    }).filter(Boolean);
  }, []);

  // Strips off recommendations JSON to keep text bubble clean and professional
  const cleanContent = useCallback((content: string) => {
    return content.replace(/\{"umwari_recommend":\s*\{[^}]+\}\}/g, '').trim();
  }, []);

  return { sendMessage, extractDoctorRecommendations, cleanContent };
}
