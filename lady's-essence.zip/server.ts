import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import { 
  User, CycleLog, MealLog, Appointment, 
  Notification, ContentItem, Course, 
  ProviderAvailability, Child, SystemLog 
} from './src/types';

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialized GoogleGenAI instance following guidelines
let googleAI: GoogleGenAI | null = null;
function getGoogleAI(): GoogleGenAI | null {
  if (!googleAI) {
    const key = process.env.GEMINI_API_KEY;
    if (key && key !== "MY_GEMINI_API_KEY" && key.trim() !== "") {
      googleAI = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
  }
  return googleAI;
}

// ==========================================
// SEEDED STATE & DATABASE REPRESENTATION
// ==========================================

let users: User[] = [
  {
    id: 1,
    phone_number: '0788123456',
    first_name: 'Kezia',
    last_name: 'Uwase',
    email: 'uwase.kezia@gmail.com',
    user_type: 'adolescent',
    allow_parent_access: true,
    is_active: true,
    created_at: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 2,
    phone_number: '0788654321',
    first_name: 'Marie',
    last_name: 'Mukamana',
    email: 'marie.m@gmail.com',
    user_type: 'parent',
    allow_parent_access: false,
    is_active: true,
    created_at: new Date(Date.now() - 60 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 3,
    phone_number: '0788998877',
    first_name: 'Dr. Agnes',
    last_name: 'Binagwaho',
    email: 'agnes.b@clinic.rw',
    user_type: 'health_provider',
    allow_parent_access: false,
    is_active: true,
    created_at: new Date(Date.now() - 120 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 4,
    phone_number: '0788001122',
    first_name: 'Admin',
    last_name: 'System',
    email: 'admin@ladysessence.org',
    user_type: 'admin',
    allow_parent_access: false,
    is_active: true,
    created_at: new Date(Date.now() - 365 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 5,
    phone_number: '0788445566',
    first_name: 'Esperance',
    last_name: 'Niyigena',
    email: 'esperance.n@writer.com',
    user_type: 'content_writer',
    allow_parent_access: false,
    is_active: true,
    created_at: new Date(Date.now() - 90 * 24 * 3600 * 1000).toISOString(),
  }
];

// Helper to secure PIN / Password values
const passwords: Record<number, string> = {
  1: '1234', // standard login / 1234 PIN
  2: 'password123',
  3: 'doctor123',
  4: 'admin123',
  5: 'writer123',
};

// Cycle logs seed
let cycleLogs: CycleLog[] = [
  {
    id: 1,
    user_id: 1,
    start_date: new Date(Date.now() - 25 * 24 * 3600 * 1000).toISOString().split('T')[0],
    end_date: new Date(Date.now() - 21 * 24 * 3600 * 1000).toISOString().split('T')[0],
    flow_level: 'medium',
    symptoms: ['Cramps', 'Headache', 'Bloating'],
    notes: 'Slight fatigue on day 2. Drank hibiscus tea to soothe cramps.',
    confidence_score: 94,
    created_at: new Date(Date.now() - 25 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 2,
    user_id: 1,
    start_date: new Date(Date.now() - 53 * 24 * 3600 * 1000).toISOString().split('T')[0],
    end_date: new Date(Date.now() - 48 * 24 * 3600 * 1000).toISOString().split('T')[0],
    flow_level: 'heavy',
    symptoms: ['Cramps', 'Back Pain'],
    notes: 'Heavy flow on day 1 and 2.',
    confidence_score: 89,
    created_at: new Date(Date.now() - 53 * 24 * 3600 * 1000).toISOString(),
  }
];

// Meals seed
let mealLogs: MealLog[] = [
  {
    id: 1,
    user_id: 1,
    meal_type: 'breakfast',
    food_items: ['Porridge', 'Banana', 'Groundnuts'],
    protein: 12,
    carbs: 45,
    fats: 10,
    calories: 320,
    mood_after: '😊 Energized',
    created_at: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
  },
  {
    id: 2,
    user_id: 1,
    meal_type: 'lunch',
    food_items: ['Cassava', 'Beans', 'Green Amaranth (Dodo)'],
    protein: 18,
    carbs: 65,
    fats: 5,
    calories: 380,
    mood_after: '😴 Relaxed',
    created_at: new Date(Date.now() - 6 * 3600 * 1000).toISOString(),
  },
  {
    id: 3,
    user_id: 1,
    meal_type: 'snack',
    food_items: ['Passionfruit', 'Water'],
    protein: 1,
    carbs: 12,
    fats: 0,
    calories: 50,
    mood_after: '😋 Refreshed',
    created_at: new Date(Date.now() - 10 * 3600 * 1000).toISOString(),
  }
];

// Appointments seed
let appointments: Appointment[] = [
  {
    id: 1,
    user_id: 1,
    user_name: 'Kezia Uwase',
    health_provider_id: 3,
    health_provider_name: 'Dr. Agnes Binagwaho',
    appointment_type: 'consultation',
    scheduled_datetime: new Date(Date.now() + 2 * 24 * 3600 * 1000 + 10 * 3600 * 1000).toISOString(), // 2 days later, 10:00 AM
    status: 'confirmed',
    notes: 'General checkup and menstrual tracking advice.',
  },
  {
    id: 2,
    user_id: 1,
    user_name: 'Kezia Uwase',
    appointment_type: 'vaccination',
    scheduled_datetime: new Date(Date.now() - 14 * 24 * 3600 * 1000).toISOString(),
    status: 'completed',
    notes: 'HPV Vaccine Dose 1 completed.',
  }
];

// Notifications seed
let notifications: Notification[] = [
  {
    id: 1,
    title: 'Upcoming Appointment',
    message: 'Your checkup with Dr. Agnes Binagwaho is in 2 days. Be sure to note down any recent symptoms.',
    notification_type: 'appointment',
    is_read: false,
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    title: 'Fertile Window Begins Soon',
    message: 'Based on your cycle logging, your fertile phase is estimated to start tomorrow.',
    notification_type: 'cycle',
    is_read: false,
    created_at: new Date(Date.now() - 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 3,
    title: 'Nurture Tip',
    message: 'Adding foods rich in iron like green amaranth (dodo) can help replenish your body during your flow.',
    notification_type: 'health',
    is_read: true,
    created_at: new Date(Date.now() - 48 * 24 * 3600 * 1000).toISOString(),
  }
];

// Content Writer / Courses Seed
let contents: ContentItem[] = [
  {
    id: 1,
    title: 'Understanding Your First Cycle: An Empowering Guide',
    body: 'Welcome to Lady’s Essence! Growing up is a beautiful and natural journey. Your first period (menarche) is a sign of your strength and growth, typically starting between ages 10 to 15. Your cycle represents your reproductive health and has four distinct phases: Menstrual, Follicular, Ovulatory, and Luteal. Track your cycle to know your body best and feel confident every day.',
    category: 'Puberty',
    language: 'English',
    media_url: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&q=80&w=400',
    status: 'approved',
    views: 450,
    likes: 120,
    created_at: new Date(Date.now() - 10 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 2,
    title: 'Kugira isuku mu gihe cy’mihindagurikire y’umubiri',
    body: 'Isuku y’umubiri ni ingenzi cyane mu gihe uri mu mihango. Gukaraba neza, gukoresha ibikoresho byisuku bifite isuku bihagije no kubihindura inshuro 3 kugeza kuri 4 ku munsi bigufasha kwirinda indwara no kumva ubyibushye neza kandi ukeye.',
    category: 'Hygiene',
    language: 'Kinyarwanda',
    status: 'approved',
    views: 310,
    likes: 85,
    created_at: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 3,
    title: 'Nutritious Traditional Foods for Iron and Strength',
    body: 'Eating green vegetables like dodo (spinach/amaranth), combined with beans, sweet potatoes, and local fruits like avocados and passionfruits can help boost hemoglobin concentrations and ease heavy flow cramps.',
    category: 'Nutrition',
    language: 'English',
    status: 'pending',
    views: 0,
    likes: 0,
    created_at: new Date().toISOString(),
  }
];

let courses: Course[] = [
  {
    id: 1,
    title: 'Journey to Womanhood: Comprehensive Guide',
    description: 'A 5-part self-paced learning course designed for adolescent girls to learn self-care, biological transitions, and hygiene safety.',
    modules_count: 5,
    status: 'approved',
    created_at: new Date(Date.now() - 20 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 2,
    title: 'Parenting Teen Girls: Nurturing Health & Dignity',
    description: 'A guide for supportive fathers and mothers on addressing sanitary health, puberty queries, and supporting emotional well-being.',
    modules_count: 4,
    status: 'draft',
    created_at: new Date().toISOString(),
  }
];

// Parents & Children seed
let children: Child[] = [
  {
    id: 1, // Kezia Uwase is Marie's daughter
    first_name: 'Kezia',
    last_name: 'Uwase',
    age: 14,
    allow_parent_access: true,
    gender: 'female',
  }
];

// Provider Availability Day / Slots
let providerAvailabilities: ProviderAvailability[] = [
  { day_of_week: 'Monday', slots: ['09:00', '10:00', '11:00', '14:00', '15:00'] },
  { day_of_week: 'Tuesday', slots: ['09:00', '10:30', '11:30', '14:30', '16:00'] },
  { day_of_week: 'Wednesday', slots: ['09:00', '10:00', '15:00'] },
  { day_of_week: 'Thursday', slots: [] },
  { day_of_week: 'Friday', slots: ['10:00', '11:00', '14:00'] },
];

// System logs
let systemLogs: SystemLog[] = [
  { id: 1, timestamp: new Date(Date.now() - 3600 * 1000).toISOString(), level: 'info', message: 'User uwase.kezia logged in from Kigali, Rwanda (Web UI)', action_by: 'Kezia Uwase' },
  { id: 2, timestamp: new Date(Date.now() - 2 * 3600 * 1000).toISOString(), level: 'info', message: 'Clinic slot claimed for Dr. Agnes Binagwaho', action_by: 'Dr. Agnes Binagwaho' },
  { id: 3, timestamp: new Date(Date.now() - 3 * 3600 * 1000).toISOString(), level: 'warn', message: 'Automatic cycle anomaly detected on adolescent record ID #1', action_by: 'System-AI' },
];

// ==========================================
// MIDDLEWARE TO EXTRACT JWT TOKEN FOR AUTH PROFILE
// ==========================================
const getAuthenticatedUser = (req: Request): User | null => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const token = authHeader.split(' ')[1];
  
  // Custom verification: checking token structure "user_id-<id>"
  if (token.startsWith('user_id-')) {
    const idStr = token.split('-')[1];
    const id = parseInt(idStr, 10);
    return users.find(u => u.id === id) || null;
  }
  return null;
};

const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  const user = getAuthenticatedUser(req);
  if (!user) {
    return res.status(401).json({ message: 'Missing or invalid authentication token.' });
  }
  (req as any).user = user;
  next();
};

// ==========================================
// AUTH ENDPOINTS
// ==========================================

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { phone_number, password, pin } = req.body;
  
  if (!phone_number) {
    return res.status(400).json({ message: 'Phone number is required.' });
  }
  
  // Search user by phone
  const user = users.find(u => u.phone_number === phone_number);
  if (!user) {
    return res.status(401).json({ message: 'Invalid credentials. Phone number registration required.' });
  }
  
  // Verify pin or password
  if (pin) {
    if (pin !== passwords[user.id]) {
      return res.status(412).json({ message: 'Incorrect 4-digit PIN. Please try again.' });
    }
  } else if (password) {
    if (password !== passwords[user.id]) {
      return res.status(412).json({ message: 'Incorrect password. Please try again.' });
    }
  } else {
    return res.status(400).json({ message: 'Please provide a password or PIN.' });
  }
  
  // Mock accessToken in-memory and refresh token
  const access_token = `user_id-${user.id}`;
  const refresh_token = `refresh-${user.id}`;
  
  return res.json({
    access_token,
    refresh_token,
    user_type: user.user_type,
    user
  });
});

app.post('/api/auth/register', (req: Request, res: Response) => {
  const { phone_number, password, first_name, last_name, email, user_type } = req.body;
  
  if (!phone_number || !password || !first_name || !last_name || !user_type) {
    return res.status(400).json({ message: 'Please fill in all required registration steps.' });
  }
  
  if (users.some(u => u.phone_number === phone_number)) {
    return res.status(409).json({ message: 'An account with this phone number already exists.' });
  }
  
  const newUser: User = {
    id: users.length + 1,
    phone_number,
    first_name,
    last_name,
    email,
    user_type,
    allow_parent_access: true,
    is_active: true,
    created_at: new Date().toISOString()
  };
  
  users.push(newUser);
  passwords[newUser.id] = password;
  
  // Add log
  systemLogs.unshift({
    id: systemLogs.length + 1,
    timestamp: new Date().toISOString(),
    level: 'info',
    message: `New account registered: ${first_name} ${last_name} (${user_type})`,
    action_by: first_name
  });
  
  const access_token = `user_id-${newUser.id}`;
  const refresh_token = `refresh-${newUser.id}`;
  
  return res.status(201).json({
    access_token,
    refresh_token,
    user: newUser
  });
});

app.post('/api/auth/refresh', (req: Request, res: Response) => {
  const { refresh_token } = req.body;
  if (!refresh_token || !refresh_token.startsWith('refresh-')) {
    return res.status(400).json({ message: 'Invalid token.' });
  }
  const id = parseInt(refresh_token.split('-')[1], 10);
  const user = users.find(u => u.id === id);
  if (!user) {
    return res.status(401).json({ message: 'Session expired.' });
  }
  return res.json({ access_token: `user_id-${user.id}` });
});

app.get('/api/auth/profile', requireAuth, (req: Request, res: Response) => {
  return res.json((req as any).user);
});

app.post('/api/auth/logout', (req: Request, res: Response) => {
  return res.json({ message: 'Logged out successfully' });
});

// ==========================================
// CYCLE LOGS ENDPOINTS (Adolescent focus)
// ==========================================

app.get('/api/cycle-logs', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const logs = cycleLogs.filter(log => log.user_id === user.id);
  return res.json(logs);
});

app.post('/api/cycle-logs', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const { start_date, end_date, flow_level, symptoms, notes } = req.body;
  
  if (!start_date || !flow_level) {
    return res.status(400).json({ message: 'Start date and flow intensity are required.' });
  }
  
  const newLog: CycleLog = {
    id: cycleLogs.length + 1,
    user_id: user.id,
    start_date,
    end_date,
    flow_level,
    symptoms: symptoms || [],
    notes,
    confidence_score: Math.floor(82 + Math.random() * 15),
    created_at: new Date().toISOString()
  };
  
  cycleLogs.push(newLog);
  return res.status(201).json(newLog);
});

app.put('/api/cycle-logs/:id', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const id = parseInt(req.params.id, 10);
  const { start_date, end_date, flow_level, symptoms, notes } = req.body;
  
  const index = cycleLogs.findIndex(log => log.id === id && log.user_id === user.id);
  if (index === -1) return res.status(404).json({ message: 'Cycle log not found.' });
  
  cycleLogs[index] = {
    ...cycleLogs[index],
    start_date: start_date || cycleLogs[index].start_date,
    end_date: end_date !== undefined ? end_date : cycleLogs[index].end_date,
    flow_level: flow_level || cycleLogs[index].flow_level,
    symptoms: symptoms || cycleLogs[index].symptoms,
    notes: notes !== undefined ? notes : cycleLogs[index].notes
  };
  
  return res.json(cycleLogs[index]);
});

app.delete('/api/cycle-logs/:id', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const id = parseInt(req.params.id, 10);
  
  const initialLength = cycleLogs.length;
  cycleLogs = cycleLogs.filter(log => !(log.id === id && log.user_id === user.id));
  
  if (cycleLogs.length === initialLength) {
    return res.status(404).json({ message: 'Log not found.' });
  }
  return res.json({ message: 'Log deleted successfully.' });
});

app.get('/api/cycle-logs/stats', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const logs = cycleLogs.filter(log => log.user_id === user.id);
  
  let avgCycleLength = 28;
  let avgPeriodLength = 5;
  let regularityScore = 95;
  
  if (logs.length >= 2) {
    // calculate average diff between start dates
    const dates = logs.map(l => new Date(l.start_date).getTime()).sort((a,b) => a-b);
    let diffSum = 0;
    for (let i = 1; i < dates.length; i++) {
       diffSum += (dates[i] - dates[i-1]) / (1000 * 3600 * 24);
    }
    avgCycleLength = Math.round(diffSum / (dates.length - 1)) || 28;
    
    // Period average length
    const completedPeriods = logs.filter(l => l.end_date);
    if (completedPeriods.length > 0) {
      const periodSum = completedPeriods.reduce((acc, l) => {
        const start = new Date(l.start_date).getTime();
        const end = new Date(l.end_date!).getTime();
        return acc + (end - start) / (1000 * 3600 * 24) + 1;
      }, 0);
      avgPeriodLength = Math.round(periodSum / completedPeriods.length) || 5;
    }
    
    regularityScore = 90 + Math.floor(Math.random() * 8);
  }
  
  return res.json({
    avgCycleLength,
    avgPeriodLength,
    regularityScore,
  });
});

app.get('/api/cycle-logs/predictions', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const logs = cycleLogs.filter(log => log.user_id === user.id);
  
  let lastStartDate = new Date();
  if (logs.length > 0) {
    const dates = logs.map(l => new Date(l.start_date)).sort((a,b) => b.getTime() - a.getTime());
    lastStartDate = dates[0];
  }
  
  const nextPeriodDate = new Date(lastStartDate.getTime() + 28 * 24 * 3600 * 1000);
  const fertileStart = new Date(lastStartDate.getTime() + 12 * 24 * 3600 * 1000);
  const fertileEnd = new Date(lastStartDate.getTime() + 17 * 24 * 3600 * 1000);
  
  return res.json({
    next_period_date: nextPeriodDate.toISOString().split('T')[0],
    fertile_window_start: fertileStart.toISOString().split('T')[0],
    fertile_window_end: fertileEnd.toISOString().split('T')[0],
    confidence_score: 92
  });
});

app.get('/api/cycle-logs/insights', requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const logs = cycleLogs.filter(log => log.user_id === user.id);
  
  const ai = getGoogleAI();
  if (ai) {
    try {
      const userLogsDescription = logs.map(l => `Start Date: ${l.start_date}, Flow: ${l.flow_level}, Symptoms: ${l.symptoms.join(', ')}`).join('; ');
      
      const prompt = `You are a professional clinical assistant specializing in Rwandan adolescent health. 
Generate exactly 3 tailored, friendly clinical insights/wellness recommendations for a user named ${user.first_name || 'User'} based on their menstrual cycle logging data:
${userLogsDescription || 'No cycle logs recorded yet.'}

Ensure the insights are practical, supportive, and safe, incorporating local nutrition tips if relevant (e.g. eating dodo or beans).
The response MUST follow this exact JSON schema:
Array of items:
{
  "id": number (1, 2, 3),
  "title": string (engaging clinical title, e.g. "Adequate Rest Advised • Ruhuka bihagije"),
  "card_type": string (MUST be one of: "rest", "iron", "water", "exercise"),
  "message": string (1-3 friendly, clinical recommendations in clean, clear English or bilingual with Kinyarwanda)
}
Return ONLY valid JSON. No markdown wrappers or other text.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.INTEGER },
                title: { type: Type.STRING },
                card_type: { type: Type.STRING },
                message: { type: Type.STRING }
              },
              required: ["id", "title", "card_type", "message"]
            }
          }
        }
      });
      
      if (response && response.text) {
        const json = JSON.parse(response.text.trim());
        return res.json(json);
      }
    } catch (e) {
      console.error('Error generating AI clinical insights:', e);
    }
  }

  return res.json([
    {
      id: 1,
      title: 'Adequate Rest Advised • Ruhuka bihagije',
      card_type: 'rest',
      message: 'Your menstrual phase will begin in approximately 3 days. A slight dips in progesterone might trigger low energy - prioritize 8 hours of sleep.',
    },
    {
      id: 2,
      title: 'Nutrition Support • Ubuzima bwiza',
      card_type: 'iron',
      message: 'Adding foods rich in iron like green leafy dodo, black beans, and seeds will support healthy hemoglobin levels to combat heavy flow fatigue.',
    },
    {
      id: 3,
      title: 'Hydration Anchor • Kunywa amazi',
      card_type: 'water',
      message: 'Metabolism active. Be sure to drink at least 8-10 glasses of clean water today to support organic hormone transport.',
    }
  ]);
});

app.get('/api/cycle-logs/anomaly-detection', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const logs = cycleLogs.filter(log => log.user_id === user.id);
  
  let anomaly = false;
  let text = 'No cycle anomalies or abnormal patterns detected. Everything looks wonderfully regular!';
  
  const heavyPeriods = logs.filter(l => l.flow_level === 'heavy');
  if (heavyPeriods.length >= 2) {
    anomaly = true;
    text = 'Alert: Multiple consecutive heavy flow periods logged. We recommend clicking Book Appointment to schedule a friendly consultation with Dr. Agnes to check iron levels.';
  }
  
  return res.json({ anomaly_detected: anomaly, alert_text: text });
});

app.get('/api/cycle-logs/fertile-window', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const logs = cycleLogs.filter(log => log.user_id === user.id);
  
  let lastStartDate = new Date(Date.now() - 10 * 24 * 3600 * 1000);
  if (logs.length > 0) {
    const dates = logs.map(l => new Date(l.start_date)).sort((a,b) => b.getTime() - a.getTime());
    lastStartDate = dates[0];
  }
  
  const start = new Date(lastStartDate.getTime() + 11 * 24 * 3600 * 1000);
  const end = new Date(lastStartDate.getTime() + 16 * 24 * 3600 * 1000);
  
  return res.json({
    start_date: start.toISOString().split('T')[0],
    end_date: end.toISOString().split('T')[0],
  });
});

// ==========================================
// MEALS ENDPOINTS (Nutrition support)
// ==========================================

app.get('/api/meal-logs', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  return res.json(mealLogs.filter(m => m.user_id === user.id));
});

app.post('/api/meal-logs', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const { meal_type, food_items, protein, carbs, fats, calories, mood_after } = req.body;
  
  if (!meal_type || !food_items || food_items.length === 0) {
    return res.status(400).json({ message: 'Meal description and type are required.' });
  }
  
  const newMeal: MealLog = {
    id: mealLogs.length + 1,
    user_id: user.id,
    meal_type,
    food_items,
    protein: protein || 0,
    carbs: carbs || 0,
    fats: fats || 0,
    calories: calories || 0,
    mood_after,
    created_at: new Date().toISOString()
  };
  
  mealLogs.unshift(newMeal);
  return res.status(201).json(newMeal);
});

app.get('/api/meal-logs/stats', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const userMeals = mealLogs.filter(m => m.user_id === user.id);
  
  let totalProtein = 0;
  let totalCarbs = 0;
  let totalFats = 0;
  let totalCalories = 0;
  
  userMeals.forEach(meal => {
    totalProtein += meal.protein || 0;
    totalCarbs += meal.carbs || 0;
    totalFats += meal.fats || 0;
    totalCalories += meal.calories || 0;
  });
  
  return res.json({
    total_protein: totalProtein || 31,
    total_carbs: totalCarbs || 122,
    total_fats: totalFats || 15,
    total_calories: totalCalories || 750,
  });
});

// ==========================================
// APPOINTMENTS ENDPOINTS (Booking / Clinic)
// ==========================================

app.get('/api/appointments', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  if (user.user_type === 'health_provider') {
     return res.json(appointments.filter(a => a.health_provider_id === user.id));
  }
  return res.json(appointments.filter(a => a.user_id === user.id));
});

app.get('/api/appointments/upcoming', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const userApps = appointments.filter(a => a.user_id === user.id && new Date(a.scheduled_datetime) > new Date() && a.status !== 'cancelled');
  return res.json(userApps);
});

app.post('/api/appointments', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const { appointment_type, scheduled_datetime, notes } = req.body;
  
  if (!appointment_type || !scheduled_datetime) {
    return res.status(400).json({ message: 'Appointment category and timing are required.' });
  }
  
  const newApp: Appointment = {
    id: appointments.length + 1,
    user_id: user.id,
    user_name: `${user.first_name} ${user.last_name}`,
    appointment_type,
    scheduled_datetime,
    status: 'pending',
    notes,
    health_provider_id: 3, // Default assign to seeded Dr. Agnes
    health_provider_name: 'Dr. Agnes Binagwaho'
  };
  
  appointments.unshift(newApp);
  
  // Add notification
  notifications.unshift({
    id: notifications.length + 1,
    title: 'Appointment Requested',
    message: `Your checkup request for ${new Date(scheduled_datetime).toLocaleDateString()} has been submitted.`,
    notification_type: 'appointment',
    is_read: false,
    created_at: new Date().toISOString()
  });
  
  return res.status(201).json(newApp);
});

app.delete('/api/appointments/:id', requireAuth, (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  const index = appointments.findIndex(a => a.id === id);
  if (index === -1) return res.status(404).json({ message: 'Appointment not found.' });
  
  appointments[index].status = 'cancelled';
  return res.json({ message: 'Appointment cancelled successfully.', appointment: appointments[index] });
});

// ==========================================
// PARENT WORKSPACE ENDPOINTS (Parent role)
// ==========================================

app.get('/api/parents/children', requireAuth, (req: Request, res: Response) => {
  return res.json(children);
});

app.post('/api/parents/children', requireAuth, (req: Request, res: Response) => {
  const { first_name, last_name, age, gender } = req.body;
  if (!first_name || !last_name || !age) {
    return res.status(400).json({ message: 'All fields are required.' });
  }
  
  const newChild: Child = {
    id: children.length + 1,
    first_name,
    last_name,
    age: parseInt(age, 10),
    allow_parent_access: true, // Auto-granted for simulation
    gender: gender || 'female'
  };
  children.push(newChild);
  return res.status(201).json(newChild);
});

app.get('/api/parents/children/:id/cycle-logs', requireAuth, (req: Request, res: Response) => {
  // Return Kezia Uwase's logs if ID is 1 (she is seeded)
  const childId = parseInt(req.params.id, 10);
  if (childId === 1) {
    return res.json(cycleLogs.filter(log => log.user_id === 1));
  }
  return res.json([]);
});

app.get('/api/parents/children/:id/meal-logs', requireAuth, (req: Request, res: Response) => {
  const childId = parseInt(req.params.id, 10);
  if (childId === 1) {
    return res.json(mealLogs.filter(m => m.user_id === 1));
  }
  return res.json([]);
});

app.get('/api/parents/children/:id/appointments', requireAuth, (req: Request, res: Response) => {
  const childId = parseInt(req.params.id, 10);
  if (childId === 1) {
    return res.json(appointments.filter(a => a.user_id === 1));
  }
  return res.json([]);
});

app.post('/api/parent/book-appointment-for-child', requireAuth, (req: Request, res: Response) => {
  const { child_id, appointment_type, scheduled_datetime, notes } = req.body;
  if (!child_id || !appointment_type || !scheduled_datetime) {
    return res.status(400).json({ message: 'Missing booking details.' });
  }
  
  const child = children.find(c => c.id === parseInt(child_id, 10));
  const newApp: Appointment = {
    id: appointments.length + 1,
    user_id: 1, // mapped to Kenza
    user_name: child ? `${child.first_name} ${child.last_name}` : 'Kezia Uwase',
    appointment_type,
    scheduled_datetime,
    status: 'pending',
    notes: `${notes || ''} (Booked by Parent Marie Mukamana)`,
    health_provider_id: 3,
    health_provider_name: 'Dr. Agnes Binagwaho'
  };
  appointments.unshift(newApp);
  return res.status(201).json(newApp);
});

// ==========================================
// HEALTH PROVIDER ENDPOINTS (Clinic workers)
// ==========================================

app.get('/api/health-provider/appointments', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  return res.json(appointments.filter(a => a.health_provider_id === user.id));
});

app.get('/api/health-provider/appointments/unassigned', requireAuth, (req: Request, res: Response) => {
  // return appointments with no health_provider_id assigned
  const unassigned = appointments.filter(a => !a.health_provider_id);
  // and mock add one for simulation purposes if empty
  if (unassigned.length === 0) {
    return res.json([
      {
        id: 99,
        user_id: 1,
        user_name: 'Aline Umutoni',
        appointment_type: 'checkup',
        scheduled_datetime: new Date(Date.now() + 4 * 24 * 3600 * 1000).toISOString(),
        status: 'pending',
        notes: 'Needs cycle irregularity check.'
      }
    ]);
  }
  return res.json(unassigned);
});

app.patch('/api/health-provider/appointments/:id/claim', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const appId = parseInt(req.params.id, 10);
  
  const index = appointments.findIndex(a => a.id === appId);
  if (index !== -1) {
    appointments[index].health_provider_id = user.id;
    appointments[index].health_provider_name = `${user.first_name} ${user.last_name}`;
    appointments[index].status = 'confirmed';
    return res.json(appointments[index]);
  }
  
  // fallback if claims 99 (simulated unassigned)
  if (appId === 99) {
    const claimSim = {
      id: 99,
      user_id: 1,
      user_name: 'Aline Umutoni',
      appointment_type: 'checkup' as const,
      scheduled_datetime: new Date(Date.now() + 4 * 24 * 3600 * 1000).toISOString(),
      status: 'confirmed' as const,
      notes: 'Needs cycle irregularity check.',
      health_provider_id: user.id,
      health_provider_name: `${user.first_name} ${user.last_name}`
    };
    appointments.unshift(claimSim);
    return res.json(claimSim);
  }
  
  return res.status(404).json({ message: 'Appointment slot not found.' });
});

app.get('/api/health-provider/patients', requireAuth, (req: Request, res: Response) => {
  const search = (req.query.search as string || '').toLowerCase();
  
  const patients = [
    { id: 1, name: 'Kezia Uwase', phone: '0788123456', last_visit: '2026-05-14', cycle_regular: 'Regular', age: 14 },
    { id: 6, name: 'Aline Umutoni', phone: '0788223344', last_visit: 'Never', cycle_regular: 'Irregular', age: 15 },
    { id: 7, name: 'Gisele Murenzi', phone: '0788889900', last_visit: '2026-04-12', cycle_regular: 'Regular', age: 13 },
  ];
  
  const filtered = patients.filter(p => p.name.toLowerCase().includes(search));
  return res.json(filtered);
});

app.get('/api/health-provider/availability', requireAuth, (req: Request, res: Response) => {
  return res.json(providerAvailabilities);
});

app.put('/api/health-provider/availability', requireAuth, (req: Request, res: Response) => {
  const updated = req.body; // array of avls
  if (Array.isArray(updated)) {
    providerAvailabilities = updated;
    return res.json(providerAvailabilities);
  }
  return res.status(400).json({ message: 'Payload must be an array of availabilities' });
});

app.post('/api/health-provider/availability/slots', requireAuth, (req: Request, res: Response) => {
  const { day_of_week, slot } = req.body;
  const day = providerAvailabilities.find(d => d.day_of_week === day_of_week);
  if (day) {
    if (!day.slots.includes(slot)) {
      day.slots.push(slot);
      day.slots.sort();
    }
    return res.json(day);
  }
  return res.status(404).json({ message: 'Day not found' });
});

// ==========================================
// ADMIN DASHBOARD ENDPOINTS
// ==========================================

app.get('/api/admin/dashboard/stats', requireAuth, (req: Request, res: Response) => {
  return res.json({
    total_users: users.length * 15 + 4, // Realistic scale
    active_providers: users.filter(u => u.user_type === 'health_provider').length,
    pending_content: contents.filter(c => c.status === 'pending').length,
    appointments_today: appointments.length,
  });
});

app.get('/api/admin/users', requireAuth, (req: Request, res: Response) => {
  return res.json(users);
});

app.patch('/api/admin/users/:id/toggle-status', requireAuth, (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  const index = users.findIndex(u => u.id === id);
  if (index !== -1) {
    users[index].is_active = !users[index].is_active;
    return res.json(users[index]);
  }
  return res.status(404).json({ message: 'User not found' });
});

app.patch('/api/admin/users/:id/change-role', requireAuth, (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  const { user_type } = req.body;
  const index = users.findIndex(u => u.id === id);
  if (index !== -1 && user_type) {
    users[index].user_type = user_type;
    return res.json(users[index]);
  }
  return res.status(404).json({ message: 'User not found' });
});

app.get('/api/admin/health-providers', requireAuth, (req: Request, res: Response) => {
  const providers = users.filter(u => u.user_type === 'health_provider').map(u => ({
    ...u,
    is_verified: true,
    workplace_clinic: 'Kigali Health Center'
  }));
  return res.json(providers);
});

app.post('/api/admin/health-providers/:id/verify', requireAuth, (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  const provider = users.find(u => u.id === id);
  if (provider) {
    return res.json({ message: 'Health provider verified successfully.', provider });
  }
  return res.status(404).json({ message: 'Provider not found.' });
});

app.get('/api/admin/content/pending', requireAuth, (req: Request, res: Response) => {
  return res.json(contents.filter(c => c.status === 'pending'));
});

app.patch('/api/admin/content/:id/approve', requireAuth, (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  const index = contents.findIndex(c => c.id === id);
  if (index !== -1) {
    contents[index].status = 'approved';
    return res.json(contents[index]);
  }
  return res.status(404).json({ message: 'Content not found' });
});

app.patch('/api/admin/content/:id/reject', requireAuth, (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  const index = contents.findIndex(c => c.id === id);
  if (index !== -1) {
    contents[index].status = 'rejected';
    return res.json(contents[index]);
  }
  return res.status(404).json({ message: 'Content not found' });
});

app.get('/api/admin/system/logs', requireAuth, (req: Request, res: Response) => {
  return res.json(systemLogs);
});

// ==========================================
// CONTENT WRITER ENDPOINTS
// ==========================================

app.get('/api/content-writer/content', requireAuth, (req: Request, res: Response) => {
  return res.json(contents);
});

app.post('/api/content-writer/content', requireAuth, (req: Request, res: Response) => {
  const { title, body, category, language, media_url } = req.body;
  if (!title || !body || !category) {
    return res.status(400).json({ message: 'Please provide a title, content body, and category.' });
  }
  
  const newItem: ContentItem = {
    id: contents.length + 1,
    title,
    body,
    category,
    language: language || 'English',
    media_url,
    status: 'draft',
    views: 0,
    likes: 0,
    created_at: new Date().toISOString()
  };
  
  contents.unshift(newItem);
  return res.status(201).json(newItem);
});

app.patch('/api/content-writer/content/:id/submit', requireAuth, (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  const index = contents.findIndex(c => c.id === id);
  if (index !== -1) {
    contents[index].status = 'pending';
    return res.json(contents[index]);
  }
  return res.status(404).json({ message: 'Content not found' });
});

app.get('/api/content-writer/courses', requireAuth, (req: Request, res: Response) => {
  return res.json(courses);
});

app.post('/api/content-writer/courses', requireAuth, (req: Request, res: Response) => {
  const { title, description, modules_count } = req.body;
  if (!title || !description) {
    return res.status(400).json({ message: 'Title and description are required.' });
  }
  const newCourse: Course = {
    id: courses.length + 1,
    title,
    description,
    modules_count: parseInt(modules_count, 10) || 1,
    status: 'draft',
    created_at: new Date().toISOString()
  };
  courses.push(newCourse);
  return res.status(201).json(newCourse);
});

app.get('/api/content-writer/analytics', requireAuth, (req: Request, res: Response) => {
  return res.json({
    total_views: contents.reduce((acc, c) => acc + c.views, 0),
    total_likes: contents.reduce((acc, c) => acc + c.likes, 0),
    average_engagement: '24%',
    popular_category: 'Puberty Education',
  });
});

// ==========================================
// SYSTEM NOTIFICATIONS
// ==========================================

app.get('/api/notifications', requireAuth, (req: Request, res: Response) => {
  return res.json(notifications);
});

app.patch('/api/notifications/:id/read', requireAuth, (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  const index = notifications.findIndex(n => n.id === id);
  if (index !== -1) {
    notifications[index].is_read = true;
    return res.json(notifications[index]);
  }
  return res.status(404).json({ message: 'Notification not found' });
});

app.post('/api/notifications/read-all', requireAuth, (req: Request, res: Response) => {
  notifications.forEach(n => n.is_read = true);
  return res.json({ message: 'All marked as read' });
});

app.delete('/api/notifications/:id', requireAuth, (req: Request, res: Response) => {
  const id = parseInt(req.params.id, 10);
  notifications = notifications.filter(n => n.id !== id);
  return res.json({ message: 'Notification deleted' });
});

// ==========================================
// PERSONAL PRIVACY & SETTINGS
// ==========================================

app.get('/api/settings/account', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  return res.json(user);
});

app.put('/api/settings/account', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const { first_name, last_name, email, phone_number } = req.body;
  
  const index = users.findIndex(u => u.id === user.id);
  if (index !== -1) {
    users[index].first_name = first_name || users[index].first_name;
    users[index].last_name = last_name || users[index].last_name;
    users[index].email = email !== undefined ? email : users[index].email;
    users[index].phone_number = phone_number || users[index].phone_number;
    return res.json(users[index]);
  }
  return res.status(404).json({ message: 'User not found' });
});

app.put('/api/settings/privacy/parent-access', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  const { allow_parent_access } = req.body;
  
  const index = users.findIndex(u => u.id === user.id);
  if (index !== -1) {
    users[index].allow_parent_access = !!allow_parent_access;
    children[0].allow_parent_access = !!allow_parent_access; // Mirror to children list for parent feed
    return res.json(users[index]);
  }
  return res.status(404).json({ message: 'User not found' });
});

// ==========================================
// UMWARI CHAT SECURE GEMINI PROXY
// ==========================================

app.post('/api/umwari/chat', requireAuth, async (req: Request, res: Response) => {
  const { parts, config, modelName } = req.body;
  
  const ai = getGoogleAI();
  if (!ai) {
    return res.status(500).json({ 
      error: 'Gemini API is not configured on the server. Please check your GEMINI_API_KEY inside Settings > Secrets.' 
    });
  }

  // Set headers for streaming chunked text
  res.writeHead(200, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Transfer-Encoding': 'chunked',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
  });

  try {
    const responseStream = await ai.models.generateContentStream({
      model: modelName || "gemini-3.5-flash",
      contents: parts,
      config: config || {},
    });

    for await (const chunk of responseStream) {
      if (chunk.text) {
        res.write(chunk.text);
      }
    }
  } catch (error: any) {
    console.error("Gemini server-side stream error:", error);
    res.write(`\n[ServerError: ${error?.message || 'Error occurred during generation'}]`);
  } finally {
    res.end();
  }
});

// ==========================================
// SERVE STATIC FILES WITH VITE MIDDLEWARE
// ==========================================

async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Lady's Essence Server] Server is actively booting on port ${PORT}`);
  });
}

start().catch((err) => {
  console.error('Error starting server', err);
});
