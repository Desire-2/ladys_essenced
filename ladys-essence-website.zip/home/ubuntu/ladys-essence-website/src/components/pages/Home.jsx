import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Users, BookOpen, Heart, Shield, Smartphone, Globe, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';

// Import images
import heroImage from '../../assets/women-empowerment.jpg';
import educationImage from '../../assets/girls-education.jpg';
import healthImage from '../../assets/women-health-africa.jpg';
import schoolImage from '../../assets/rwanda-school.jpg';

const Home = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [stats, setStats] = useState({
    girls: 0,
    women: 0,
    workshops: 0,
    waitingList: 0
  });

  // Animate statistics on mount
  useEffect(() => {
    const animateStats = () => {
      const targets = { girls: 1200, women: 800, workshops: 15, waitingList: 600 };
      const duration = 2000;
      const steps = 60;
      const stepTime = duration / steps;

      let step = 0;
      const timer = setInterval(() => {
        step++;
        const progress = step / steps;
        
        setStats({
          girls: Math.floor(targets.girls * progress),
          women: Math.floor(targets.women * progress),
          workshops: Math.floor(targets.workshops * progress),
          waitingList: Math.floor(targets.waitingList * progress)
        });

        if (step >= steps) {
          clearInterval(timer);
          setStats(targets);
        }
      }, stepTime);
    };

    const timer = setTimeout(animateStats, 500);
    return () => clearTimeout(timer);
  }, []);

  const testimonials = [
    {
      text: "Before Lady's Essence came to our village, I missed school every month. Now I have the knowledge and supplies I need, and I haven't missed a single class. My grades have improved, and I can focus on my dream of becoming a doctor.",
      author: "Claudine, 15",
      location: "Student from Nyamagabe District"
    },
    {
      text: "The pregnancy care guidance helped me understand proper nutrition and vaccination schedules. My baby was born healthy, and I felt supported throughout the entire journey.",
      author: "Marie, 28",
      location: "Mother from Huye District"
    },
    {
      text: "The community workshops opened our eyes to important health topics we never discussed before. Now our daughters are better prepared and more confident.",
      author: "Agnes, 45",
      location: "Community Leader from Ruhango District"
    }
  ];

  const services = [
    {
      icon: Globe,
      title: "Web Platform",
      description: "Comprehensive digital platform with health tracking and educational resources",
      link: "https://ladys-essenced.vercel.app",
      external: true
    },
    {
      icon: Smartphone,
      title: "USSD Service",
      description: "Accessible health information for basic phones via USSD codes",
      link: "/ussd-simulator",
      external: false
    },
    {
      icon: BookOpen,
      title: "Educational Resources",
      description: "Culturally sensitive materials on menstrual health and pregnancy care",
      link: "/resources",
      external: false
    },
    {
      icon: Shield,
      title: "GBV Prevention",
      description: "Violence recognition, reporting, and support pathways",
      link: "/resources",
      external: false
    }
  ];

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 hero-gradient opacity-90"></div>
        <div className="absolute inset-0">
          <img 
            src={heroImage} 
            alt="Women empowerment in Africa" 
            className="w-full h-full object-cover opacity-30"
          />
        </div>
        
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Lady's Essence
            </h1>
            <p className="text-xl md:text-2xl mb-4 font-light">
              Empowering women, enhancing Lives
            </p>
            <p className="text-lg md:text-xl mb-8 opacity-90 max-w-2xl mx-auto">
              Transforming lives through comprehensive health education, tangible support, 
              and accessible technology for women and girls in rural Rwanda.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
                <Link to="/get-involved">
                  Support Our Mission <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                <Link to="/about">Learn Our Story</Link>
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white rounded-full mt-2 pulse-animation"></div>
          </div>
        </motion.div>
      </section>

      {/* Amina's Story Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-foreground">
                The Story of <span className="text-gradient">Amina</span>
              </h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Amina, a bright young girl in rural Rwanda, dreams of becoming a doctor. 
                  Every month, she misses school for days. Without knowledge about her body 
                  or access to sanitary pads, she falls behind in class.
                </p>
                <p>
                  Her mother, pregnant again, relies on fragmented advice passed through 
                  generations. Their shared family phone makes private health information 
                  inaccessible.
                </p>
                <p className="font-semibold text-primary">
                  Amina represents millions caught in a cycle of silence, stigma, and missed opportunities.
                </p>
                <p className="text-lg font-medium text-foreground">
                  This isn't just about periods or pregnancy; it's about dignity, education, 
                  and futures we are allowing to slip away.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img 
                src={educationImage} 
                alt="Girls education in Africa" 
                className="rounded-lg shadow-2xl w-full"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent rounded-lg"></div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Impact Statistics */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
              Our <span className="text-gradient">Impact</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Making a real difference in the lives of women and girls across 30 districts in Rwanda
            </p>
          </motion.div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="bg-primary/10 p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <div className="text-3xl font-bold text-primary mb-2">{stats.girls.toLocaleString()}+</div>
              <p className="text-muted-foreground">Girls received menstrual health education</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="bg-secondary/10 p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <Heart className="h-8 w-8 text-secondary" />
              </div>
              <div className="text-3xl font-bold text-secondary mb-2">{stats.women.toLocaleString()}+</div>
              <p className="text-muted-foreground">Women supported during pregnancy</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="bg-accent/10 p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <BookOpen className="h-8 w-8 text-accent" />
              </div>
              <div className="text-3xl font-bold text-accent mb-2">{stats.workshops}</div>
              <p className="text-muted-foreground">Community workshops on violence prevention</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="bg-orange-100 p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <Users className="h-8 w-8 text-orange-600" />
              </div>
              <div className="text-3xl font-bold text-orange-600 mb-2">{stats.waitingList.toLocaleString()}+</div>
              <p className="text-muted-foreground">Individuals on our waiting list</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
              Our <span className="text-gradient">Services</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive support through education, technology, and tangible resources
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full card-hover cursor-pointer">
                  <CardHeader className="text-center">
                    <div className="bg-primary/10 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                      <service.icon className="h-8 w-8 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <CardDescription className="mb-4">
                      {service.description}
                    </CardDescription>
                    {service.external ? (
                      <Button asChild variant="outline" size="sm">
                        <a href={service.link} target="_blank" rel="noopener noreferrer">
                          Access Platform <ArrowRight className="ml-2 h-4 w-4" />
                        </a>
                      </Button>
                    ) : (
                      <Button asChild variant="outline" size="sm">
                        <Link to={service.link}>
                          Learn More <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
              <span className="text-gradient">Voices</span> of Change
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Real stories from the women and girls whose lives have been transformed
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            <Card className="relative">
              <CardContent className="p-8">
                <div className="flex items-center justify-between mb-6">
                  <button
                    onClick={prevTestimonial}
                    className="p-2 rounded-full bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                  >
                    <ChevronLeft className="h-6 w-6" />
                  </button>
                  <button
                    onClick={nextTestimonial}
                    className="p-2 rounded-full bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                  >
                    <ChevronRight className="h-6 w-6" />
                  </button>
                </div>

                <motion.div
                  key={currentTestimonial}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.5 }}
                  className="text-center"
                >
                  <blockquote className="text-lg md:text-xl text-muted-foreground mb-6 italic">
                    "{testimonials[currentTestimonial].text}"
                  </blockquote>
                  <div>
                    <p className="font-semibold text-primary text-lg">
                      — {testimonials[currentTestimonial].author}
                    </p>
                    <p className="text-muted-foreground">
                      {testimonials[currentTestimonial].location}
                    </p>
                  </div>
                </motion.div>

                <div className="flex justify-center mt-6 space-x-2">
                  {testimonials.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentTestimonial(index)}
                      className={`w-3 h-3 rounded-full transition-colors ${
                        index === currentTestimonial ? 'bg-primary' : 'bg-primary/30'
                      }`}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 hero-gradient text-white">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Join Us in Empowering Her Future
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Every donation, partnership, and shared story brings us closer to a world 
              where no woman or girl is held back by her biology.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
                <Link to="/get-involved">
                  Donate Now <Heart className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                <Link to="/contact">Become a Partner</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Home;

