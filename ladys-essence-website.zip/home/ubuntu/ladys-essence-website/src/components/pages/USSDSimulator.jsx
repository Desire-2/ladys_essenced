import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Smartphone, Phone, ArrowRight, CheckCircle, Info, ExternalLink } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Alert, AlertDescription } from '../ui/alert';

const USSDSimulator = () => {
  const [showSimulator, setShowSimulator] = useState(false);

  const steps = [
    {
      step: 1,
      title: "Enter Your Phone Number",
      description: "Input your mobile phone number in the simulator (format: +250XXXXXXXXX for Rwanda)"
    },
    {
      step: 2,
      title: "Dial the USSD Code",
      description: "Type *384*70975# in the USSD code field"
    },
    {
      step: 3,
      title: "Navigate the Menu",
      description: "Follow the on-screen prompts to access health information and services"
    },
    {
      step: 4,
      title: "Explore Features",
      description: "Try different menu options to see available health resources and tips"
    }
  ];

  const features = [
    "Menstrual health information and cycle tracking",
    "Pregnancy care tips and nutrition guidance",
    "Emergency health contacts and resources",
    "Community health worker information",
    "Educational content in local languages",
    "No internet connection required"
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-primary/10 to-secondary/10">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <div className="bg-primary p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
              <Smartphone className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
              USSD <span className="text-gradient">Simulator</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Experience our USSD service that works on any mobile phone, even without internet. 
              Try the simulator below to see how easy it is to access health information.
            </p>
            <div className="bg-primary/10 p-4 rounded-lg inline-block">
              <p className="text-lg font-semibold text-primary">
                USSD Code: <span className="font-mono">*384*70975#</span>
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Instructions Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
              How to Use the <span className="text-gradient">Simulator</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Follow these simple steps to try our USSD service in the simulator below
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full text-center">
                  <CardHeader>
                    <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                      {step.step}
                    </div>
                    <CardTitle className="text-lg">{step.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>{step.description}</CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <Alert className="mb-8">
            <Info className="h-4 w-4" />
            <AlertDescription>
              <strong>Note:</strong> This is a simulator for demonstration purposes. 
              The actual USSD service works on real mobile phones by dialing *384*70975# 
              from any network in Rwanda.
            </AlertDescription>
          </Alert>
        </div>
      </section>

      {/* Simulator Section */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-8"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
              Try the <span className="text-gradient">USSD Simulator</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Experience our USSD service interface using the Africa's Talking simulator
            </p>
            
            {!showSimulator ? (
              <Button 
                onClick={() => setShowSimulator(true)}
                size="lg"
                className="mb-8"
              >
                Launch Simulator <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            ) : null}
          </motion.div>

          {showSimulator && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="max-w-6xl mx-auto"
            >
              <Card className="overflow-hidden">
                <CardHeader className="bg-primary text-white">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Phone className="h-6 w-6" />
                      <div>
                        <CardTitle>USSD Service Simulator</CardTitle>
                        <CardDescription className="text-primary-foreground/80">
                          Powered by Africa's Talking
                        </CardDescription>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      asChild
                      className="border-white text-white hover:bg-white hover:text-primary"
                    >
                      <a 
                        href="https://developers.africastalking.com/simulator" 
                        target="_blank" 
                        rel="noopener noreferrer"
                      >
                        Open in New Tab <ExternalLink className="ml-2 h-4 w-4" />
                      </a>
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="relative w-full" style={{ paddingBottom: '75%' }}>
                    <iframe
                      src="https://developers.africastalking.com/simulator"
                      className="absolute top-0 left-0 w-full h-full border-0"
                      title="USSD Simulator"
                      allow="fullscreen"
                    />
                  </div>
                </CardContent>
              </Card>
              
              <div className="mt-6 text-center">
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Instructions:</strong> In the simulator above, enter your phone number 
                    (use format +250XXXXXXXXX) and type <strong>*384*70975#</strong> as the USSD code 
                    to experience our service.
                  </AlertDescription>
                </Alert>
              </div>
            </motion.div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-foreground">
                Why Choose <span className="text-gradient">USSD</span>?
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                Our USSD service ensures that every woman and girl can access vital health 
                information, regardless of their phone type or internet connectivity.
              </p>
              <ul className="space-y-4">
                {features.map((feature, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-start gap-3"
                  >
                    <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                    <span className="text-muted-foreground">{feature}</span>
                  </motion.li>
                ))}
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <Card className="bg-gradient-to-br from-primary/10 to-secondary/10 border-0">
                <CardContent className="p-8 text-center">
                  <div className="bg-primary p-6 rounded-full w-24 h-24 mx-auto mb-6 flex items-center justify-center">
                    <Smartphone className="h-12 w-12 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-foreground">Universal Access</h3>
                  <p className="text-muted-foreground mb-6">
                    Works on any mobile phone - from the simplest feature phone to the latest smartphone. 
                    No app download or internet connection required.
                  </p>
                  <div className="bg-white p-4 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-2">Dial this code on your phone:</p>
                    <p className="text-2xl font-bold text-primary font-mono">*384*70975#</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Real Usage Section */}
      <section className="py-16 bg-muted">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center max-w-4xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-foreground">
              Ready to Use the <span className="text-gradient">Real Service</span>?
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              The simulator gives you a preview, but the real magic happens when you dial 
              *384*70975# on your actual mobile phone in Rwanda.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="bg-primary/10 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                    <Phone className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Step 1</h3>
                  <p className="text-sm text-muted-foreground">Open your phone's dialer</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="bg-secondary/10 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                    <span className="text-secondary font-bold text-lg">*#</span>
                  </div>
                  <h3 className="font-semibold mb-2">Step 2</h3>
                  <p className="text-sm text-muted-foreground">Dial *384*70975#</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="bg-accent/10 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                    <CheckCircle className="h-8 w-8 text-accent" />
                  </div>
                  <h3 className="font-semibold mb-2">Step 3</h3>
                  <p className="text-sm text-muted-foreground">Access health information</p>
                </CardContent>
              </Card>
            </div>

            <div className="mt-8">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>Available 24/7:</strong> Our USSD service is available around the clock 
                  on all major networks in Rwanda. Standard USSD charges may apply.
                </AlertDescription>
              </Alert>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default USSDSimulator;

